$ErrorActionPreference='Stop'
$root=Join-Path $env:USERPROFILE 'kp-2326667-mwrev8ox/sieve-20261122-100223'
$source="$root/mechanisms-20261124/source"
$out="$root/tree-pairs-20261124-v1/diagnostics"
$old='C:/Users/sshuser/CODE/kinetica-physics'
$tool="$old/tools/llvm-mingw-20261117-ucrt-x86_64/bin"
$env:Path="$tool;"+$env:Path
New-Item -Force -ItemType Directory $out | Out-Null
Set-Location $out
$opts=@('-O3','-DNDEBUG','-std=c++17','-march=haswell','-ffp-contract=off',"-I$source/validation/engines")
& clang++.exe @opts "-I$old/box3d/include" "$root/tree-study-BoxStages.cpp" "$old/build-box3d/src/libbox3d.a" -o box.exe
if($LASTEXITCODE){throw 'box diagnostic compile'}
& clang++.exe @opts -flto "-I$source/include" "$source/validation/engines/ours.cpp" "$root/tree-study-TreeCounts.cpp" "$root/mechanisms-20261124/build/src/libkinetica-physics.a" -o tree.exe
if($LASTEXITCODE){throw 'Kinetica diagnostic compile'}
[Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[intptr]256
$env:KP_THREADS='1'
$env:STRESS_PASS='verify'
foreach($scene in @('pyramid1000','rain1000')){
 $env:STRESS_SCENE=$scene
 cmd.exe /d /c "box.exe 1 > box-$scene.csv 2> box-profile-$scene.csv"
 if($LASTEXITCODE){throw 'box diagnostic run'}
 cmd.exe /d /c "tree.exe realtime 1 --shock-on > tree-$scene.csv 2> tree-counts-$scene.csv"
 if($LASTEXITCODE){throw 'tree diagnostic run'}
}
$files=@(Get-ChildItem -Filter '*.csv' -Name)
tar -czf "$root/tree-stage-results.tgz" @files
exit $LASTEXITCODE
