$ErrorActionPreference='Stop'
$root=Join-Path $env:USERPROFILE 'kp-2326667-mwrev8ox/sieve-20261122-100223'
$w="$root/vehicle-20261124"
$tool='C:/Users/sshuser/CODE/kinetica-physics/tools/llvm-mingw-20261117-ucrt-x86_64/bin'
$env:Path="$tool;"+$env:Path
$out="$root/tree-pairs-20261124-v1/shadow"
New-Item -Force -ItemType Directory $out | Out-Null
Set-Location $out
& clang++.exe -O3 -DNDEBUG -std=c++17 -march=haswell -ffp-contract=off -flto "-I$w/source/include" "$w/source/validation/engines/ours.cpp" "$root/ManifoldOracle.cpp" "$w/build/src/libkinetica-physics.a" -o manifolds.exe
if($LASTEXITCODE){throw 'compile'}
[Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[intptr]256
$env:KP_THREADS='1'
$env:STRESS_PASS='verify'
foreach($scene in @('pyramid1000','rain1000')){
 $env:STRESS_SCENE=$scene
 cmd.exe /d /c "manifolds.exe realtime 1 --shock-on > $scene.csv 2> counts-$scene.csv"
 if($LASTEXITCODE){throw 'run'}
 $ref="$root/mechanisms-20261124/qualified/$scene-on.csv"
 if((Get-FileHash "$out/$scene.csv").Hash -ne (Get-FileHash $ref).Hash){throw 'diagnostic changed geometry'}
 Get-Content "counts-$scene.csv"
}
& clang++.exe -O3 -DNDEBUG -std=c++17 -march=haswell -ffp-contract=off -flto "-I$w/source/include" "$root/ReplayPatch.cpp" "$w/build/src/libkinetica-physics.a" -o replay.exe
if($LASTEXITCODE){throw 'compile minimal case'}
cmd.exe /d /c "replay.exe lost-edge.txt > replay.txt"
if($LASTEXITCODE){throw 'counterexample failed to replay'}
Get-Content replay.txt
tar -czf "$root/manifold-shadow.tgz" pyramid1000.csv rain1000.csv counts-pyramid1000.csv counts-rain1000.csv lost-edge.txt replay.txt
exit $LASTEXITCODE
