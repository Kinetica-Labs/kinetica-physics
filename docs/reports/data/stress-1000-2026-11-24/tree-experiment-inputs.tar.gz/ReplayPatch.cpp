// Reads two boxes, their current poses and the cached face and anchors in local coordinates.
#include <collision/ManifoldMemory.h>
#include <fstream>
#include <iostream>
using namespace kp;

Vector3 vectorFrom(std::istream& input) {
    Vector3 v;
    input >> v.x >> v.y >> v.z;
    return v;
}
Body boxFrom(std::istream& input) {
    const Vector3 half = vectorFrom(input);
    const Vector3 centre = vectorFrom(input);
    Quaternion rotation;
    int dynamic;
    input >> rotation.w >> rotation.x >> rotation.y >> rotation.z >> dynamic;
    Body box = Body::box(half, dynamic, centre);
    box.orientation = rotation;
    return box;
}
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    std::ifstream input(argv[1]);
    const Body a = boxFrom(input), b = boxFrom(input);
    ManifoldMemory::Entry saved{};
    Real reach;
    input >> reach >> saved.faceOnB >> saved.count;
    if (!input || saved.count < 2 || saved.count > ManifoldMemory::kPoints) return 2;
    saved.normal = vectorFrom(input);
    saved.onFace = vectorFrom(input);
    for (int i = 0; i < saved.count; ++i) {
        saved.points[i].at = vectorFrom(input);
        input >> saved.points[i].id;
    }
    if (!input) return 2;
    const auto reused = ManifoldMemory::carried(saved, a, b, reach);
    const auto fresh = examinePairWithin(a, b, reach, Real(.001));
    const int count = fresh ? fresh->manifold.count : 0;
    std::cout << "cached_points=" << reused.manifold.count << ",fresh_points=" << count << '\n';
    return count != 0 || reused.manifold.count < 2;
}
