#include <cstdio>
#include <cstdlib>
#include <collision/ManifoldMemory.h>

#include <algorithm>
#include <limits>

namespace kp {
namespace {
// Пара возвращается решателю из старого алгоритма. У перенесённого ответа только наблюдатель.
enum Verdict { Match, Empty, Topology, Feature, Direction, Position, Kinds };
constexpr Real targetDistance = Real(2e-5); // м, 0,02 мм
constexpr Real targetNormalChord = Real(.0008726645983); // 2 sin(0,05°/2)
struct Oracle {
    long long all[Kinds]{}, sliding[Kinds]{};
    long long rejected = 0;
    void record(Verdict v, bool tangential) {
        ++all[v];
        if (tangential) ++sliding[v];
        ++rejected;
    }
    ~Oracle() {
        std::fprintf(stderr,"subset,matched,no_points,count_or_reference,feature_or_order,normal,anchor_or_gap\n");
        for (const auto subset : {all,sliding})
            std::fprintf(stderr,"%s,%lld,%lld,%lld,%lld,%lld,%lld\n",subset==all?"all":"small_tangential",
                         subset[Match],subset[Empty],subset[Topology],subset[Feature],subset[Direction],subset[Position]);
    }
} oracle;

void saveLostContact(const Body& a,const Body& b,const ManifoldMemory::Entry& entry,Real reach) {
    std::FILE* f=std::fopen("lost-edge.txt","w");
    if (!f) std::abort();
    const auto vec=[&](Vector3 v){std::fprintf(f,"%.17g %.17g %.17g ",v.x,v.y,v.z);};
    for (const Body* body : {&a,&b}) {
        vec({body->shape->support({1,0,0}).x,body->shape->support({0,1,0}).y,body->shape->support({0,0,1}).z});
        const auto pose=body->pose();
        vec(pose.position);
        const auto q=pose.orientation;
        std::fprintf(f,"%.17g %.17g %.17g %.17g %d\n",q.w,q.x,q.y,q.z,int(!body->isStatic()));
    }
    std::fprintf(f,"%.17g %d %d\n",reach,int(entry.faceOnB),entry.count);
    vec(entry.normal);vec(entry.onFace);std::fprintf(f,"\n");
    for (int i=0;i<entry.count;++i) {vec(entry.points[i].at);std::fprintf(f,"%u\n",entry.points[i].id);}
    std::fclose(f);
}

Verdict comparePatch(const ContactManifold& old, const std::optional<ContactPair>& fresh) {
    if (!fresh || fresh->manifold.count == 0) return Empty;
    const auto& now = fresh->manifold;
    if (old.count != now.count || old.faceOnB != now.faceOnB) return Topology;
    for (int i=0; i<old.count; ++i)
        if (old.points[size_t(i)].id != now.points[size_t(i)].id) return Feature;
    if ((old.normal - now.normal).length() > targetNormalChord) return Direction;
    for (int i=0; i<old.count; ++i) {
        const auto& a=old.points[size_t(i)];
        const auto& b=now.points[size_t(i)];
        if ((a.onA-b.onA).length()>targetDistance || (a.onB-b.onB).length()>targetDistance ||
            abs(a.separation-b.separation)>targetDistance) return Position;
    }
    return Match;
}


bool smallerIsA(const Body& a, const Body& b) { return a.shape->boundingRadius() <= b.shape->boundingRadius(); }

// Поза меньшего тела в осях большего: смещение любой точки меньшего тела относительно большего
// ограничено смещением его центра и поворотом на его же радиусе.
Transform apartOf(const Body& a, const Body& b) { return smallerIsA(a, b) ? b.pose().relative(a.pose()) : a.pose().relative(b.pose()); }

} // namespace

std::optional<ManifoldMemory::Entry> ManifoldMemory::entryOf(const ContactPair& pair, const Body& a, const Body& b) {
    const ContactManifold& found = pair.manifold;
    if (!a.shape->hull() || !b.shape->hull() || found.count < 2 || found.count > kPoints || found.roundA != 0 || found.roundB != 0) return std::nullopt;
    const Transform poseA = a.pose(), poseB = b.pose();
    const Transform &face = found.faceOnB ? poseB : poseA, &lying = found.faceOnB ? poseA : poseB;
    const auto onFace = [&](int k) { return found.faceOnB ? found.points[size_t(k)].onB : found.points[size_t(k)].onA; };
    const auto onLying = [&](int k) { return found.faceOnB ? found.points[size_t(k)].onA : found.points[size_t(k)].onB; };
    Entry entry{pair.a, pair.b, pair.partA, pair.partB, a.shape.get(), b.shape.get(), apartOf(a, b), pair.reach, found.faceOnB, face.localDirection(found.normal), face.localPoint(onFace(0)), found.count, {}};
    for (int k = 0; k < found.count; ++k) entry.points[k] = {lying.localPoint(onLying(k)), found.points[size_t(k)].id};
    return entry;
}

// a и b — части, как их отдаёт Body::part: у простого тела оно само. key — {тело a, тело b, часть a, часть b}.
const ManifoldMemory::Entry* ManifoldMemory::valid(const std::array<int, 4>& key, const Body& a, const Body& b, Real reach) const {
    const auto before = [](const Entry& entry, const std::array<int, 4>& wanted) {
        if (entry.a != wanted[0]) return entry.a < wanted[0];
        if (entry.b != wanted[1]) return entry.b < wanted[1];
        return entry.partA != wanted[2] ? entry.partA < wanted[2] : entry.partB < wanted[3];
    };
    const auto known = std::lower_bound(entries_.begin(), entries_.end(), key, before);
    if (known == entries_.end() || known->a != key[0] || known->b != key[1] || known->partA != key[2] || known->partB != key[3]) return nullptr;
    if (known->shapeA != a.shape.get() || known->shapeB != b.shape.get()) return nullptr;
    const Transform now = apartOf(a, b);
    // 2 sin(θ/2) — удвоенная длина векторной части кватерниона относительного поворота.
    const Quaternion turn = now.orientation * known->apart.orientation.conjugate();
    const Real chord = 2 * Vector3{turn.x, turn.y, turn.z}.length();
    const Real drift = (now.position - known->apart.position).length() + chord * std::min(a.shape->boundingRadius(), b.shape->boundingRadius());
    if (drift + std::max(Real(0), reach - known->reach) <= tolerance) return &*known;
    const ContactPair hypothetical=carried(*known,a,b,reach);
    const auto fresh=examinePairWithin(a,b,reach,Real(.001)); // soft.edgeSlop стенда
    const Body& larger=smallerIsA(a,b)?b:a;
    const Vector3 n=larger.pose().localDirection(hypothetical.manifold.normal);
    const Vector3 translation=now.position-known->apart.position;
    const Real rotation=chord*std::min(a.shape->boundingRadius(),b.shape->boundingRadius());
    const bool sliding=translation.length()<=Real(.002) && abs(translation.dot(n))<=targetDistance &&
        rotation<=targetDistance && reach-known->reach<=targetDistance;
    const Verdict verdict=comparePatch(hypothetical.manifold,fresh);
    if (sliding && verdict==Empty && oracle.sliding[Empty]==0) saveLostContact(a,b,*known,reach);
    oracle.record(verdict,sliding);
    return nullptr;
}

// Точка лежащего тела идёт с ним; её зазор — расстояние до плоскости опорной грани вдоль нормали
// площадки (от A к B), а точка на грани — её проекция на эту плоскость (HullVsHullAlgorithm).
ContactPair ManifoldMemory::carried(const Entry& entry, const Body& a, const Body& b, Real reach) {
    ContactPair pair;
    carryInto(entry, a, b, reach, pair);
    return pair;
}

void ManifoldMemory::carryInto(const Entry& entry, const Body& a, const Body& b, Real reach, ContactPair& pair) {
    const Transform poseA = a.pose(), poseB = b.pose();
    const Transform &face = entry.faceOnB ? poseB : poseA, &lying = entry.faceOnB ? poseA : poseB;
    pair.manifold.points.clear();
    pair.manifold.count = 0;
    pair.manifold.roundA = pair.manifold.roundB = 0;
    pair.reach = reach, pair.manifold.faceOnB = entry.faceOnB;
    const Vector3 n = pair.manifold.normal = face.direction(entry.normal), onFace = face.point(entry.onFace);
    Real least = std::numeric_limits<Real>::infinity();
    for (int k = 0; k < entry.count; ++k) {
        const Vector3 at = lying.point(entry.points[k].at);
        const Real separation = entry.faceOnB ? n.dot(onFace - at) : n.dot(at - onFace);
        pair.manifold.add(entry.faceOnB ? ContactPoint{at, at + separation * n, separation, entry.points[k].id} : ContactPoint{at - separation * n, at, separation, entry.points[k].id});
        least = std::min(least, separation);
    }
    pair.distance = std::max(Real(0), least);
}

// Записи, оставшиеся на своих местах, не копируются: в покое состав памяти не меняется вовсе. Иначе
// новый состав собирается в стороне — указатели смотрят в нынешний — и занимает его место.
void ManifoldMemory::replace(const StepArray<const Entry*>& entries) {
    size_t same = 0;
    while (same < entries.size() && same < entries_.size() && entries[same] == &entries_[same]) ++same;
    if (same == entries.size() && same == entries_.size()) return;
    next_.clear(), next_.reserve(entries.size());
    for (const Entry* entry : entries) next_.push_back(*entry);
    entries_.swap(next_);
}

} // namespace kp
