$ErrorActionPreference='Stop'
$root=Join-Path $env:USERPROFILE 'kp-2326667-mwrev8ox/sieve-20261122-100223'
$control=Join-Path $root 'mechanisms-20261124'
$w=Join-Path $root 'tree-pairs-20261124-v1'
$src=Join-Path $w 'source'
$build=Join-Path $w 'build'
$out=Join-Path $w 'evidence'
$tool='C:/Users/sshuser/CODE/kinetica-physics/tools/llvm-mingw-20261117-ucrt-x86_64/bin'
$env:Path="$tool;"+$env:Path
$env:KP_THREADS='1'
foreach($dir in @($src,$out)){New-Item -Force -ItemType Directory $dir | Out-Null}
$baselineSHA=(Get-FileHash "$root/mechanisms-src.tgz").Hash
if($baselineSHA -ne '791cfef521deda89cfa72f04aecab1623ab5f70808aace745b2700271a6050d5'){throw 'unexpected input revision'}
tar -xf "$root/mechanisms-src.tgz" -C $src
if($LASTEXITCODE){throw 'baseline unpack'}
tar -xf "$root/tree-study-src.tgz" -C $src
if($LASTEXITCODE){throw 'candidate unpack'}
$cache=Get-Content "$control/build/CMakeCache.txt"
function Setting($name){$line=@($cache | Where-Object {$_ -match "^${name}:[^=]+="});if($line.Count -eq 1){return ($line[0] -split '=',2)[1]};return ''}
$cfg=@('-S',$src,'-B',$build,'-G',(Setting 'CMAKE_GENERATOR'),'-DCMAKE_BUILD_TYPE=Release','-DKP_VIEWER=OFF')
foreach($k in @('CMAKE_MAKE_PROGRAM','CMAKE_CXX_COMPILER','CMAKE_CXX_FLAGS','CMAKE_INTERPROCEDURAL_OPTIMIZATION')){
 $v=Setting $k
 if($v){$cfg+="-D$k=$v"}
}
& cmake @cfg > "$out/configure.txt"
if($LASTEXITCODE){throw 'configure'}
cmd.exe /d /c "cmake --build `"$build`" --target compare-ours unit-tests study-state-hash -j 8 > `"$out/build.txt`" 2>&1"
if($LASTEXITCODE){Get-Content "$out/build.txt" -Tail 20;throw 'build'}
$cpu=256
[Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[intptr]$cpu
$base="$control/build/validation/engines/compare-ours.exe"
$trial="$build/validation/engines/compare-ours.exe"
$versions=@{base=$base;trial=$trial}
function Sample($exe,$arguments,$name) {
 $p=Start-Process $exe -ArgumentList $arguments -PassThru -NoNewWindow -RedirectStandardOutput "$out/$name" -RedirectStandardError "$out/$name.log"
 $p.Handle | Out-Null
 if($p.ProcessorAffinity.ToInt64() -ne $cpu){throw 'affinity'}
 $p.WaitForExit()
 if($p.ExitCode -ne 0){throw "$name exit $($p.ExitCode)"}
}
$env:STRESS_PASS='verify'
$expected=@{}
foreach($scene in @('pyramid1000','rain1000')){
 $env:STRESS_SCENE=$scene
 foreach($mode in @('on','off')){
  $name="verify-$scene-$mode.csv"
  Sample $trial @('realtime','1',"--shock-$mode") $name
  $orig="$control/qualified/$scene-$mode.csv"
  $r=@(Import-Csv "$out/$name")
  if($r.Count -ne 121 -or (Get-FileHash $orig).Hash -ne (Get-FileHash "$out/$name").Hash){throw "geometry $name"}
  if($mode -eq 'on'){$expected[$scene]=$r[-1].state_hash}
 }
}
Remove-Item Env:STRESS_SCENE,Env:STRESS_PASS
$p=Start-Process "$build/tests/unit-tests.exe" -NoNewWindow -Wait -PassThru -RedirectStandardOutput "$out/unit.txt" -RedirectStandardError "$out/unit.log"
if($p.ExitCode){throw 'unit'}
$oldBox='C:/Users/sshuser/CODE/kinetica-physics/box3d'
foreach($file in @('src/broad_phase.c','src/physics_world.c','src/solver.c','src/dynamic_tree.c','include/box3d/types.h')){
 if(Test-Path "$oldBox/$file"){Get-FileHash "$oldBox/$file" | Select-Object Path,Hash | Export-Csv -Append -NoTypeInformation "$out/box-source.csv"}
}
@{baseline_snapshot=$baselineSHA;overlay=(Get-FileHash "$root/tree-study-src.tgz").Hash;base_exe=(Get-FileHash $base).Hash;trial_exe=(Get-FileHash $trial).Hash;compiler=((& clang++.exe --version)[0]);flags=(Setting 'CMAKE_CXX_FLAGS');affinity=$cpu;threads=1;blocks=6;substeps=8;sleep=$false;frames=120;hashes=$expected} | ConvertTo-Json | Set-Content -Encoding utf8 "$out/manifest.json"
$env:STRESS_PASS='time'
function TimeRun($scene,$key,$file){
 $env:STRESS_SCENE=$scene
 Sample $versions[$key] @('realtime','1','--shock-on') "$file.csv"
 $rows=@(Import-Csv "$out/$file.csv")
 if($rows.Count -ne 120){throw "incomplete $file"}
 for($i=0;$i -lt 120;++$i){
  $u=[double]::Parse($rows[$i].step_us,[Globalization.CultureInfo]::InvariantCulture)
  if([int]$rows[$i].frame -ne $i+1 -or $rows[$i].final_hash -ne $expected[$scene] -or !($u -gt 0) -or [double]::IsInfinity($u)){throw "bad timing $file $i"}
 }
}
foreach($key in @('base','trial')){TimeRun 'pyramid1000' $key "warm-$key"}
foreach($block in 1..6){
 $order=if($block%2){@('base','trial')}else{@('trial','base')}
 $scenes=if($block%2){@('pyramid1000','rain1000')}else{@('rain1000','pyramid1000')}
 foreach($scene in $scenes){
  foreach($key in $order){TimeRun $scene $key "$scene-$block-$key"}
 }
 Write-Output "block $block / 6"
}
tar -czf "$root/tree-study-results.tgz" -C $out .
if($LASTEXITCODE){throw 'results archive'}
