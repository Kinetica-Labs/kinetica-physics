$ErrorActionPreference='Stop'
$root=Join-Path $env:USERPROFILE 'kp-2326667-mwrev8ox/sieve-20261122-100223'
$base="$root/mechanisms-20261124/build"
$new="$root/vehicle-20261124/build"
$out="$root/vehicle-20261124/regression"
$bin='C:/Users/sshuser/CODE/kinetica-physics/tools/llvm-mingw-20261117-ucrt-x86_64/bin'
$env:Path="$bin;"+$env:Path
New-Item -Force -ItemType Directory $out | Out-Null
$env:KP_STEP_MEMORY='check'
$checks=@{}
foreach($mode in @('exact60','fast600')){
  $params=if($mode -eq 'exact60'){@('60')}else{@('600','realtime')}
  foreach($key in @('base','trial')){
    $b=if($key -eq 'base'){$base}else{$new}
    $env:KP_THREADS='1'
    $p=Start-Process "$b/validation/studies/study-state-hash.exe" -ArgumentList $params -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$out/$mode-$key.txt" -RedirectStandardError "$out/$mode-$key.log"
    if($p.ExitCode){throw "hash $mode $key"}
  }
  $checks[$mode]=(Get-FileHash "$out/$mode-base.txt").Hash -eq (Get-FileHash "$out/$mode-trial.txt").Hash
}
foreach($n in @(4,12)){
  $env:KP_THREADS="$n"
  $p=Start-Process "$new/validation/studies/study-state-hash.exe" -ArgumentList @('60') -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$out/hash-t$n.txt" -RedirectStandardError "$out/hash-t$n.log"
  if($p.ExitCode){throw "hash $n"}
  $checks["threads$n"]=(Get-FileHash "$out/exact60-trial.txt").Hash -eq (Get-FileHash "$out/hash-t$n.txt").Hash
}
$checks | ConvertTo-Json | Set-Content -Encoding utf8 "$out/hash-results.json"
$env:KP_THREADS='4'
$env:KP_STEP_MEMORY=$null
foreach($key in @('base','trial')){
 $b=if($key -eq 'base'){$base}else{$new}
 $nonce=[Guid]::NewGuid().ToString('N')
 $rows="$out/case-$key-$nonce.jsonl"
 $p=Start-Process "$b/validation/studies/study-case-table.exe" -ArgumentList @('4',$rows) -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$out/case-$key.txt" -RedirectStandardError "$out/case-$key.log"
 if ($p.ExitCode -notin @(0,1) -or !(Test-Path $rows)) {throw "case $key failed"}
 Move-Item -Force $rows "$out/case-$key.jsonl"
}
tar -czf "$root/tree-regression.tgz" -C $out .
if($LASTEXITCODE){throw 'archive'}
