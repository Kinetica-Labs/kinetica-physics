"""Read centres printed by the real GLFW viewer. XTest runs on a private X server."""
import csv
import math
import os
from pathlib import Path
import re
import signal
import subprocess as sp
import sys
import time

root, work = map(Path, sys.argv[1:])

def xdo(*args):
    return sp.check_output(["xdotool", *map(str,args)],text=True,stderr=sp.DEVNULL,timeout=6).strip()

def find_window(app):
    for _ in range(100):
        if app.poll() is not None:
            raise RuntimeError(f"viewer exited {app.returncode}")
        try:
            return xdo("search","--onlyvisible","--name","^kinetica-physics$").splitlines()[-1]
        except (sp.CalledProcessError,IndexError):
            time.sleep(.1)
    print("display",os.environ['DISPLAY'],"process",Path(f'/proc/{app.pid}/wchan').read_text(),flush=True)
    for window in xdo("search","--name",".*").splitlines():
        print("window",window,xdo("getwindowname",window),flush=True)
    raise RuntimeError("viewer did not map")

def centres(window,log):
    start=log.stat().st_size
    xdo("key","t")
    for _ in range(60):
        with log.open("rb") as stream:
            stream.seek(start)
            src=stream.read().decode(errors="replace")
        if "последний шаг" in src:
            matches=re.findall(r"тело (\d+): центр \(([-.\d]+), ([-.\d]+), ([-.\d]+)\)",src)
            if len(matches)!=55: raise ValueError(f"received {len(matches)} dynamic bodies")
            return {int(i):tuple(map(float,xyz)) for i,*xyz in matches}
        time.sleep(.05)
    raise RuntimeError("no new state from viewer's T key")

def project(xyz,width,height):
    yaw,pitch=.6,.3
    eye_dir=(math.cos(pitch)*math.sin(yaw),math.sin(pitch),math.cos(pitch)*math.cos(yaw))
    relative=tuple(x-(c+9*d) for x,c,d in zip(xyz,(0,1.4,0),eye_dir))
    right=(math.cos(yaw),0,-math.sin(yaw))
    up=(-math.sin(pitch)*math.sin(yaw),math.cos(pitch),-math.sin(pitch)*math.cos(yaw))
    dot=lambda a,b:sum(p*q for p,q in zip(a,b))
    depth=-dot(relative,eye_dir)
    return (round(370+(width-370)/2+height*dot(relative,right)/depth),
            round(height/2-height*dot(relative,up)/depth))

def replay(binary,mode,kind):
    logfile=work/(binary.name+'-'+str(mode)+'-'+kind+'.log')
    with logfile.open('w') as stream:
        env=dict(os.environ,KP_STUDY_SUPPORT=str(mode))
        app=sp.Popen(['stdbuf','-oL',str(binary),'--scene','7','--measured','1'],stdout=stream,stderr=stream,env=env)
    try:
        win=find_window(app)
        xdo("windowfocus","--sync",win)
        geometry=dict(line.split("=",1) for line in xdo("getwindowgeometry","--shell",win).splitlines())
        time.sleep(.6)
        start=centres(win,logfile)
        x,y=project(start[5],int(geometry['WIDTH']),int(geometry['HEIGHT']))
        px,py=(8,y) if kind=="panel" else (x,y)
        xdo("mousemove","--window",win,px,py)
        time.sleep(.2)
        if kind in ("batched","released"):
            os.kill(app.pid,signal.SIGSTOP)
            os.waitpid(app.pid,os.WUNTRACED)
        xdo("mousedown","1")
        if kind=="ordinary": time.sleep(.15)
        if kind=="released": xdo("mouseup","1")
        if kind=="panel":
            xdo("mousemove","--window",win,x,y)
            time.sleep(.15)
        xdo("mousemove","--window",win,x+125,y-65)
        if kind in ("batched","released"): os.kill(app.pid,signal.SIGCONT)
        time.sleep(1.2)
        # Holding a sidebar widget can route T to ImGui. Read this control after release.
        held=None if kind=="panel" else centres(win,logfile)
        xdo("mouseup","1")
        time.sleep(.45)
        if kind=="panel":
            xdo("mousemove","--window",win,int(geometry['WIDTH'])-30,30)
            xdo("click","1")
            time.sleep(.1)
        end=centres(win,logfile)
        return (binary.name,mode,kind,px,py,round(math.dist(held[5],start[5]),4) if held else '',round(math.dist(end[5],start[5]),4),
                sum(math.dist(p,start[i])>.05 for i,p in end.items() if i!=5))
    except Exception:
        print(logfile.read_text(errors="replace")[-1000:],file=sys.stderr)
        raise
    finally:
        if app.poll() is None:
            os.kill(app.pid,signal.SIGCONT)
            app.terminate()
            try:app.wait(timeout=3)
            except sp.TimeoutExpired:app.kill();app.wait()

output=root/'window-input-results.csv'
with output.open('w',newline='') as dst:
    w=csv.writer(dst,lineterminator='\n')
    w.writerow(('binary','support','input','press_x','press_y','held_shift5_m','final_shift5_m','others_over_5cm'))
    for filename,support in (('stress-support-viewer',2),('stress-support-viewer-fixed',3),('stress-support-viewer-input',3)):
        b=root/filename
        cases=('ordinary','batched','panel','released') if filename.endswith('-input') else ('ordinary','batched')
        for kind in cases:
            r=replay(b,support,kind)
            w.writerow(r);dst.flush();print(*r,flush=True)
