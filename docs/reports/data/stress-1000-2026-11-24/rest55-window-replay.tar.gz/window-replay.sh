#!/usr/bin/env bash
set -eu
root=/mnt/c/Users/PC/kp-2326667-mwrev8ox/sieve-20261122-100223
runtime=/var/tmp/kp-stress55-gui
if [ "${1:-}" != "private-mounts" ]; then exec unshare --mount --propagation private bash "$0" private-mounts; fi
export LD_LIBRARY_PATH="$runtime/libs/usr/lib/x86_64-linux-gnu"
export PATH="$runtime/libs/usr/bin:$PATH"
export LIBGL_ALWAYS_SOFTWARE=1
export KP_STUDY_SUPPORT=3 KP_THREADS=1
run=$(mktemp -d "$runtime/run/input.XXXXXX")
mkdir -m 1777 "$run/sockets"
mount --bind "$run/sockets" /tmp/.X11-unix
if [ ! -x /usr/bin/xkbcomp ]; then
  mkdir "$run/bin-upper" "$run/bin-work"
  mount -t overlay overlay -o "lowerdir=/usr/bin,upperdir=$run/bin-upper,workdir=$run/bin-work" /usr/bin
  ln -s "$runtime/libs/usr/bin/xkbcomp" /usr/bin/xkbcomp
fi
Xvfb -displayfd 3 -screen 0 1600x1000x24 -nolisten tcp -noreset -xkbdir "$runtime/libs/usr/share/X11/xkb" 3>"$run/display" >"$run/server.log" 2>&1 &
server=$!
trap 'kill "$server" 2>/dev/null || true' EXIT
for n in {1..50}; do
  if ! kill -0 "$server" 2>/dev/null; then tail -n 10 "$run/server.log"; exit 2; fi
  if [ -s "$run/display" ]; then break; fi
  sleep .1
done
if [ ! -s "$run/display" ]; then tail -n 10 "$run/server.log"; exit 2; fi
export DISPLAY=:$(cat "$run/display")
unset WAYLAND_DISPLAY
export XDG_SESSION_TYPE=x11 XDG_RUNTIME_DIR="$run/session" GALLIUM_DRIVER=llvmpipe
mkdir -m 700 "$XDG_RUNTIME_DIR"
python3 "$root/window-replay.py" "$root" "$run"
