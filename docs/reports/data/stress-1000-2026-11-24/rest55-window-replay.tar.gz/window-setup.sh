#!/usr/bin/env bash
set -eu
root=/mnt/c/Users/PC/kp-2326667-mwrev8ox/sieve-20261122-100223
runtime=/var/tmp/kp-stress55-gui
mkdir -p "$runtime/debs" "$runtime/libs" "$runtime/run"
cd "$runtime/debs"
source /etc/os-release
printf 'deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu %s main universe\n' "$VERSION_CODENAME" > "$runtime/packages.list"
mkdir -p "$runtime/lists/partial"
opts=(-o "Dir::Etc::sourcelist=$runtime/packages.list" -o Dir::Etc::sourceparts=- -o "Dir::State::lists=$runtime/lists" -o Acquire::Languages=none -o Acquire::Retries=0 -o Acquire::https::Timeout=12)
apt-get "${opts[@]}" update -qq
apt-get "${opts[@]}" download xvfb xserver-common x11-xkb-utils libxkbfile1 libxfont2 libunwind8 libfontenc1 xkb-data xdotool libxdo3 libglfw3 libopengl0 >/dev/null
for deb in ./*.deb; do dpkg-deb -x "$deb" "$runtime/libs"; done
export LD_LIBRARY_PATH="$runtime/libs/usr/lib/x86_64-linux-gnu"
ldd "$root/stress-support-viewer-fixed" | grep 'not found' || true
ldd "$runtime/libs/usr/bin/Xvfb" | grep 'not found' || true
command -v xkbcomp || true
ldd "$runtime/libs/usr/bin/xdotool" | grep 'not found' || true
ldd "$runtime/libs/usr/bin/xkbcomp" | grep 'not found' || true
