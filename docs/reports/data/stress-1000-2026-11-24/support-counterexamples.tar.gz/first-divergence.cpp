#include "StandardScenes.h"
#include <math/WorkerPool.h>
#include <array>
#include <cstdio>
#include <cstring>
using namespace kp;
std::array<Real,13> state(const Body& body) {
    const auto p=body.position; const auto q=body.orientation;
    const auto v=body.linearVelocity(); const auto w=body.angularVelocity();
    return {p.x,p.y,p.z,q.w,q.x,q.y,q.z,v.x,v.y,v.z,w.x,w.y,w.z};
}
int main(){
    WorkerPool::shared().resize(1);
    for(const auto& scene:standardScenes()) if(std::strcmp(scene.key,"buckets")==0) {
        World plain=scene.build(), extra=scene.build();
        plain.realtime=extra.realtime=true; plain.shockPropagation=false; extra.shockPropagation=true;
        for(int f=1;f<=4440;++f) {
            plain.step(Real(1)/60); extra.step(Real(1)/60);
            for(size_t i=0;i<plain.bodies().size();++i){
                const auto a=state(plain.bodies()[i]), b=state(extra.bodies()[i]);
                for(size_t k=0;k<a.size();++k) if(a[k]!=b[k]) {
                    std::printf("first_frame,body,component,off,on\n%d,%zu,%zu,%.17g,%.17g\n",f,i,k,a[k],b[k]);return 0;
                }
            }
        }
        std::puts("no differing state across 4440 frames, 4 bodies, 13 components");return 0;
    }
    return 2;
}
