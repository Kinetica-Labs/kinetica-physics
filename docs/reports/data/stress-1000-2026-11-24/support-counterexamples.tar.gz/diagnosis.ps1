$ErrorActionPreference='Stop'
$out=Join-Path $root 'support-diagnosis'
New-Item -Force -ItemType Directory $out |Out-Null
foreach($tag in @('support-default','mechanisms')) {
 $w=Join-Path $root "$tag-20261124"
 $s="$w/source"
 & "$bin/clang++.exe" -O3 -ffp-contract=off -std=c++17 "-I$s/include" "-I$s/examples/scenes" "$root/first-divergence.cpp" "$w/build/examples/libkinetica-scenes.a" "$w/build/src/libkinetica-physics.a" -o "$out/$tag.exe"
 if($LASTEXITCODE){throw "compile $tag"}
 $p=Start-Process -FilePath "$out/$tag.exe" -PassThru -Wait -NoNewWindow -RedirectStandardOutput "$out/$tag.csv" -RedirectStandardError "$out/$tag.stderr"
 if($p.ExitCode){throw "run $tag"}
 Get-Content "$out/$tag.csv"
}
