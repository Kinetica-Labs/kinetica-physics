#include "examples/scenes/StandardScenes.h"
#include <cmath>
#include <cstdio>
#include <string>
int main() {
    const double g = 9.81, mu = 0.2, t = 1.0;
    const double a = g * (0.5 - mu * std::sqrt(3.0) / 2);
    for (const StandardScene& scene : standardScenes()) {
        if (std::string(scene.key) != "slope") continue;
        for (int n : {4, 8, 16, 32}) {
            kp::World world = scene.build();
            world.realtime = true;
            world.sleeping = false;
            world.soft.substeps = n;
            const auto start = world.bodies()[1].position;
            for (int i = 0; i < 60; ++i) world.step(t / 60);
            const auto delta = world.bodies()[1].position - start;
            const double along = delta.x * std::sqrt(3.0) / 2 - 0.5 * delta.y;
            const double error = (delta.length() - a * t * t / 2) * 1000;
            std::printf("n=%2d path=%.9f along=%.9f err_mm=%.8f model_mm=%.8f\n",
                        n, delta.length(), along, error, 1000 * a * t * t / (120 * n));
        }
    }
}
