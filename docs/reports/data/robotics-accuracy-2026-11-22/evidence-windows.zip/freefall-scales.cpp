#include <world/World.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
int main() {
    const double gravity = 9.81;
    const double tolerance = 1e-10;  // Normalized distance, fixed before the run.
    for (bool fast : {false, true}) {
        double low = 1e6, high = -1e6;
        for (double scale : {1e-6, 1e-3, 1.0, 1e3, 1e6}) {
            kp::World world;
            world.gravity = {0, -gravity, 0};
            world.realtime = fast;
            world.sleeping = false;
            world.soft.substeps = 8;
            world.addBody(kp::Body::box({scale, scale, scale}, 1000, {0, 10 * scale, 0}));
            const double time = std::sqrt(scale);
            for (int frame = 0; frame < 60; ++frame) world.step(time / 60);
            const double fall = (10 * scale - world.bodies()[0].position.y) / scale;
            const double error = fall - gravity / 2;
            if (!std::isfinite(error)) return 2;
            low = std::min(low, error);
            high = std::max(high, error);
            std::printf("fast=%d scale=%g fall=%.15g normalized_error=%.12g oracle_ok=%d\n",
                        fast, scale, fall, error, std::fabs(error) <= tolerance);
        }
        std::printf("fast=%d spread=%.12g similarity_ok=%d tolerance=%g\n",
                    fast, high - low, high - low <= tolerance, tolerance);
    }
}
