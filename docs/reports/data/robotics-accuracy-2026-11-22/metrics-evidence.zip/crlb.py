import math, random, statistics, json
from pathlib import Path
# Positive vertical displacement, unknown offset, initial velocity and gravity.
t = [i/60 for i in range(61)]
b = [x*x/2 for x in t]
mt, mb = statistics.mean(t), statistics.mean(b)
slope = sum((x-mt)*(z-mb) for x,z in zip(t,b))/sum((x-mt)**2 for x in t)
p = [z-mb-slope*(x-mt) for x,z in zip(t,b)]
info_weight = sum(z*z for z in p)
weights = [z/info_weight for z in p]
sigma, g, runs = 0.001, 9.81, 10000
sd = sigma/math.sqrt(info_weight)
known_sd = sigma/math.sqrt(sum(z*z for z in b))
assert abs(sum(weights))<1e-12 and abs(sum(x*z for x,z in zip(t,weights)))<1e-12
assert abs(sum(x*z for x,z in zip(b,weights))-1)<1e-12
truth = [0.37-0.23*x+g*z for x,z in zip(t,b)]
rng = random.Random(2326667)
errors = [sum(w*(y+rng.gauss(0,sigma)) for w,y in zip(weights,truth))-g for _ in range(runs)]
bias = statistics.mean(errors)
ratio = statistics.variance(errors)/sd**2
cover = sum(abs(e)<1.95996398454*sd for e in errors)/runs
res=dict(seed=2326667,runs=runs,sd=sd,known_sd=known_sd,bias=bias,
         bias_se=sd/math.sqrt(runs),measured_sd=statistics.stdev(errors),
         variance_ratio=ratio,coverage95=cover)
print(res)
Path('crlb.json').write_text(json.dumps(res,indent=2))
assert abs(bias)<3*sd/math.sqrt(runs) and 0.95<ratio<1.05

