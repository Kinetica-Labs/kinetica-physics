import csv, json, math, statistics
from pathlib import Path

def complete(k):
    a, b = 1.0, math.sqrt(1-k*k)
    for _ in range(8):
        a, b = (a+b)/2, math.sqrt(a*b)
    return math.pi/(2*a)

k = math.sin(math.pi/3)
K = complete(k)
q = math.exp(-math.pi*complete(math.sqrt(1-k*k))/K)
omega = math.sqrt(9.81 / ((0.4**2+0.03**2)/(3*0.4)+0.4))
def angle(t):
    phase = math.pi*(K-omega*t)/(2*K)
    s = sum(q**(j+0.5)*math.sin((2*j+1)*phase)/(1-q**(2*j+1)) for j in range(18))
    return 2*math.asin(2*math.pi/K*s)

result = {}
reference = [angle(i/60) for i in range(1,601)]
print('analytic_init,period,final', angle(0), 4*K/omega, reference[-1])
for ident in ['kp','bx','rp']:
    rows = list(csv.reader(open(ident+'.csv')))
    assert len(rows)==16*600
    old = json.loads(Path(ident+'.json').read_text(encoding='utf-8'))
    metrics = []
    for j in range(16):
        run = rows[600*j:600*(j+1)]
        assert [int(r[0]) for r in run] == list(range(1,601))
        errors = [math.remainder(float(r[1])-ref,2*math.pi) for r,ref in zip(run,reference)]
        axis = [math.remainder(float(r[2])-ref,2*math.pi) for r,ref in zip(run,reference)]
        assert all(math.isfinite(x) for x in errors+axis)
        metrics.append(dict(last=abs(errors[-1]), rms=statistics.mean(x*x for x in errors)**0.5,
             max=max(map(abs,errors)), rms_axis=statistics.mean(x*x for x in axis)**0.5,
             delta_endpoint=abs(abs(errors[-1])-old['numbers']['angle_err_rad'][j])))
    result[ident]=metrics
    print(ident, {k:format(statistics.median(x[k] for x in metrics),'.10g') for k in metrics[0]})
    print('max_endpoint_disagreement', max(x['delta_endpoint'] for x in metrics))
for rival in ['bx','rp']:
    print('lower_than',rival,{m:sum(a[m]<b[m] for a,b in zip(result['kp'], result[rival])) for m in ['last','rms','max','rms_axis']})
Path('angles.json').write_text(json.dumps(result,indent=2))

