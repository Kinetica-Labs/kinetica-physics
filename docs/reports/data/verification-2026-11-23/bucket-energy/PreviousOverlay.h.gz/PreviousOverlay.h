#pragma once
// У совпадающих рёбер несколько допустимых нормалей. Различия поз порядка округления
// могут изменить выбор. Отметки для покоя хранятся до движения относительно опорной позы.
#include <debug/DebugGeometry.h>
#include <algorithm>
#include <cmath>

class ContactOverlay {
public:
    void clear() { lastWorld_ = nullptr; }

    const kp::DebugGeometry& sample(const kp::World& world, bool raw = false) {
        const auto& bodies = world.bodies();
        if (!raw && lastWorld_ == &world && reference_.size() == bodies.size() &&
            std::equal(reference_.begin(), reference_.end(), bodies.begin(), sameGeometry))
            return markers_;
        markers_.points.clear();
        markers_.lines.clear();
        markers_.addContactMarkers(world);
        reference_.clear();
        reference_.reserve(bodies.size());
        for (const auto& body : bodies)
            reference_.push_back({body.pose(), body.shape.get(), body.parts.get(), body.isStatic()});
        lastWorld_ = &world;
        return markers_;
    }
private:
    struct Geometry {
        kp::Transform pose;
        const kp::ConvexShape* shape;
        const std::vector<kp::Body::Part>* parts;
        bool fixed;
    };
    // Для координат абсолютная граница 64 epsilon метров; для компонент кватерниона
    // она безразмерна. Порог не растёт с расстоянием до начала мира.
    static bool sameGeometry(const Geometry& saved, const kp::Body& body) {
        if (saved.shape != body.shape.get() || saved.parts != body.parts.get() || saved.fixed != body.isStatic()) return false;
        constexpr kp::Real tol = 64 * kp::kEpsilon;
        const auto pose = body.pose();
        if ((saved.pose.position - pose.position).lengthSquare() > tol * tol) return false;
        const auto a = saved.pose.orientation, b = pose.orientation;
        const kp::Real sign = a.w*b.w + a.x*b.x + a.y*b.y + a.z*b.z < 0 ? -1 : 1;
        return std::abs(a.w-sign*b.w) <= tol && std::abs(a.x-sign*b.x) <= tol &&
               std::abs(a.y-sign*b.y) <= tol && std::abs(a.z-sign*b.z) <= tol;
    }
    const kp::World* lastWorld_ = nullptr;
    std::vector<Geometry> reference_;
    kp::DebugGeometry markers_;
};
