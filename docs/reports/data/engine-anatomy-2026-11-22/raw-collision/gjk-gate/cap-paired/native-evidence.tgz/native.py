from pathlib import Path
import csv, hashlib, json, os, subprocess, tarfile
from collections import Counter
w=Path(__file__).resolve().parent
gate=w.parent
lab=gate.parent.parent
sdk=lab/'cap-manifold-src'
lib=lab/'cap-manifold-build/src/libkinetica-physics.a'
meta=json.loads((gate/'manifest.json').read_text())
capSrc=sdk/'src/collision/narrowphase/ContactPatch.cpp'
gjkSrc=sdk/'src/collision/narrowphase/Gjk.cpp'
cc=Path(r'C:\Users\sshuser\CODE\kinetica-physics\tools\llvm-mingw-20261117-ucrt-x86_64\bin\clang++.exe')
os.environ['PATH']=str(cc.parent)+os.pathsep+os.environ['PATH'];os.environ['KP_THREADS']='1';os.environ.pop('KP_GATE_ALWAYS',None)
sh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected_gjk=next(s for p,s in meta['files'].items() if p.endswith('Gjk.cpp'))
assert sh(gjkSrc)==expected_gjk
for n in ('gate.cpp','gate-metrics.h','preregistration.md'):
 assert sh(gate/n)==next(s for p,s in meta['files'].items() if p.endswith(n))
objects=[gate/'gate.obj',gate/'base/Gjk.obj',gate/'area/Gjk.obj']
manifest={'compiler':subprocess.check_output([cc,'--version']).decode().splitlines()[0],'archive_sha256':sh(lib),'sources':{p.name:sh(p) for p in [capSrc,gjkSrc]},'gjk_objects':{str(p.relative_to(gate)):sh(p) for p in objects},'preregistration_sha256':sh(gate/'preregistration.md'),'series':{}}
flags=['-std=c++17','-O3','-DNDEBUG','-ffp-contract=off','-I'+str(sdk/'include')]
front=['feature_a','feature_b','frame','swap','gap_m']
ct=['case','shape_a','shape_b','frame','swap','step','margin_m','oracle_gap_m']
summary=[]
for nm,m,cols in [('primary',1440,front),('holdout',1440,front),('contract',14992,ct)]:
 cpp=gate/(nm+'-probe.cpp');obj=w/(nm+'.obj')
 subprocess.run([cc,*flags,'-c',cpp,'-o',obj],check=True)
 tables=[];series={}
 for kind,override in [('cap',[]),('combined',objects)]:
  label=nm+'-'+kind
  exe=w/(label+'.exe')
  subprocess.run([cc,*flags,obj,*override,lib,'-o',exe],check=True)
  tab=w/(label+'.csv');tr=w/(label+'-trace.txt')
  with tab.open('wb') as f,tr.open('wb') as e: rc=subprocess.run([exe],stdout=f,stderr=e).returncode
  assert rc in (0,1),(label,rc)
  with tab.open() as f: rows=list(csv.DictReader(f))
  def key(r): return tuple(r[k] for k in cols)
  table={key(r):r for r in rows};assert len(rows)==len(table)==m,(label,len(rows),len(table),m)
  assert rc==int(any(r['pass']!='1' for r in rows))
  tables.append(table)
  series[kind]={'source_sha256':sh(cpp),'exe_sha256':sh(exe),'csv_sha256':sh(tab),'exit':rc}
  if kind=='combined':
   queries=retry=0
   for line in tr.open():
    if line.startswith('gate,'):queries+=1;retry+=int(line.split(',')[1])
   assert queries==m
   series[kind].update(queries=queries,retry=retry)
 old,new=tables
 assert old.keys()==new.keys()
 # Raw paired changes retain all keys and every independent boolean criterion.
 changes=[]
 criterion=[k for k in next(iter(old.values())) if k=='pass' or k.endswith('_ok')]
 for k,prev in old.items():
  curr=new[k]
  for c in criterion:
   if prev[c]!=curr[c]:
    changes.append(dict(zip(cols,k),criterion=c,cap=prev[c],combined=curr[c]))
 with (w/(nm+'-changes.csv')).open('w',newline='') as f:
  t=csv.DictWriter(f,[*cols,'criterion','cap','combined']);t.writeheader();t.writerows(changes)
 cnt=Counter((old[k]['pass'],new[k]['pass']) for k in old)
 out=dict(probe=nm,inputs=m,cap_pass=cnt['1','0']+cnt['1','1'],combined_pass=cnt['0','1']+cnt['1','1'],gained=cnt['0','1'],lost=cnt['1','0'],still_fail=cnt['0','0'],retries=series['combined']['retry'])
 print(out,flush=True)
 summary.append(out);manifest['series'][nm]=series
with (w/'paired.csv').open('w',newline='') as f:
 t=csv.DictWriter(f,list(summary[0]));t.writeheader();t.writerows(summary)
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(w/'native-evidence.tgz','w:gz') as a:
 for p in sorted(w.iterdir()):
  if p.name=='native.py' or p.suffix in ['.csv','.txt','.json']:a.add(p,arcname=p.name)
