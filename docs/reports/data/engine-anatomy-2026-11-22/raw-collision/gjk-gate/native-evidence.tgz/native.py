from pathlib import Path
from collections import Counter
import csv,hashlib,json,math,os,shutil,subprocess,sys,tarfile
work=Path(__file__).resolve().parent; out=work.parent.parent
sdk=out/'accepted-src';lib=out/'accepted-build/src/libkinetica-physics.a'
cc=Path(r'C:\Users\sshuser\CODE\kinetica-physics\tools\llvm-mingw-20261117-ucrt-x86_64\bin\clang++.exe')
os.environ['PATH']=str(cc.parent)+os.pathsep+os.environ['PATH']
flags=['-std=c++17','-O3','-DNDEBUG','-ffp-contract=off','-I'+str(sdk/'include'),'-I'+str(work)]
def build(*args):subprocess.run([cc,*flags,*args],check=True)
def one(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel=Path('src/collision/narrowphase/Gjk.cpp'); probe=Path('validation/studies/anatomy/primitive_feature_pairs.cpp')
m={'compiler':subprocess.check_output([cc,'--version']).decode().splitlines()[0],'files':{str(p):sha(p) for p in (sdk/rel,sdk/probe,lib,work/'preregistration.md',work/'gate.cpp',work/'gate-metrics.h')},'series':{}}
def metrics(s):
 s='#include "gate-metrics.h"\n'+s
 s=one(s,'    Real scale = v.dot(v);','    Real scale = v.dot(v);\n    Real lastAlong = 0;')
 s=one(s,'const Real along = v.dot(next.w);','const Real along = v.dot(next.w);\n        lastAlong = along;')
 s=one(s,'    return true;\n}\n\n} // namespace\n','''    auto& metrics = *gjkgate::current;
    metrics.upper = v.length();
    if (iterations > 64 && metrics.upper > 0 && std::isfinite(metrics.upper)) {
        lastAlong = v.dot(support(-v).w);
        metrics.certificateSupports += 2;
        metrics.descentSupports -= 2; // support lambda counted both calls
    }
    metrics.lower = metrics.upper > 0 && std::isfinite(metrics.upper) ? lastAlong / metrics.upper :
        std::numeric_limits<Real>::quiet_NaN();
    return true;
}

} // namespace
''')
 s=one(s,'        const Vector3 onA = a.support(d);','        gjkgate::current->descentSupports += 2;\n        const Vector3 onA = a.support(d);')
 s=one(s,'a.hasPointCore() && b.hasPointCore()', 'gjkgate::pointCore(a) && gjkgate::pointCore(b)')
 s=one(s,'        return pointCoreGap(a, poseA.position, b, poseB.position, farther);','        return gjkgate::current->analytic = true, pointCoreGap(a, poseA.position, b, poseB.position, farther);')
 s=one(s,'    // Ужать ядро можно','    gjkgate::current->shrunk = true;\n    // Ужать ядро можно')
 return s
objs=[]
for tag,alias in [('base','originalProjection'),('area','areaProjection')]:
 d=work/tag;(d/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(sdk/rel,d/rel)
 if tag=='area':subprocess.run(['git.exe','apply','--whitespace=nowarn',work/'area.patch'],cwd=d,check=True)
 s=metrics((d/rel).read_text(encoding='utf8'));(d/rel).write_text(s,encoding='utf8')
 o=d/'Gjk.obj';build('-DclosestPoints='+alias,'-c',d/rel,'-o',o);objs.append(o)
gh=work/'gate.obj';build('-c',work/'gate.cpp','-o',gh)
d=work/'holdout';(d/probe).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(sdk/probe,d/probe)
normalized=work/'holdout-lf.patch';normalized.write_bytes((work/'holdout.patch').read_bytes().replace(b'\r\n',b'\n'));subprocess.run(['git.exe','apply','--whitespace=nowarn',normalized],cwd=d,check=True)
names=['retry','alternate','original_shrunk','alternate_shrunk','beyond','overlap','analytic','unbounded','stock_width_m','area_width_m','first_descent_supports','second_descent_supports','first_certificate_supports','second_certificate_supports','first_pointcore_supports','second_pointcore_supports','first_bound_calls','second_bound_calls','original_resolved','alternate_resolved']
def run(name,exe,always=False):
 table=work/(name+'.csv'); trace=work/(name+'-trace.txt');env=os.environ.copy()
 if always:env['KP_GATE_ALWAYS']='1'
 with table.open('wb') as f,trace.open('wb') as e:rc=subprocess.run([exe],stdout=f,stderr=e,env=env).returncode
 if rc not in (0,1):raise RuntimeError((name,rc))
 rows=list(csv.DictReader(table.open()));counter=Counter();ns=0
 for l in trace.open():
  if not l.startswith('gate,'):continue
  ns+=1;values=l.strip().split(',')[1:];assert len(values)==len(names)
  for k,v in zip(names,values):
   if k not in ('stock_width_m','area_width_m'):counter[k]+=int(v)
 m['series'][name]=dict(rows=len(rows),queries=ns,exit=rc,failed=sum(r['pass']!='1' for r in rows),csv_sha256=sha(table),counters=dict(counter))
 print(name,'rows',len(rows),'failures',m['series'][name]['failed'],'queries',ns,'retries',counter['retry'],flush=True)
 return rows
for name,source in [('primary',sdk/probe),('holdout',d/probe),('contract',sdk/'validation/studies/anatomy/collision_contract.cpp')]:
 p=work/(name+'-probe.cpp');s=source.read_text(encoding='utf8')
 if name!='contract':
  s=one(s,'    const auto closest = closestPoints(','    std::fprintf(stderr,"case,%s,%s,%s,%d,%.9g\\n",a.name,b.name,frame,swap,gap);\n    const auto closest = closestPoints(')
 p.write_text(s,encoding='utf8')
 exe=work/(name+'.exe');build(p,gh,*objs,lib,'-o',exe)
 rows=run(name,exe)
 if name!='contract':
  assert len(rows)==1440
  full=run(name+'-forced-cost',exe,True);assert rows==full
 else:
  base=work/'contracts-base.exe';build(p,lib,'-o',base);baseline=run('contract-stock',base);assert len(baseline)==len(rows)
# Direct public guards with finite, positive-infinite horizons and degenerate configurations.
for nm,objects in [('gate',[gh,*objs]),('stock',[])]:
 exe=work/('guards-'+nm+'.exe');build(work/'guards.cpp',*objects,lib,'-o',exe);run('guards-'+nm,exe)
m['long_double_note']='area weights depend on ABI; see parent experiment'
(work/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(work/'evidence.tgz','w:gz') as arch:
 for p in sorted(work.iterdir()):
  if p.is_file() and p.suffix in ('.csv','.txt','.json','.h','.cpp','.patch','.md','.py'):arch.add(p,arcname=p.name)
