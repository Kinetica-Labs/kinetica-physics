#pragma once
#include <collision/narrowphase/Gjk.h>
#include <limits>
namespace gjkgate {
struct Metrics {
    kp::Real upper=std::numeric_limits<kp::Real>::quiet_NaN(), lower=upper;
    unsigned descentSupports=0, certificateSupports=0, pointCoreSupports=0, boundCalls=0;
    bool shrunk=false, analytic=false;
};
extern thread_local Metrics* current;
inline bool pointCore(const kp::ConvexShape& shape) {
    ++current->boundCalls;
    if (shape.boundingRadius()!=shape.radius) return false;
    const auto get=[&](kp::Vector3 d){ ++current->pointCoreSupports;return shape.support(d); };
    return get({1,0,0}).x==0 && get({-1,0,0}).x==0 && get({0,1,0}).y==0 &&
           get({0,-1,0}).y==0 && get({0,0,1}).z==0 && get({0,0,-1}).z==0;
}
}
