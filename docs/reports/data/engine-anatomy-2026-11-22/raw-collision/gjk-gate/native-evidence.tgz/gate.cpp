#include "gate-metrics.h"
#include <collision/shapes/Flat.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
namespace gjkgate { thread_local Metrics* current=nullptr; }
namespace kp {
using Query = ClosestPoints(const ConvexShape&,const Transform&,const ConvexShape&,const Transform&,Real);
Query originalProjection,areaProjection;
namespace {
using gjkgate::Metrics;
bool finite(Vector3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
bool resolved(const ClosestPoints& s) {
    return !s.beyond&&!s.coresOverlap&&std::isfinite(s.distance)&&finite(s.normal)&&finite(s.onA)&&finite(s.onB);
}
Real width(const Metrics& m) { return m.upper-m.lower; }
bool insideTolerance(Metrics& m, const ConvexShape& a,const ConvexShape& b) {
    const Real w=std::abs(width(m));
    if (!std::isfinite(w)) return false;
    if (w<=kOnBoundary) return true; // no boundingRadius() needed in this common case
    m.boundCalls+=2;
    const Real ra=a.boundingRadius(),rb=b.boundingRadius();
    if (!std::isfinite(ra)||!std::isfinite(rb)) return false;
    return w<=64*kEpsilon*std::max({ra,rb,m.upper});
}
}
ClosestPoints closestPoints(const ConvexShape& a,const Transform& pa,const ConvexShape& b,const Transform& pb,Real far) {
    Metrics first,second;
    gjkgate::current=&first;
    const auto orig=originalProjection(a,pa,b,pb,far);
    const bool usable=resolved(orig)&&!first.analytic;
    const bool under=usable&&!first.shrunk&&insideTolerance(first,a,b);
    const bool required=usable&&!under;
    static const bool always=std::getenv("KP_GATE_ALWAYS")!=nullptr;
    const bool retry=required||always;
    ClosestPoints alternative;
    bool take=false;
    if (retry) {
        gjkgate::current=&second;
        alternative=areaProjection(a,pa,b,pb,far);
        if (required&&resolved(alternative)&&!second.shrunk&&std::isfinite(width(second))) {
            const bool valid=width(second)>=0||insideTolerance(second,a,b);
            if (valid) {
                if (first.shrunk) take=insideTolerance(second,a,b);
                else take=!std::isfinite(width(first))||width(first)<0||std::max(Real(0),width(second))<width(first);
            }
        }
    }
    gjkgate::current=nullptr;
    std::fprintf(stderr,"gate,%d,%d,%d,%d,%d,%d,%d,%d,%.17g,%.17g,%u,%u,%u,%u,%u,%u,%u,%u,%d,%d\n",
       int(retry),int(take),int(first.shrunk),int(second.shrunk),int(orig.beyond),int(orig.coresOverlap),int(first.analytic),
       int(std::isinf(far)),double(width(first)),double(width(second)),first.descentSupports,second.descentSupports,
       first.certificateSupports,second.certificateSupports,first.pointCoreSupports,second.pointCoreSupports,
       first.boundCalls,second.boundCalls,int(resolved(orig)),int(retry&&resolved(alternative)));
    return take?alternative:orig;
}
}
