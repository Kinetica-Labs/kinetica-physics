#include <collision/narrowphase/Gjk.h>
#include <collision/shapes/Capsule.h>
#include <collision/shapes/ConvexHull.h>
#include <collision/shapes/Sphere.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <limits>
using namespace kp;
int main(){
 const Sphere a(.25),b(.125);const Capsule point(0,.125);const auto box=ConvexHull::box({.2,.2,.2});
 const Real inf=std::numeric_limits<Real>::infinity();int fails=0;
 std::puts("case,beyond,overlap,distance,pass");
 auto probe=[&](const char* label,const ConvexShape& x,Transform px,const ConvexShape& y,Transform py,Real far,int status,Real expected){
  const auto q=closestPoints(x,px,y,py,far);
  const int actual=q.beyond?2:q.coresOverlap?1:0;
  const bool ok=actual==status&&(status!=0||std::abs(q.distance-expected)<=1.e-12*std::max(Real(1),std::abs(expected)));
  std::printf("%s,%d,%d,%.17g,%d\n",label,int(q.beyond),int(q.coresOverlap),double(q.distance),int(ok));fails+=!ok;
 };
 probe("finite_beyond",a,{},b,{{2,0,0},{}},.1,2,0);
 probe("infinite_resolved",a,{},b,{{2,0,0},{}},inf,0,1.625);
 probe("finite_resolved",a,{},b,{{2,0,0},{}},2,0,1.625);
 probe("rounded_shells_penetrate",a,{},b,{{.125,0,0},{}},inf,0,-.25);
 probe("point_concentric",a,{},point,{},inf,0,-.375);
 probe("point_small_delta",a,{},point,{{std::numeric_limits<Real>::denorm_min(),0,0},{}},inf,0,-.375);
 probe("huge_delta",a,{},b,{{1e200,0,0},{}},inf,0,1e200);
 probe("overlap_hulls",box,{},box,{},inf,1,0);
 probe("finite_hulls_beyond",box,{},box,{{2,0,0},{}},.1,2,0);
 return fails?1:0;
}
