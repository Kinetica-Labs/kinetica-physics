from pathlib import Path
import os,csv,hashlib,json,subprocess,tarfile
w=Path(__file__).resolve().parent;lab=w.parent.parent
sdk=lab/'cap-manifold-src';lib=lab/'cap-manifold-build/src/libkinetica-physics.a'
cc=Path(r'C:\Users\sshuser\CODE\kinetica-physics\tools\llvm-mingw-20261117-ucrt-x86_64\bin\clang++.exe')
os.environ.update(PATH=str(cc.parent)+os.pathsep+os.environ['PATH'],KP_THREADS='1')
def build(*args):subprocess.run([cc,'-std=c++17','-O3','-DNDEBUG','-ffp-contract=off','-I'+str(sdk/'include'),'-I'+str(sdk/'validation/studies'),*args],check=True)
src=sdk/'src/collision/PairFinder.cpp';s=src.read_text(encoding='utf8');token='    if (carried) found.pairs.push_back'
assert s.count(token)==1
s='extern "C" void kp_record_lookup(int);\n'+s.replace(token,'    kp_record_lookup(memory == nullptr ? 2 : (carried ? 0 : 1));\n'+token)
mod=w/'PairFinder.cpp';mod.write_text(s,encoding='utf8')
probe=w/'probe.cpp';probe.write_text(r'''#define main previous_grip_main
#include "GripLimit.cpp"
#undef main
#include <array>
static std::array<unsigned long long,3> counts;
static bool record=false;
extern "C" void kp_record_lookup(int code) { if(record) ++counts[code]; }
int main(){
    kp::WorkerPool::shared().resize(1);
    std::puts("mode,case_name,phase,frame,public_steps,hits,misses,no_cache,relative_y_m,left_px_Ns,right_px_Ns");
    const grip::Load cases[]={{0.5,10,10},{0.5,10,12},{0.5,10,10,true}};
    const char* names[]={"threshold_10N","sliding_12N","open_10N"};
    for (bool coupled : {false,true}) for(int i=0;i<3;++i){
        const auto load=cases[i]; Rig rig(1,load,true);rig.world().soft.coupledFriction=coupled;
        for(int phase=0;phase<2;++phase) for(int frame=1;frame<=15;++frame){
            counts={};record=true;
            const bool ok=rig.step(1./60,load.squeeze,phase?load.down:0);
            record=false;
            const auto r=rig.read(); if (!ok || !r.valid()) return 1;
            std::printf("%s,%s,%s,%d,8,%llu,%llu,%llu,%.17g,%.17g,%.17g\n",coupled?"coupled":"stock",names[i],phase?"loaded":"preload",frame,counts[0],counts[1],counts[2],r.relativeY,r.leftPx,r.rightPx);
        }
    }
    return 0;
}
'''.replace(r'\\n',r'\n'),encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build('-c',mod,'-o',w/'PairFinder.obj')
build('-c',probe,'-o',w/'probe.obj')
tables=[];manifest={'compiler':subprocess.check_output([cc,'--version']).decode().splitlines()[0],'sdk_archive_sha256':sha(lib),'pairfinder_original_sha256':sha(src),'pairfinder_instrumented_sha256':sha(mod),'grip_sha256':sha(sdk/'validation/studies/GripLimit.cpp'),'probe_sha256':sha(probe),'scope':'one thread, 3 solid boxes + static shapeless slider anchor. PartFinder excluding listed pairs; no_cache is separate. Each world fresh per case and mode. Units integer counts.'}
for variant,objs in [('base',[]),('counter',[w/'PairFinder.obj'])]:
 exe=w/(variant+'.exe');build(w/'probe.obj',*objs,lib,'-o',exe)
 tab=w/(variant+'.csv')
 with tab.open('wb') as f:subprocess.run([exe],stdout=f,check=True)
 with tab.open() as f:rows=list(csv.DictReader(f))
 assert len(rows)==180,len(rows)
 tables.append(rows);manifest[variant]=dict(exe_sha256=sha(exe),csv_sha256=sha(tab))
cols=('hits','misses','no_cache')
assert all(all(ref[k]==row[k] for k in row if k not in cols) for ref,row in zip(*tables))
assert all(all(int(r[c])==0 for c in cols) for r in tables[0])
groups={}
for r in tables[1]:
 key=tuple(r[k] for k in ['mode','case_name','phase']);acc=groups.setdefault(key,[0,0,0]);acc[:]=[old+int(r[c]) for old,c in zip(acc,cols)]
with (w/'summary.csv').open('w',newline='') as f:
 writer=csv.writer(f);writer.writerow(['mode','case_name','phase','public_steps',*cols,'hit_pct'])
 for key,(h,m,n) in groups.items():
  writer.writerow([*key,120,h,m,n,round(100*h/(h+m),5) if h+m else 'n/a'])
manifest['identical_trajectories_frame_count']=180
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print((w/'summary.csv').read_text(),flush=True)
with tarfile.open(w/'native-evidence.tgz','w:gz') as tar:
 for n in ['native.py','PairFinder.cpp','probe.cpp','summary.csv','manifest.json','base.csv','counter.csv']:
  tar.add(w/n,arcname=n)
