
StepMemory::take

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

00000001400117e0 <_ZN2kp10StepMemory4takeEy>:
1400117e0:     	pushq	%r15
1400117e2:     	pushq	%r14
1400117e4:     	pushq	%rsi
1400117e5:     	pushq	%rdi
1400117e6:     	pushq	%rbx
1400117e7:     	subq	$0x50, %rsp
1400117eb:     	movq	%rcx, %rsi
1400117ee:     	addq	$0x1f, %rsi
1400117f2:     	andq	$-0x10, %rsi
1400117f6:     	movl	0x6f844(%rip), %eax     # 0x140081040 <_tls_index>
1400117fc:     	movq	%gs:0x58, %rcx
140011805:     	movq	(%rcx,%rax,8), %rax
140011809:     	cmpl	$0x0, 0x50(%rax)
140011810:     	jle	0x14001197c <_ZN2kp10StepMemory4takeEy+0x19c>
140011816:     	movl	0x6f824(%rip), %eax     # 0x140081040 <_tls_index>
14001181c:     	movq	%gs:0x58, %rcx
140011825:     	movq	(%rcx,%rax,8), %rax
140011829:     	cmpb	$0x0, 0x54(%rax)
140011830:     	je	0x1400119f1 <_ZN2kp10StepMemory4takeEy+0x211>
140011836:     	movl	0x6f804(%rip), %eax     # 0x140081040 <_tls_index>
14001183c:     	movq	%gs:0x58, %rcx
140011845:     	movq	(%rcx,%rax,8), %rcx
140011849:     	leaq	0x8(%rcx), %rbx
140011850:     	movq	0x10(%rcx), %r14
140011857:     	movq	0x8(%rcx), %rax
14001185e:     	movq	%r14, %rdx
140011861:     	subq	%rax, %rdx
140011864:     	sarq	$0x3, %rdx
140011868:     	movq	0x38(%rcx), %rcx
14001186f:     	cmpq	%rdx, %rcx
140011872:     	jae	0x1400118bc <_ZN2kp10StepMemory4takeEy+0xdc>
140011874:     	movq	0x18(%rbx), %r8
140011878:     	movq	0x38(%rbx), %r9
14001187c:     	addq	%rsi, %r9
14001187f:     	cmpq	(%r8,%rcx,8), %r9
140011883:     	jbe	0x1400118bc <_ZN2kp10StepMemory4takeEy+0xdc>
140011885:     	incq	%rcx
140011888:     	movq	%rcx, 0x30(%rbx)
14001188c:     	movq	$0x0, 0x38(%rbx)
140011894:     	cmpq	%rdx, %rcx
140011897:     	je	0x1400118c5 <_ZN2kp10StepMemory4takeEy+0xe5>
140011899:     	nopl	(%rax)
1400118a0:     	cmpq	(%r8,%rcx,8), %rsi
1400118a4:     	jbe	0x1400118bc <_ZN2kp10StepMemory4takeEy+0xdc>
1400118a6:     	incq	%rcx
1400118a9:     	movq	%rcx, 0x30(%rbx)
1400118ad:     	movq	$0x0, 0x38(%rbx)
1400118b5:     	cmpq	%rcx, %rdx
1400118b8:     	jne	0x1400118a0 <_ZN2kp10StepMemory4takeEy+0xc0>
1400118ba:     	jmp	0x1400118c5 <_ZN2kp10StepMemory4takeEy+0xe5>
1400118bc:     	cmpq	%rdx, %rcx
1400118bf:     	jne	0x140011966 <_ZN2kp10StepMemory4takeEy+0x186>
1400118c5:     	cmpq	$0x400001, %rsi         # imm = 0x400001
1400118cc:     	movl	$0x400000, %edi         # imm = 0x400000
1400118d1:     	cmovaeq	%rsi, %rdi
1400118d5:     	movq	%rdi, 0x48(%rsp)
1400118da:     	movq	%rdi, %rcx
1400118dd:     	callq	0x140072fd0 <malloc>
1400118e2:     	movq	%rax, 0x40(%rsp)
1400118e7:     	movq	%r14, 0x20(%rsp)
1400118ec:     	leaq	0x20(%rsp), %r15
1400118f1:     	movq	%r15, 0x28(%rsp)
1400118f6:     	leaq	0x40(%rsp), %rcx
1400118fb:     	movq	%rcx, 0x30(%rsp)
140011900:     	movq	%rbx, 0x38(%rsp)
140011905:     	cmpq	0x10(%rbx), %r14
140011909:     	je	0x140011a39 <_ZN2kp10StepMemory4takeEy+0x259>
14001190f:     	movq	%rax, (%r14)
140011912:     	addq	$0x8, %r14
140011916:     	movq	%r14, 0x8(%rbx)
14001191a:     	leaq	0x18(%rbx), %rcx
14001191e:     	movq	0x20(%rbx), %rax
140011922:     	movq	%rax, 0x20(%rsp)
140011927:     	movq	%r15, 0x28(%rsp)
14001192c:     	leaq	0x48(%rsp), %rdx
140011931:     	movq	%rdx, 0x30(%rsp)
140011936:     	movq	%rcx, 0x38(%rsp)
14001193b:     	cmpq	0x28(%rbx), %rax
14001193f:     	je	0x140011a4d <_ZN2kp10StepMemory4takeEy+0x26d>
140011945:     	movq	%rdi, (%rax)
140011948:     	addq	$0x8, %rax
14001194c:     	movq	%rax, 0x20(%rbx)
140011950:     	movq	0x8(%rbx), %rax
140011954:     	cmpq	$0x0, -0x8(%rax)
140011959:     	je	0x140011a6f <_ZN2kp10StepMemory4takeEy+0x28f>
14001195f:     	movq	(%rbx), %rax
140011962:     	movq	0x30(%rbx), %rcx
140011966:     	movq	0x38(%rbx), %rdx
14001196a:     	movq	(%rax,%rcx,8), %rax
14001196e:     	addq	%rdx, %rax
140011971:     	addq	%rdx, %rsi
140011974:     	movq	%rsi, 0x38(%rbx)
140011978:     	movb	$0x1, %cl
14001197a:     	jmp	0x1400119df <_ZN2kp10StepMemory4takeEy+0x1ff>
14001197c:     	movl	0x6f6be(%rip), %eax     # 0x140081040 <_tls_index>
140011982:     	movq	%gs:0x58, %rcx
14001198b:     	movq	(%rcx,%rax,8), %rax
14001198f:     	cmpb	$0x0, 0x54(%rax)
140011996:     	je	0x140011a15 <_ZN2kp10StepMemory4takeEy+0x235>
140011998:     	movl	0x6f6a2(%rip), %eax     # 0x140081040 <_tls_index>
14001199e:     	movq	%gs:0x58, %rcx
1400119a7:     	movq	(%rcx,%rax,8), %rax
1400119ab:     	cmpb	$0x1, 0x48(%rax)
1400119b2:     	jne	0x1400119d5 <_ZN2kp10StepMemory4takeEy+0x1f5>
1400119b4:     	movzbl	0x6f795(%rip), %eax     # 0x140081150 <_ZGVZN2kp12_GLOBAL__N_18registryEvE3all>
1400119bb:     	testb	%al, %al
1400119bd:     	je	0x140011a9a <_ZN2kp10StepMemory4takeEy+0x2ba>
1400119c3:     	movq	0x6f77e(%rip), %rax     # 0x140081148 <_ZZN2kp12_GLOBAL__N_18registryEvE3all>
1400119ca:     	movl	0x20(%rax), %eax
1400119cd:     	testl	%eax, %eax
1400119cf:     	jg	0x140011816 <_ZN2kp10StepMemory4takeEy+0x36>
1400119d5:     	movq	%rsi, %rcx
1400119d8:     	callq	0x140072e70 <_Znwy>
1400119dd:     	xorl	%ecx, %ecx
1400119df:     	movb	%cl, (%rax)
1400119e1:     	addq	$0x10, %rax
1400119e5:     	addq	$0x50, %rsp
1400119e9:     	popq	%rbx
1400119ea:     	popq	%rdi
1400119eb:     	popq	%rsi
1400119ec:     	popq	%r14
1400119ee:     	popq	%r15
1400119f0:     	retq
1400119f1:     	movl	0x6f649(%rip), %eax     # 0x140081040 <_tls_index>
1400119f7:     	movq	%gs:0x58, %rcx
140011a00:     	movq	(%rcx,%rax,8), %rax
140011a04:     	movb	$0x1, 0x54(%rax)
140011a0b:     	callq	0x140011080 <__cxx_global_var_init>
140011a10:     	jmp	0x140011836 <_ZN2kp10StepMemory4takeEy+0x56>
140011a15:     	movl	0x6f625(%rip), %eax     # 0x140081040 <_tls_index>
140011a1b:     	movq	%gs:0x58, %rcx
140011a24:     	movq	(%rcx,%rax,8), %rax
140011a28:     	movb	$0x1, 0x54(%rax)
140011a2f:     	callq	0x140011080 <__cxx_global_var_init>
140011a34:     	jmp	0x140011998 <_ZN2kp10StepMemory4takeEy+0x1b8>
140011a39:     	leaq	0x28(%rsp), %rcx
140011a3e:     	callq	0x140011ff0 <_ZZNSt3__16vectorIPcNS_9allocatorIS1_EEE12emplace_backB9nqe230106IJS1_EEERS1_DpOT_ENKUlvE0_clB9nqe230106Ev>
140011a43:     	movq	0x20(%rsp), %r14
140011a48:     	jmp	0x140011916 <_ZN2kp10StepMemory4takeEy+0x136>
140011a4d:     	leaq	0x28(%rsp), %rcx
140011a52:     	callq	0x140012100 <_ZZNSt3__16vectorIyNS_9allocatorIyEEE12emplace_backB9nqe230106IJRKyEEERyDpOT_ENKUlvE0_clB9nqe230106Ev>
140011a57:     	movq	0x20(%rsp), %rax
140011a5c:     	movq	%rax, 0x20(%rbx)
140011a60:     	movq	0x8(%rbx), %rax
140011a64:     	cmpq	$0x0, -0x8(%rax)
140011a69:     	jne	0x14001195f <_ZN2kp10StepMemory4takeEy+0x17f>
140011a6f:     	movl	$0x8, %ecx
140011a74:     	callq	0x140072e80 <__cxa_allocate_exception>
140011a79:     	movq	%rax, %rsi
140011a7c:     	movq	%rax, %rcx
140011a7f:     	callq	0x140073290 <_ZNSt9bad_allocC1Ev>
140011a84:     	leaq	0x63385(%rip), %rdx     # 0x140074e10 <_ZTISt9bad_alloc>
140011a8b:     	leaq	0x6180e(%rip), %r8      # 0x1400732a0 <_ZNSt9bad_allocD1Ev>
140011a92:     	movq	%rsi, %rcx
140011a95:     	callq	0x140072eb0 <__cxa_throw>
140011a9a:     	leaq	0x6f6af(%rip), %rcx     # 0x140081150 <_ZGVZN2kp12_GLOBAL__N_18registryEvE3all>
140011aa1:     	callq	0x140073060 <__cxa_guard_acquire>
140011aa6:     	testl	%eax, %eax
140011aa8:     	je	0x1400119c3 <_ZN2kp10StepMemory4takeEy+0x1e3>
140011aae:     	movl	$0x28, %ecx
140011ab3:     	callq	0x140072e70 <_Znwy>
140011ab8:     	xorps	%xmm0, %xmm0
140011abb:     	movups	%xmm0, 0x10(%rax)
140011abf:     	movups	%xmm0, (%rax)
140011ac2:     	movq	$0x0, 0x1d(%rax)
140011aca:     	movq	%rax, 0x6f677(%rip)     # 0x140081148 <_ZZN2kp12_GLOBAL__N_18registryEvE3all>
140011ad1:     	leaq	0x6f678(%rip), %rcx     # 0x140081150 <_ZGVZN2kp12_GLOBAL__N_18registryEvE3all>
140011ad8:     	callq	0x140073080 <__cxa_guard_release>
140011add:     	jmp	0x1400119c3 <_ZN2kp10StepMemory4takeEy+0x1e3>
140011ae2:     	movq	%rax, %rsi
140011ae5:     	leaq	0x6f664(%rip), %rcx     # 0x140081150 <_ZGVZN2kp12_GLOBAL__N_18registryEvE3all>
140011aec:     	callq	0x140073090 <__cxa_guard_abort>
140011af1:     	movq	%rsi, %rcx
140011af4:     	callq	0x140072ed0 <_Unwind_Resume>
140011af9:     	int3
140011afa:     	nopw	(%rax,%rax)

DirectJoints::assemble

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140048f10 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>:
140048f10:     	pushq	%r15
140048f12:     	pushq	%r14
140048f14:     	pushq	%r13
140048f16:     	pushq	%r12
140048f18:     	pushq	%rsi
140048f19:     	pushq	%rdi
140048f1a:     	pushq	%rbp
140048f1b:     	pushq	%rbx
140048f1c:     	subq	$0x128, %rsp            # imm = 0x128
140048f23:     	movapd	%xmm15, 0x110(%rsp)
140048f2d:     	movapd	%xmm14, 0x100(%rsp)
140048f37:     	movapd	%xmm13, 0xf0(%rsp)
140048f41:     	movapd	%xmm12, 0xe0(%rsp)
140048f4b:     	movapd	%xmm11, 0xd0(%rsp)
140048f55:     	movapd	%xmm10, 0xc0(%rsp)
140048f5f:     	movapd	%xmm9, 0xb0(%rsp)
140048f69:     	movapd	%xmm8, 0xa0(%rsp)
140048f73:     	movapd	%xmm7, 0x90(%rsp)
140048f7c:     	movapd	%xmm6, 0x80(%rsp)
140048f85:     	movq	(%rcx), %rax
140048f88:     	cmpq	0x8(%rcx), %rax
140048f8c:     	je	0x140049558 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x648>
140048f92:     	movq	%rdx, %rdi
140048f95:     	movq	%rcx, %rbp
140048f98:     	movq	0x8(%rdx), %rax
140048f9c:     	subq	(%rdx), %rax
140048f9f:     	addq	$0x90, %rcx
140048fa6:     	sarq	$0x3, %rax
140048faa:     	movabsq	$-0x2c8590b21642c859, %rdx # imm = 0xD37A6F4DE9BD37A7
140048fb4:     	imulq	%rax, %rdx
140048fb8:     	movq	%rcx, 0x30(%rsp)
140048fbd:     	callq	0x140049b00 <_ZNSt3__16vectorINS0_IiN2kp13StepAllocatorIiEEEENS2_IS4_EEE6resizeB9nqe230106Ey>
140048fc2:     	movq	(%rbp), %r12
140048fc6:     	movq	0x8(%rbp), %rax
140048fca:     	cmpq	%rax, %r12
140048fcd:     	je	0x1400494d5 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x5c5>
140048fd3:     	leaq	0x90(%rbp), %rcx
140048fda:     	movq	(%rcx), %rcx
140048fdd:     	movq	%r12, %rdx
140048fe0:     	movslq	(%rdx), %r8
140048fe3:     	leaq	(%r8,%r8,2), %r8
140048fe7:     	movq	(%rcx,%r8,8), %r9
140048feb:     	movq	%r9, 0x8(%rcx,%r8,8)
140048ff0:     	movslq	0x4(%rdx), %r8
140048ff4:     	leaq	(%r8,%r8,2), %r8
140048ff8:     	movq	(%rcx,%r8,8), %r9
140048ffc:     	movq	%r9, 0x8(%rcx,%r8,8)
140049001:     	addq	$0xa8, %rdx
140049008:     	cmpq	%rax, %rdx
14004900b:     	jne	0x140048fe0 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0xd0>
14004900d:     	leaq	0x30(%rbp), %rax
140049011:     	movq	%rax, 0x40(%rsp)
140049016:     	xorl	%r14d, %r14d
140049019:     	xorpd	%xmm6, %xmm6
14004901d:     	movapd	0x2dedb(%rip), %xmm7    # 0x140076f00 <.refptr._ZTVN2kp8CylinderE+0x408>
140049025:     	movq	%rbp, 0x50(%rsp)
14004902a:     	movq	%rdi, 0x48(%rsp)
14004902f:     	jmp	0x140049069 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x159>
140049031:     	nopw	%cs:(%rax,%rax)
140049040:     	incq	%r14
140049043:     	movq	(%rbp), %r12
140049047:     	movq	0x8(%rbp), %rax
14004904b:     	subq	%r12, %rax
14004904e:     	sarq	$0x3, %rax
140049052:     	movabsq	$-0x30c30c30c30c30c3, %rcx # imm = 0xCF3CF3CF3CF3CF3D
14004905c:     	imulq	%rcx, %rax
140049060:     	cmpq	%rax, %r14
140049063:     	jae	0x1400494d5 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x5c5>
140049069:     	imulq	$0xa8, %r14, %rax
140049070:     	movslq	(%r12,%rax), %r8
140049074:     	movq	(%rdi), %rcx
140049077:     	imulq	$0xb8, %r8, %rdx
14004907e:     	movsd	0x78(%rcx,%rdx), %xmm0
140049084:     	ucomisd	%xmm6, %xmm0
140049088:     	movl	%r14d, %edx
14004908b:     	jbe	0x1400490b1 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1a1>
14004908d:     	movq	0x30(%rsp), %rdx
140049092:     	movq	(%rdx), %r9
140049095:     	leaq	(%r8,%r8,2), %r10
140049099:     	movq	(%r9,%r10,8), %r8
14004909d:     	movl	%r14d, %edx
1400490a0:     	cmpq	0x8(%r9,%r10,8), %r8
1400490a5:     	je	0x1400490b1 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1a1>
1400490a7:     	movl	(%r8), %edx
1400490aa:     	cmpl	%r14d, %edx
1400490ad:     	cmovgel	%r14d, %edx
1400490b1:     	movslq	0x4(%r12,%rax), %r8
1400490b6:     	imulq	$0xb8, %r8, %r9
1400490bd:     	movsd	0x78(%rcx,%r9), %xmm0
1400490c4:     	ucomisd	%xmm6, %xmm0
1400490c8:     	jbe	0x1400490e8 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1d8>
1400490ca:     	movq	0x30(%rsp), %rcx
1400490cf:     	movq	(%rcx), %r9
1400490d2:     	leaq	(%r8,%r8,2), %r8
1400490d6:     	movq	(%r9,%r8,8), %rcx
1400490da:     	cmpq	0x8(%r9,%r8,8), %rcx
1400490df:     	je	0x1400490e8 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1d8>
1400490e1:     	movl	(%rcx), %ecx
1400490e3:     	cmpl	%edx, %ecx
1400490e5:     	cmovll	%ecx, %edx
1400490e8:     	addq	%rax, %r12
1400490eb:     	movq	0x40(%rsp), %rcx
1400490f0:     	callq	0x140049c90 <_ZN2kp13ProfileMatrix6addRowEi>
1400490f5:     	movq	(%r12), %rax
1400490f9:     	movq	%rax, 0x78(%rsp)
1400490fe:     	movslq	%r14d, %rax
140049101:     	movq	%rax, 0x38(%rsp)
140049106:     	xorl	%ebx, %ebx
140049108:     	movq	%r14, 0x58(%rsp)
14004910d:     	jmp	0x14004913e <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x22e>
14004910f:     	leaq	(%r8,%r9,8), %r13
140049113:     	movq	0x10(%r13), %rax
140049117:     	cmpq	%rax, %r15
14004911a:     	je	0x140049428 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x518>
140049120:     	movl	%r14d, (%r15)
140049123:     	addq	$0x4, %r15
140049127:     	movq	%r15, 0x8(%r13)
14004912b:     	nopl	(%rax,%rax)
140049130:     	addq	$0x4, %rbx
140049134:     	cmpq	$0x8, %rbx
140049138:     	je	0x140049040 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x130>
14004913e:     	movslq	0x78(%rsp,%rbx), %rax
140049143:     	movq	(%rdi), %rdx
140049146:     	imulq	$0xb8, %rax, %rcx
14004914d:     	movsd	0x78(%rdx,%rcx), %xmm0
140049153:     	ucomisd	%xmm6, %xmm0
140049157:     	jne	0x14004915b <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x24b>
140049159:     	jnp	0x140049130 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x220>
14004915b:     	addq	%rcx, %rdx
14004915e:     	movl	0x4(%r12), %r10d
140049163:     	xorl	%ecx, %ecx
140049165:     	cmpl	%r10d, %eax
140049168:     	sete	%cl
14004916b:     	leaq	0x2dd7e(%rip), %r8      # 0x140076ef0 <.refptr._ZTVN2kp8CylinderE+0x3f8>
140049172:     	movsd	(%r8,%rcx,8), %xmm1
140049178:     	mulsd	%xmm1, %xmm0
14004917c:     	movsd	0x8(%r12), %xmm11
140049183:     	movsd	0x10(%r12), %xmm10
14004918a:     	movsd	0x18(%r12), %xmm9
140049191:     	movapd	%xmm11, %xmm3
140049196:     	mulsd	%xmm0, %xmm3
14004919a:     	movapd	%xmm10, %xmm2
14004919f:     	mulsd	%xmm0, %xmm2
1400491a3:     	mulsd	%xmm9, %xmm0
1400491a8:     	movl	$0x20, %r11d
1400491ae:     	movl	$0x38, %ecx
1400491b3:     	cmoveq	%rcx, %r11
1400491b7:     	movsd	(%r12,%r11), %xmm14
1400491bd:     	movsd	0x8(%r12,%r11), %xmm13
1400491c4:     	movsd	0x10(%r12,%r11), %xmm12
1400491cb:     	movsd	0x30(%rdx), %xmm4
1400491d0:     	mulsd	%xmm14, %xmm4
1400491d5:     	movsd	0x38(%rdx), %xmm5
1400491da:     	mulsd	%xmm13, %xmm5
1400491df:     	addsd	%xmm4, %xmm5
1400491e3:     	movsd	0x40(%rdx), %xmm4
1400491e8:     	mulsd	%xmm12, %xmm4
1400491ed:     	addsd	%xmm5, %xmm4
1400491f1:     	movsd	0x48(%rdx), %xmm5
1400491f6:     	mulsd	%xmm14, %xmm5
1400491fb:     	movsd	0x50(%rdx), %xmm8
140049201:     	mulsd	%xmm13, %xmm8
140049206:     	addsd	%xmm5, %xmm8
14004920b:     	movsd	0x58(%rdx), %xmm5
140049210:     	mulsd	%xmm12, %xmm5
140049215:     	addsd	%xmm8, %xmm5
14004921a:     	movsd	0x60(%rdx), %xmm8
140049220:     	mulsd	%xmm14, %xmm8
140049225:     	movsd	0x68(%rdx), %xmm15
14004922b:     	mulsd	%xmm13, %xmm15
140049230:     	addsd	%xmm8, %xmm15
140049235:     	movsd	0x70(%rdx), %xmm8
14004923b:     	mulsd	%xmm12, %xmm8
140049240:     	addsd	%xmm15, %xmm8
140049245:     	mulsd	%xmm1, %xmm4
140049249:     	mulsd	%xmm1, %xmm5
14004924d:     	mulsd	%xmm1, %xmm8
140049252:     	movq	0x48(%rbp), %rcx
140049256:     	movq	0x90(%rbp), %r8
14004925d:     	leaq	(%rax,%rax,2), %r9
140049261:     	movq	(%r8,%r9,8), %rdx
140049265:     	movq	0x8(%r8,%r9,8), %r15
14004926a:     	cmpq	%r15, %rdx
14004926d:     	movq	%rdx, 0x60(%rsp)
140049272:     	je	0x1400493a9 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x499>
140049278:     	movl	%r10d, 0x28(%rsp)
14004927d:     	movq	(%rbp), %rdi
140049281:     	movq	0x30(%rbp), %rsi
140049285:     	movq	0x38(%rsp), %r10
14004928a:     	movq	(%rcx,%r10,8), %rcx
14004928e:     	movl	(%rsi,%r10,4), %r13d
140049292:     	movslq	%r13d, %r14
140049295:     	movq	0x60(%rbp), %r10
140049299:     	movq	%rcx, 0x70(%rsp)
14004929e:     	movq	%r10, 0x68(%rsp)
1400492a3:     	leaq	(%r10,%rcx,8), %rsi
1400492a7:     	jmp	0x1400492cc <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x3bc>
1400492a9:     	nopl	(%rax)
1400492b0:     	subq	%r14, %rcx
1400492b3:     	addsd	(%rsi,%rcx,8), %xmm9
1400492b9:     	movsd	%xmm9, (%rsi,%rcx,8)
1400492bf:     	addq	$0x4, %rdx
1400492c3:     	cmpq	%r15, %rdx
1400492c6:     	je	0x140049360 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x450>
1400492cc:     	movslq	(%rdx), %rcx
1400492cf:     	imulq	$0xa8, %rcx, %r10
1400492d6:     	cmpl	0x4(%rdi,%r10), %eax
1400492db:     	movsd	0x8(%rdi,%r10), %xmm9
1400492e2:     	mulsd	%xmm3, %xmm9
1400492e7:     	movsd	0x10(%rdi,%r10), %xmm10
1400492ee:     	mulsd	%xmm2, %xmm10
1400492f3:     	addsd	%xmm9, %xmm10
1400492f8:     	movsd	0x18(%rdi,%r10), %xmm11
1400492ff:     	mulsd	%xmm0, %xmm11
140049304:     	addsd	%xmm10, %xmm11
140049309:     	leaq	0x38(%rdi,%r10), %rbp
14004930e:     	leaq	0x20(%rdi,%r10), %r10
140049313:     	cmoveq	%rbp, %r10
140049317:     	movsd	(%r10), %xmm9
14004931c:     	mulsd	%xmm4, %xmm9
140049321:     	movsd	0x8(%r10), %xmm10
140049327:     	mulsd	%xmm5, %xmm10
14004932c:     	addsd	%xmm9, %xmm10
140049331:     	movsd	0x10(%r10), %xmm9
140049337:     	mulsd	%xmm8, %xmm9
14004933c:     	addsd	%xmm10, %xmm9
140049341:     	addsd	%xmm11, %xmm9
140049346:     	je	0x1400492b0 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x3a0>
14004934c:     	xorpd	%xmm7, %xmm9
140049351:     	jmp	0x1400492b0 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x3a0>
140049356:     	nopw	%cs:(%rax,%rax)
140049360:     	movsd	0x8(%r12), %xmm11
140049367:     	movsd	0x10(%r12), %xmm10
14004936e:     	movsd	0x18(%r12), %xmm9
140049375:     	movsd	(%r12,%r11), %xmm14
14004937b:     	movsd	0x8(%r12,%r11), %xmm13
140049382:     	movsd	0x10(%r12,%r11), %xmm12
140049389:     	movq	0x50(%rsp), %rbp
14004938e:     	movq	0x48(%rsp), %rdi
140049393:     	movq	0x58(%rsp), %r14
140049398:     	movl	0x28(%rsp), %r10d
14004939d:     	movq	0x70(%rsp), %r11
1400493a2:     	movq	0x68(%rsp), %rsi
1400493a7:     	jmp	0x1400493be <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x4ae>
1400493a9:     	movq	0x38(%rsp), %rdx
1400493ae:     	movq	(%rcx,%rdx,8), %r11
1400493b2:     	movq	0x30(%rbp), %rcx
1400493b6:     	movq	0x60(%rbp), %rsi
1400493ba:     	movl	(%rcx,%rdx,4), %r13d
1400493be:     	mulsd	%xmm11, %xmm3
1400493c3:     	mulsd	%xmm10, %xmm2
1400493c8:     	addsd	%xmm3, %xmm2
1400493cc:     	mulsd	%xmm9, %xmm0
1400493d1:     	addsd	%xmm2, %xmm0
1400493d5:     	mulsd	%xmm14, %xmm4
1400493da:     	mulsd	%xmm13, %xmm5
1400493df:     	addsd	%xmm4, %xmm5
1400493e3:     	mulsd	%xmm12, %xmm8
1400493e8:     	addsd	%xmm5, %xmm8
1400493ed:     	addsd	%xmm0, %xmm8
1400493f2:     	mulsd	%xmm8, %xmm1
1400493f7:     	movl	%r14d, %ecx
1400493fa:     	subl	%r13d, %ecx
1400493fd:     	movslq	%ecx, %rcx
140049400:     	leaq	(%rsi,%r11,8), %rdx
140049404:     	addsd	(%rdx,%rcx,8), %xmm1
140049409:     	movsd	%xmm1, (%rdx,%rcx,8)
14004940e:     	movl	(%r12), %ecx
140049412:     	cmpl	%ecx, %eax
140049414:     	jne	0x14004910f <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1ff>
14004941a:     	cmpl	%r10d, %ecx
14004941d:     	je	0x140049130 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x220>
140049423:     	jmp	0x14004910f <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x1ff>
140049428:     	movq	0x60(%rsp), %r8
14004942d:     	subq	%r8, %r15
140049430:     	movq	%r15, %rcx
140049433:     	sarq	$0x2, %rcx
140049437:     	incq	%rcx
14004943a:     	movq	%rcx, %rdx
14004943d:     	shrq	$0x3e, %rdx
140049441:     	jne	0x1400495c4 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x6b4>
140049447:     	subq	%r8, %rax
14004944a:     	movq	%rax, %rsi
14004944d:     	sarq	%rsi
140049450:     	cmpq	%rcx, %rsi
140049453:     	cmovbeq	%rcx, %rsi
140049457:     	movabsq	$0x7ffffffffffffffc, %rcx # imm = 0x7FFFFFFFFFFFFFFC
140049461:     	cmpq	%rcx, %rax
140049464:     	movabsq	$0x3fffffffffffffff, %rax # imm = 0x3FFFFFFFFFFFFFFF
14004946e:     	cmovaeq	%rax, %rsi
140049472:     	leaq	(,%rsi,4), %rcx
14004947a:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
14004947f:     	leaq	(%rax,%r15), %rcx
140049483:     	leaq	(%rax,%rsi,4), %rdx
140049487:     	movq	%rdx, 0x28(%rsp)
14004948c:     	movl	%r14d, (%rax,%r15)
140049490:     	addq	%rax, %r15
140049493:     	addq	$0x4, %r15
140049497:     	movq	(%r13), %rdx
14004949b:     	movq	0x8(%r13), %r8
14004949f:     	subq	%rdx, %r8
1400494a2:     	subq	%r8, %rcx
1400494a5:     	movq	%rcx, %rsi
1400494a8:     	callq	0x140072ff0 <memcpy>
1400494ad:     	movq	(%r13), %rcx
1400494b1:     	movq	%rsi, (%r13)
1400494b5:     	movq	%r15, 0x8(%r13)
1400494b9:     	movq	0x28(%rsp), %rax
1400494be:     	movq	%rax, 0x10(%r13)
1400494c2:     	testq	%rcx, %rcx
1400494c5:     	je	0x140049127 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x217>
1400494cb:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400494d0:     	jmp	0x140049127 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE+0x217>
1400494d5:     	leaq	0x30(%rbp), %rcx
1400494d9:     	addq	$0x78, %rbp
1400494dd:     	movsd	0x2da2b(%rip), %xmm2    # 0x140076f10 <.refptr._ZTVN2kp8CylinderE+0x418>
1400494e5:     	movq	%rbp, %rdx
1400494e8:     	movaps	0x80(%rsp), %xmm6
1400494f0:     	movaps	0x90(%rsp), %xmm7
1400494f8:     	movaps	0xa0(%rsp), %xmm8
140049501:     	movaps	0xb0(%rsp), %xmm9
14004950a:     	movaps	0xc0(%rsp), %xmm10
140049513:     	movaps	0xd0(%rsp), %xmm11
14004951c:     	movaps	0xe0(%rsp), %xmm12
140049525:     	movaps	0xf0(%rsp), %xmm13
14004952e:     	movaps	0x100(%rsp), %xmm14
140049537:     	movaps	0x110(%rsp), %xmm15
140049540:     	addq	$0x128, %rsp            # imm = 0x128
140049547:     	popq	%rbx
140049548:     	popq	%rbp
140049549:     	popq	%rdi
14004954a:     	popq	%rsi
14004954b:     	popq	%r12
14004954d:     	popq	%r13
14004954f:     	popq	%r14
140049551:     	popq	%r15
140049553:     	jmp	0x140049d90 <_ZN2kp14factorCholeskyINSt3__16vectorIcNS_13StepAllocatorIcEEEEEEvRNS_13ProfileMatrixERT_d>
140049558:     	movaps	0x80(%rsp), %xmm6
140049560:     	movaps	0x90(%rsp), %xmm7
140049568:     	movaps	0xa0(%rsp), %xmm8
140049571:     	movaps	0xb0(%rsp), %xmm9
14004957a:     	movaps	0xc0(%rsp), %xmm10
140049583:     	movaps	0xd0(%rsp), %xmm11
14004958c:     	movaps	0xe0(%rsp), %xmm12
140049595:     	movaps	0xf0(%rsp), %xmm13
14004959e:     	movaps	0x100(%rsp), %xmm14
1400495a7:     	movaps	0x110(%rsp), %xmm15
1400495b0:     	addq	$0x128, %rsp            # imm = 0x128
1400495b7:     	popq	%rbx
1400495b8:     	popq	%rbp
1400495b9:     	popq	%rdi
1400495ba:     	popq	%rsi
1400495bb:     	popq	%r12
1400495bd:     	popq	%r13
1400495bf:     	popq	%r14
1400495c1:     	popq	%r15
1400495c3:     	retq
1400495c4:     	callq	0x140029b90 <_ZNSt3__16vectorIiN2kp13StepAllocatorIiEEE20__throw_length_errorB9nqe230106Ev>
1400495c9:     	int3
1400495ca:     	nopw	(%rax,%rax)

DirectJoints::push

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

00000001400495d0 <_ZNK2kp12DirectJoints4pushEyRNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd>:
1400495d0:     	subq	$0x58, %rsp
1400495d4:     	movapd	%xmm10, 0x40(%rsp)
1400495db:     	movapd	%xmm9, 0x30(%rsp)
1400495e2:     	movapd	%xmm8, 0x20(%rsp)
1400495e9:     	movapd	%xmm7, 0x10(%rsp)
1400495ef:     	movapd	%xmm6, (%rsp)
1400495f4:     	movq	(%rcx), %rax
1400495f7:     	imulq	$0xa8, %rdx, %r9
1400495fe:     	leaq	(%rax,%r9), %rcx
140049602:     	movslq	(%rax,%r9), %r10
140049606:     	movq	(%r8), %rdx
140049609:     	imulq	$0xb8, %r10, %r8
140049610:     	movslq	0x4(%rax,%r9), %rax
140049615:     	imulq	$0xb8, %rax, %rax
14004961c:     	addq	%rdx, %rax
14004961f:     	movsd	0x78(%rdx,%r8), %xmm1
140049626:     	xorpd	%xmm0, %xmm0
14004962a:     	ucomisd	%xmm0, %xmm1
14004962e:     	jne	0x140049636 <_ZNK2kp12DirectJoints4pushEyRNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd+0x66>
140049630:     	jnp	0x140049710 <_ZNK2kp12DirectJoints4pushEyRNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd+0x140>
140049636:     	addq	%r8, %rdx
140049639:     	mulsd	%xmm3, %xmm1
14004963d:     	movsd	0x18(%rcx), %xmm2
140049642:     	mulsd	%xmm1, %xmm2
140049646:     	movsd	0x10(%rdx), %xmm4
14004964b:     	subsd	%xmm2, %xmm4
14004964f:     	movupd	0x8(%rcx), %xmm2
140049654:     	unpcklpd	%xmm1, %xmm1            # xmm1 = xmm1[0,0]
140049658:     	mulpd	%xmm2, %xmm1
14004965c:     	movupd	(%rdx), %xmm2
140049660:     	subpd	%xmm1, %xmm2
140049664:     	movupd	%xmm2, (%rdx)
140049668:     	movsd	%xmm4, 0x10(%rdx)
14004966d:     	movsd	0x30(%rcx), %xmm6
140049672:     	mulsd	%xmm3, %xmm6
140049676:     	movsd	0x70(%rdx), %xmm2
14004967b:     	mulsd	%xmm6, %xmm2
14004967f:     	movsd	0x28(%rdx), %xmm1
140049684:     	movupd	0x20(%rcx), %xmm5
140049689:     	movapd	%xmm3, %xmm4
14004968d:     	unpcklpd	%xmm3, %xmm4            # xmm4 = xmm4[0],xmm3[0]
140049691:     	mulpd	%xmm5, %xmm4
140049695:     	movupd	0x50(%rdx), %xmm5
14004969a:     	movupd	0x40(%rdx), %xmm7
14004969f:     	movupd	0x30(%rdx), %xmm8
1400496a5:     	movapd	%xmm4, %xmm9
1400496aa:     	shufpd	$0x1, %xmm4, %xmm9      # xmm9 = xmm9[1],xmm4[0]
1400496b0:     	movapd	%xmm8, %xmm10
1400496b5:     	unpckhpd	%xmm7, %xmm10           # xmm10 = xmm10[1],xmm7[1]
1400496ba:     	mulpd	%xmm9, %xmm10
1400496bf:     	unpcklpd	%xmm5, %xmm8            # xmm8 = xmm8[0],xmm5[0]
1400496c4:     	mulpd	%xmm4, %xmm8
1400496c9:     	addpd	%xmm10, %xmm8
1400496ce:     	unpcklpd	%xmm6, %xmm6            # xmm6 = xmm6[0,0]
1400496d2:     	movsd	%xmm7, %xmm5            # xmm5 = xmm7[0],xmm5[1]
1400496d6:     	mulpd	%xmm6, %xmm5
1400496da:     	movsd	0x60(%rdx), %xmm6
1400496df:     	mulsd	%xmm4, %xmm6
1400496e3:     	unpckhpd	%xmm4, %xmm4            # xmm4 = xmm4[1,1]
1400496e7:     	mulsd	0x68(%rdx), %xmm4
1400496ec:     	addpd	%xmm8, %xmm5
1400496f1:     	addsd	%xmm6, %xmm4
1400496f5:     	addsd	%xmm2, %xmm4
1400496f9:     	subsd	%xmm4, %xmm1
1400496fd:     	movupd	0x18(%rdx), %xmm2
140049702:     	subpd	%xmm5, %xmm2
140049706:     	movupd	%xmm2, 0x18(%rdx)
14004970b:     	movsd	%xmm1, 0x28(%rdx)
140049710:     	movsd	0x78(%rax), %xmm1
140049715:     	ucomisd	%xmm0, %xmm1
140049719:     	jne	0x140049721 <_ZNK2kp12DirectJoints4pushEyRNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd+0x151>
14004971b:     	jnp	0x1400497e6 <_ZNK2kp12DirectJoints4pushEyRNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd+0x216>
140049721:     	mulsd	%xmm3, %xmm1
140049725:     	movsd	0x18(%rcx), %xmm0
14004972a:     	mulsd	%xmm1, %xmm0
14004972e:     	addsd	0x10(%rax), %xmm0
140049733:     	movupd	0x8(%rcx), %xmm2
140049738:     	unpcklpd	%xmm1, %xmm1            # xmm1 = xmm1[0,0]
14004973c:     	mulpd	%xmm2, %xmm1
140049740:     	movupd	(%rax), %xmm2
140049744:     	addpd	%xmm1, %xmm2
140049748:     	movupd	0x18(%rax), %xmm1
14004974d:     	movupd	0x30(%rax), %xmm4
140049752:     	movupd	0x40(%rax), %xmm5
140049757:     	movupd	%xmm2, (%rax)
14004975b:     	movsd	%xmm0, 0x10(%rax)
140049760:     	movsd	0x48(%rcx), %xmm6
140049765:     	mulsd	%xmm3, %xmm6
140049769:     	movsd	0x70(%rax), %xmm0
14004976e:     	mulsd	%xmm6, %xmm0
140049772:     	movupd	0x38(%rcx), %xmm2
140049777:     	unpcklpd	%xmm3, %xmm3            # xmm3 = xmm3[0,0]
14004977b:     	mulpd	%xmm2, %xmm3
14004977f:     	movupd	0x50(%rax), %xmm2
140049784:     	movapd	%xmm3, %xmm7
140049788:     	shufpd	$0x1, %xmm3, %xmm7      # xmm7 = xmm7[1],xmm3[0]
14004978d:     	movapd	%xmm4, %xmm8
140049792:     	unpckhpd	%xmm5, %xmm8            # xmm8 = xmm8[1],xmm5[1]
140049797:     	mulpd	%xmm7, %xmm8
14004979c:     	unpcklpd	%xmm2, %xmm4            # xmm4 = xmm4[0],xmm2[0]
1400497a0:     	mulpd	%xmm3, %xmm4
1400497a4:     	addpd	%xmm8, %xmm4
1400497a9:     	unpcklpd	%xmm6, %xmm6            # xmm6 = xmm6[0,0]
1400497ad:     	movsd	%xmm5, %xmm2            # xmm2 = xmm5[0],xmm2[1]
1400497b1:     	mulpd	%xmm6, %xmm2
1400497b5:     	addpd	%xmm4, %xmm2
1400497b9:     	addpd	%xmm1, %xmm2
1400497bd:     	movsd	0x60(%rax), %xmm1
1400497c2:     	mulsd	%xmm3, %xmm1
1400497c6:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
1400497ca:     	mulsd	0x68(%rax), %xmm3
1400497cf:     	addsd	%xmm1, %xmm3
1400497d3:     	addsd	%xmm0, %xmm3
1400497d7:     	addsd	0x28(%rax), %xmm3
1400497dc:     	movupd	%xmm2, 0x18(%rax)
1400497e1:     	movsd	%xmm3, 0x28(%rax)
1400497e6:     	movaps	(%rsp), %xmm6
1400497ea:     	movaps	0x10(%rsp), %xmm7
1400497ef:     	movaps	0x20(%rsp), %xmm8
1400497f5:     	movaps	0x30(%rsp), %xmm9
1400497fb:     	movaps	0x40(%rsp), %xmm10
140049801:     	addq	$0x58, %rsp
140049805:     	retq
140049806:     	nopw	%cs:(%rax,%rax)

CoupledFriction::solve

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

00000001400641d0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd>:
1400641d0:     	pushq	%r15
1400641d2:     	pushq	%r14
1400641d4:     	pushq	%r13
1400641d6:     	pushq	%r12
1400641d8:     	pushq	%rsi
1400641d9:     	pushq	%rdi
1400641da:     	pushq	%rbp
1400641db:     	pushq	%rbx
1400641dc:     	subq	$0x698, %rsp            # imm = 0x698
1400641e3:     	movapd	%xmm15, 0x680(%rsp)
1400641ed:     	movapd	%xmm14, 0x670(%rsp)
1400641f7:     	movapd	%xmm13, 0x660(%rsp)
140064201:     	movapd	%xmm12, 0x650(%rsp)
14006420b:     	movapd	%xmm11, 0x640(%rsp)
140064215:     	movapd	%xmm10, 0x630(%rsp)
14006421f:     	movapd	%xmm9, 0x620(%rsp)
140064229:     	movapd	%xmm8, 0x610(%rsp)
140064233:     	movapd	%xmm7, 0x600(%rsp)
14006423c:     	movapd	%xmm6, 0x5f0(%rsp)
140064245:     	movq	%r8, %rbx
140064248:     	movq	%rdx, %rdi
14006424b:     	movq	%rcx, %rsi
14006424e:     	movq	(%rcx), %rax
140064251:     	movq	0x8(%rax), %rcx
140064255:     	movq	0x10(%rax), %rdx
140064259:     	xorpd	%xmm7, %xmm7
14006425d:     	xorpd	%xmm8, %xmm8
140064262:     	xorpd	%xmm0, %xmm0
140064266:     	cmpq	%rdx, %rcx
140064269:     	je	0x140064295 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xc5>
14006426b:     	nopl	(%rax,%rax)
140064270:     	movsd	0xa8(%rcx), %xmm1
140064278:     	addsd	%xmm1, %xmm8
14006427d:     	mulsd	0x98(%rcx), %xmm1
140064285:     	addsd	%xmm1, %xmm0
140064289:     	addq	$0xb0, %rcx
140064290:     	cmpq	%rdx, %rcx
140064293:     	jne	0x140064270 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xa0>
140064295:     	movsd	0x250(%rax), %xmm1
14006429d:     	mulsd	%xmm8, %xmm1
1400642a2:     	movapd	%xmm1, 0x220(%rsp)
1400642ab:     	movq	0x8(%rsi), %rdx
1400642af:     	movq	0x8(%rdx), %rcx
1400642b3:     	movq	0x10(%rdx), %r8
1400642b7:     	xorpd	%xmm6, %xmm6
1400642bb:     	cmpq	%r8, %rcx
1400642be:     	je	0x1400642f4 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x124>
1400642c0:     	xorpd	%xmm7, %xmm7
1400642c4:     	nopw	%cs:(%rax,%rax)
1400642d0:     	movsd	0xa8(%rcx), %xmm1
1400642d8:     	addsd	%xmm1, %xmm7
1400642dc:     	mulsd	0x98(%rcx), %xmm1
1400642e4:     	addsd	%xmm1, %xmm6
1400642e8:     	addq	$0xb0, %rcx
1400642ef:     	cmpq	%r8, %rcx
1400642f2:     	jne	0x1400642d0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x100>
1400642f4:     	movsd	0x250(%rdx), %xmm4
1400642fc:     	mulsd	%xmm7, %xmm4
140064300:     	xorpd	%xmm1, %xmm1
140064304:     	movapd	0x220(%rsp), %xmm2
14006430d:     	cmpneqsd	%xmm1, %xmm2
140064312:     	movapd	%xmm4, 0x250(%rsp)
14006431b:     	cmpneqsd	%xmm4, %xmm1
140064320:     	orpd	%xmm2, %xmm1
140064324:     	movd	%xmm1, %ebp
140064328:     	testb	$0x1, %bpl
14006432c:     	je	0x1400664d7 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x2307>
140064332:     	movsd	%xmm3, 0x2d8(%rsp)
14006433b:     	leaq	0x250(%rax), %rcx
140064342:     	movupd	0x280(%rax), %xmm12
14006434b:     	movupd	0x280(%rdx), %xmm13
140064354:     	movslq	(%rax), %rdx
140064357:     	movq	(%rdi), %r9
14006435a:     	imulq	$0xb8, %rdx, %rdx
140064361:     	addq	%r9, %rdx
140064364:     	movslq	0x4(%rax), %r8
140064368:     	imulq	$0xb8, %r8, %r8
14006436f:     	addq	%r9, %r8
140064372:     	movq	0x30(%rax), %r9
140064376:     	movq	%r9, 0x350(%rsp)
14006437e:     	movups	0x20(%rax), %xmm1
140064382:     	movaps	%xmm1, 0x340(%rsp)
14006438a:     	movq	0x48(%rax), %r9
14006438e:     	movq	%r9, 0x368(%rsp)
140064396:     	movups	0x38(%rax), %xmm1
14006439a:     	movups	%xmm1, 0x358(%rsp)
1400643a2:     	movq	0x60(%rax), %r9
1400643a6:     	movq	%r9, 0x380(%rsp)
1400643ae:     	movups	0x50(%rax), %xmm1
1400643b2:     	movaps	%xmm1, 0x370(%rsp)
1400643ba:     	movq	0x78(%rax), %r9
1400643be:     	movq	%r9, 0x398(%rsp)
1400643c6:     	movups	0x68(%rax), %xmm1
1400643ca:     	movups	%xmm1, 0x388(%rsp)
1400643d2:     	movupd	0x80(%rax), %xmm1
1400643da:     	movapd	%xmm1, 0x3a0(%rsp)
1400643e3:     	movq	0x90(%rax), %rax
1400643ea:     	movq	%rax, 0x3b0(%rsp)
1400643f2:     	movsd	%xmm0, 0x20(%rsp)
1400643f8:     	leaq	0x340(%rsp), %r14
140064400:     	movq	%r14, %r9
140064403:     	callq	0x14005f100 <_ZN2kp14CentreFriction10solveTwistERNS_10SolverBodyES2_RKNS0_5FrameEd>
140064408:     	movq	0x8(%rsi), %rax
14006440c:     	leaq	0x250(%rax), %rcx
140064413:     	movslq	(%rax), %rdx
140064416:     	movq	(%rdi), %r9
140064419:     	imulq	$0xb8, %rdx, %rdx
140064420:     	addq	%r9, %rdx
140064423:     	movslq	0x4(%rax), %r8
140064427:     	imulq	$0xb8, %r8, %r8
14006442e:     	addq	%r9, %r8
140064431:     	movq	0x30(%rax), %r9
140064435:     	movq	%r9, 0x350(%rsp)
14006443d:     	movups	0x20(%rax), %xmm0
140064441:     	movaps	%xmm0, 0x340(%rsp)
140064449:     	movq	0x48(%rax), %r9
14006444d:     	movq	%r9, 0x368(%rsp)
140064455:     	movups	0x38(%rax), %xmm0
140064459:     	movups	%xmm0, 0x358(%rsp)
140064461:     	movq	0x60(%rax), %r9
140064465:     	movq	%r9, 0x380(%rsp)
14006446d:     	movups	0x50(%rax), %xmm0
140064471:     	movaps	%xmm0, 0x370(%rsp)
140064479:     	movups	0x68(%rax), %xmm0
14006447d:     	movups	%xmm0, 0x388(%rsp)
140064485:     	movq	0x78(%rax), %r9
140064489:     	movq	%r9, 0x398(%rsp)
140064491:     	movupd	0x80(%rax), %xmm0
140064499:     	movapd	%xmm0, 0x3a0(%rsp)
1400644a2:     	movq	0x90(%rax), %rax
1400644a9:     	movq	%rax, 0x3b0(%rsp)
1400644b1:     	movsd	%xmm6, 0x20(%rsp)
1400644b7:     	movq	%r14, %r9
1400644ba:     	callq	0x14005f100 <_ZN2kp14CentreFriction10solveTwistERNS_10SolverBodyES2_RKNS0_5FrameEd>
1400644bf:     	leaq	0x340(%rsp), %rcx
1400644c7:     	movq	%rsi, 0x2d0(%rsp)
1400644cf:     	movq	%rsi, %rdx
1400644d2:     	callq	0x140063c20 <_ZNK2kp15CoupledFriction11tangentRowsEv>
1400644d7:     	xorpd	%xmm14, %xmm14
1400644dc:     	movapd	%xmm14, 0x1a0(%rsp)
1400644e6:     	movapd	%xmm14, 0x190(%rsp)
1400644f0:     	movapd	%xmm14, 0x180(%rsp)
1400644fa:     	movapd	%xmm14, 0x170(%rsp)
140064504:     	movapd	%xmm14, 0x160(%rsp)
14006450e:     	movapd	%xmm14, 0x150(%rsp)
140064518:     	movapd	%xmm14, 0x140(%rsp)
140064522:     	movapd	%xmm14, 0x130(%rsp)
14006452c:     	movapd	%xmm14, 0x120(%rsp)
140064536:     	movapd	%xmm14, 0x110(%rsp)
140064540:     	movq	(%rbx), %r9
140064543:     	movq	0x8(%rbx), %rsi
140064547:     	movabsq	$-0x30c30c30c30c30c3, %r14 # imm = 0xCF3CF3CF3CF3CF3D
140064551:     	movabsq	$0x666666666666666, %rax # imm = 0x666666666666666
14006455b:     	movabsq	$-0x3333333333333333, %r12 # imm = 0xCCCCCCCCCCCCCCCD
140064565:     	subq	%r9, %rsi
140064568:     	movq	%rbx, 0x248(%rsp)
140064570:     	je	0x14006460f <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x43f>
140064576:     	sarq	$0x3, %rsi
14006457a:     	imulq	%r14, %rsi
14006457e:     	cmpq	%rax, %rsi
140064581:     	ja	0x140066599 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x23c9>
140064587:     	movsd	%xmm8, 0x238(%rsp)
140064591:     	movl	%ebp, 0x5c(%rsp)
140064595:     	movsd	%xmm7, 0x240(%rsp)
14006459e:     	shlq	$0x3, %rsi
1400645a2:     	leaq	(%rsi,%rsi,4), %rcx
1400645a6:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
1400645ab:     	movq	%rax, %r15
1400645ae:     	leaq	(%rsi,%rsi,4), %rax
1400645b2:     	addq	$-0x28, %rax
1400645b6:     	mulq	%r12
1400645b9:     	shrq	$0x5, %rdx
1400645bd:     	leaq	(%rdx,%rdx,4), %rsi
1400645c1:     	leaq	0x28(,%rsi,8), %r8
1400645c9:     	movq	%r15, %rcx
1400645cc:     	xorl	%edx, %edx
1400645ce:     	callq	0x140073000 <memset>
1400645d3:     	leaq	(%r15,%rsi,8), %rax
1400645d7:     	addq	$0x28, %rax
1400645db:     	movq	%rax, 0x200(%rsp)
1400645e3:     	movq	(%rbx), %r9
1400645e6:     	movq	0x8(%rbx), %rax
1400645ea:     	subq	%r9, %rax
1400645ed:     	sete	0x1b0(%rsp)
1400645f5:     	sarq	$0x3, %rax
1400645f9:     	imulq	%r14, %rax
1400645fd:     	cmpq	$0x1, %rax
140064601:     	adcq	$0x0, %rax
140064605:     	movq	%rax, 0x1c0(%rsp)
14006460d:     	jmp	0x14006464a <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x47a>
14006460f:     	movsd	%xmm8, 0x238(%rsp)
140064619:     	movl	%ebp, 0x5c(%rsp)
14006461d:     	movsd	%xmm7, 0x240(%rsp)
140064626:     	xorl	%r15d, %r15d
140064629:     	movb	$0x1, 0x1b0(%rsp)
140064631:     	movl	$0x1, %eax
140064636:     	movq	%rax, 0x1c0(%rsp)
14006463e:     	movq	$0x0, 0x200(%rsp)
14006464a:     	movq	%rdi, 0x2c8(%rsp)
140064652:     	movq	(%rdi), %rax
140064655:     	movl	0x340(%rsp), %ecx
14006465c:     	movl	%ecx, 0x1d0(%rsp)
140064663:     	movl	0x344(%rsp), %ecx
14006466a:     	movl	%ecx, 0x2a0(%rsp)
140064671:     	movl	0x3e8(%rsp), %ecx
140064678:     	movl	%ecx, 0x290(%rsp)
14006467f:     	movl	0x3ec(%rsp), %ecx
140064686:     	movl	%ecx, 0x38(%rsp)
14006468a:     	movl	0x490(%rsp), %ecx
140064691:     	movl	%ecx, 0x2b0(%rsp)
140064698:     	movl	0x494(%rsp), %ecx
14006469f:     	movl	%ecx, 0x280(%rsp)
1400646a6:     	movl	0x538(%rsp), %ecx
1400646ad:     	movl	%ecx, 0x270(%rsp)
1400646b4:     	movl	0x53c(%rsp), %ecx
1400646bb:     	movl	%ecx, 0x260(%rsp)
1400646c2:     	xorl	%r14d, %r14d
1400646c5:     	movl	$0x40, %r8d
1400646cb:     	movl	$0x10, %ecx
1400646d0:     	movq	%r15, 0x210(%rsp)
1400646d8:     	movq	%r9, 0x100(%rsp)
1400646e0:     	jmp	0x1400647ad <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x5dd>
1400646e5:     	nopw	%cs:(%rax,%rax)
1400646f0:     	leaq	(%rsp,%r11), %rdx
1400646f4:     	addq	$0x340, %rdx            # imm = 0x340
1400646fb:     	addq	%rax, %rdi
1400646fe:     	addq	%rax, %r10
140064701:     	movsd	(%r10), %xmm0
140064706:     	subsd	(%rdi), %xmm0
14006470a:     	mulsd	0x8(%rdx), %xmm0
14006470f:     	movupd	0x8(%r10), %xmm1
140064715:     	movupd	0x8(%rdi), %xmm2
14006471a:     	subpd	%xmm2, %xmm1
14006471e:     	movupd	0x10(%rdx), %xmm2
140064723:     	mulpd	%xmm1, %xmm2
140064727:     	movupd	0x28(%rdx), %xmm1
14006472c:     	movupd	0x40(%rdx), %xmm3
140064731:     	addsd	%xmm2, %xmm0
140064735:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140064739:     	movsd	0x18(%r10), %xmm4
14006473f:     	mulsd	0x38(%rdx), %xmm4
140064744:     	addsd	%xmm0, %xmm2
140064748:     	movupd	0x20(%r10), %xmm0
14006474e:     	mulpd	%xmm3, %xmm0
140064752:     	addsd	%xmm0, %xmm4
140064756:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
14006475a:     	addsd	%xmm4, %xmm0
14006475e:     	addsd	%xmm2, %xmm0
140064762:     	movsd	0x18(%rdi), %xmm2
140064767:     	mulsd	0x20(%rdx), %xmm2
14006476c:     	movupd	0x20(%rdi), %xmm3
140064771:     	mulpd	%xmm1, %xmm3
140064775:     	addsd	%xmm3, %xmm2
140064779:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
14006477d:     	addsd	%xmm2, %xmm3
140064781:     	subsd	%xmm3, %xmm0
140064785:     	movsd	%xmm0, 0x190(%rsp,%r14,8)
14006478f:     	incq	%r14
140064792:     	movq	0x40(%rsp), %r15
140064797:     	addq	$0x8, %r15
14006479b:     	cmpq	$0x4, %r14
14006479f:     	movq	0x100(%rsp), %r9
1400647a7:     	je	0x140064f73 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xda3>
1400647ad:     	movq	%r15, 0x40(%rsp)
1400647b2:     	imulq	$0xa8, %r14, %r11
1400647b9:     	movslq	0x340(%rsp,%r11), %r12
1400647c1:     	movq	%r12, 0x60(%rsp)
1400647c6:     	movslq	0x344(%rsp,%r11), %r13
1400647ce:     	movq	%r13, 0x68(%rsp)
1400647d3:     	leaq	0x70(%rsp), %rsi
1400647d8:     	movupd	%xmm14, 0x80(%rsi)
1400647e1:     	movupd	%xmm14, 0x70(%rsi)
1400647e7:     	movupd	%xmm14, 0x60(%rsi)
1400647ed:     	movupd	%xmm14, 0x50(%rsi)
1400647f3:     	movupd	%xmm14, 0x40(%rsi)
1400647f9:     	movupd	%xmm14, 0x30(%rsi)
1400647ff:     	movupd	%xmm14, 0x20(%rsi)
140064805:     	movupd	%xmm14, 0x10(%rsi)
14006480b:     	movupd	%xmm14, (%rsi)
140064810:     	imulq	$0xb8, %r12, %rdi
140064817:     	imulq	$0xb8, %r13, %r10
14006481e:     	movsd	0x78(%rax,%rdi), %xmm2
140064824:     	movsd	0x358(%rsp,%r11), %xmm0
14006482e:     	movapd	%xmm2, %xmm1
140064832:     	mulsd	%xmm0, %xmm1
140064836:     	xorpd	%xmm3, %xmm3
14006483a:     	subsd	%xmm1, %xmm3
14006483e:     	movupd	0x348(%rsp,%r11), %xmm1
140064848:     	unpcklpd	%xmm2, %xmm2            # xmm2 = xmm2[0,0]
14006484c:     	mulpd	%xmm1, %xmm2
140064850:     	xorpd	%xmm4, %xmm4
140064854:     	subpd	%xmm2, %xmm4
140064858:     	movupd	%xmm4, 0x70(%rsp)
14006485e:     	movsd	%xmm3, 0x80(%rsp)
140064867:     	movsd	0x370(%rsp,%r11), %xmm5
140064871:     	movsd	0x70(%rax,%rdi), %xmm3
140064877:     	mulsd	%xmm5, %xmm3
14006487b:     	movupd	0x360(%rsp,%r11), %xmm2
140064885:     	movupd	0x30(%rax,%rdi), %xmm6
14006488b:     	movupd	0x40(%rax,%rdi), %xmm9
140064892:     	movupd	0x50(%rax,%rdi), %xmm4
140064898:     	movapd	%xmm2, %xmm10
14006489d:     	shufpd	$0x1, %xmm2, %xmm10     # xmm10 = xmm10[1],xmm2[0]
1400648a3:     	movapd	%xmm6, %xmm11
1400648a8:     	unpckhpd	%xmm9, %xmm11           # xmm11 = xmm11[1],xmm9[1]
1400648ad:     	mulpd	%xmm10, %xmm11
1400648b2:     	unpcklpd	%xmm4, %xmm6            # xmm6 = xmm6[0],xmm4[0]
1400648b6:     	mulpd	%xmm2, %xmm6
1400648ba:     	addpd	%xmm11, %xmm6
1400648bf:     	unpcklpd	%xmm5, %xmm5            # xmm5 = xmm5[0,0]
1400648c3:     	movsd	%xmm9, %xmm4            # xmm4 = xmm9[0],xmm4[1]
1400648c8:     	mulpd	%xmm5, %xmm4
1400648cc:     	movsd	0x60(%rax,%rdi), %xmm5
1400648d2:     	mulsd	%xmm2, %xmm5
1400648d6:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
1400648da:     	mulsd	0x68(%rax,%rdi), %xmm2
1400648e0:     	addpd	%xmm6, %xmm4
1400648e4:     	addsd	%xmm5, %xmm2
1400648e8:     	addsd	%xmm3, %xmm2
1400648ec:     	xorpd	%xmm3, %xmm3
1400648f0:     	subpd	%xmm4, %xmm3
1400648f4:     	xorpd	%xmm4, %xmm4
1400648f8:     	subsd	%xmm2, %xmm4
1400648fc:     	movupd	%xmm3, 0x88(%rsp)
140064905:     	movsd	%xmm4, 0x98(%rsp)
14006490e:     	cmpl	%r13d, %r12d
140064911:     	movsd	0x78(%rax,%r10), %xmm2
140064918:     	movapd	%xmm1, %xmm3
14006491c:     	mulsd	%xmm2, %xmm3
140064920:     	leaq	0xa0(%rsp), %rdx
140064928:     	cmoveq	%rsi, %rdx
14006492c:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140064930:     	leaq	0xa8(%rsp), %rsi
140064938:     	leaq	0x78(%rsp), %rbx
14006493d:     	cmoveq	%rbx, %rsi
140064941:     	mulsd	%xmm2, %xmm1
140064945:     	leaq	0xb0(%rsp), %r15
14006494d:     	leaq	0x80(%rsp), %rbx
140064955:     	cmoveq	%rbx, %r15
140064959:     	addsd	(%rdx), %xmm3
14006495d:     	addsd	(%rsi), %xmm1
140064961:     	mulsd	%xmm2, %xmm0
140064965:     	addsd	(%r15), %xmm0
14006496a:     	movsd	%xmm3, (%rdx)
14006496e:     	movsd	%xmm1, (%rsi)
140064972:     	movsd	%xmm0, (%r15)
140064977:     	movsd	0x378(%rsp,%r11), %xmm4
140064981:     	movsd	0x380(%rsp,%r11), %xmm3
14006498b:     	movsd	0x388(%rsp,%r11), %xmm0
140064995:     	movsd	0x30(%rax,%r10), %xmm1
14006499c:     	mulsd	%xmm4, %xmm1
1400649a0:     	movsd	0x38(%rax,%r10), %xmm2
1400649a7:     	mulsd	%xmm3, %xmm2
1400649ab:     	addsd	%xmm1, %xmm2
1400649af:     	movsd	0x40(%rax,%r10), %xmm1
1400649b6:     	mulsd	%xmm0, %xmm1
1400649ba:     	addsd	%xmm2, %xmm1
1400649be:     	movsd	0x48(%rax,%r10), %xmm2
1400649c5:     	mulsd	%xmm4, %xmm2
1400649c9:     	movsd	0x50(%rax,%r10), %xmm5
1400649d0:     	mulsd	%xmm3, %xmm5
1400649d4:     	addsd	%xmm2, %xmm5
1400649d8:     	movsd	0x58(%rax,%r10), %xmm2
1400649df:     	mulsd	%xmm0, %xmm2
1400649e3:     	mulsd	0x60(%rax,%r10), %xmm4
1400649ea:     	mulsd	0x68(%rax,%r10), %xmm3
1400649f1:     	addsd	%xmm5, %xmm2
1400649f5:     	addsd	%xmm4, %xmm3
1400649f9:     	mulsd	0x70(%rax,%r10), %xmm0
140064a00:     	addsd	%xmm3, %xmm0
140064a04:     	leaq	0xb8(%rsp), %rsi
140064a0c:     	leaq	0x88(%rsp), %rdx
140064a14:     	cmoveq	%rdx, %rsi
140064a18:     	leaq	0xc0(%rsp), %r15
140064a20:     	leaq	0x90(%rsp), %rdx
140064a28:     	cmoveq	%rdx, %r15
140064a2c:     	leaq	0xc8(%rsp), %rbp
140064a34:     	leaq	0x98(%rsp), %rdx
140064a3c:     	cmoveq	%rdx, %rbp
140064a40:     	addsd	(%rsi), %xmm1
140064a44:     	addsd	(%r15), %xmm2
140064a49:     	addsd	(%rbp), %xmm0
140064a4e:     	movl	0x1d0(%rsp), %ebx
140064a55:     	cmpl	%ebx, %r13d
140064a58:     	movl	$0x70, %edx
140064a5d:     	cmoveq	%r8, %rdx
140064a61:     	movsd	%xmm1, (%rsi)
140064a65:     	cmpl	%ebx, %r12d
140064a68:     	cmoveq	%rcx, %rdx
140064a6c:     	movl	0x2a0(%rsp), %ebx
140064a73:     	cmpl	%ebx, %r13d
140064a76:     	movl	$0x70, %esi
140064a7b:     	cmoveq	%r8, %rsi
140064a7f:     	movsd	%xmm2, (%r15)
140064a84:     	cmpl	%ebx, %r12d
140064a87:     	cmoveq	%rcx, %rsi
140064a8b:     	movsd	%xmm0, (%rbp)
140064a90:     	movsd	0x60(%rsp,%rsi), %xmm0
140064a96:     	movsd	0x68(%rsp,%rsi), %xmm1
140064a9c:     	movsd	0x70(%rsp,%rsi), %xmm2
140064aa2:     	subsd	0x60(%rsp,%rdx), %xmm0
140064aa8:     	subsd	0x68(%rsp,%rdx), %xmm1
140064aae:     	subsd	0x70(%rsp,%rdx), %xmm2
140064ab4:     	mulsd	0x348(%rsp), %xmm0
140064abd:     	mulsd	0x350(%rsp), %xmm1
140064ac6:     	addsd	%xmm0, %xmm1
140064aca:     	mulsd	0x358(%rsp), %xmm2
140064ad3:     	addsd	%xmm1, %xmm2
140064ad7:     	movsd	0x78(%rsp,%rsi), %xmm1
140064add:     	movsd	0x80(%rsp,%rsi), %xmm3
140064ae6:     	movsd	0x88(%rsp,%rsi), %xmm0
140064aef:     	mulsd	0x378(%rsp), %xmm1
140064af8:     	mulsd	0x380(%rsp), %xmm3
140064b01:     	mulsd	0x388(%rsp), %xmm0
140064b0a:     	addsd	%xmm1, %xmm3
140064b0e:     	addsd	%xmm3, %xmm0
140064b12:     	addsd	%xmm2, %xmm0
140064b16:     	movsd	0x78(%rsp,%rdx), %xmm1
140064b1c:     	movsd	0x80(%rsp,%rdx), %xmm2
140064b25:     	movsd	0x88(%rsp,%rdx), %xmm3
140064b2e:     	mulsd	0x360(%rsp), %xmm1
140064b37:     	mulsd	0x368(%rsp), %xmm2
140064b40:     	mulsd	0x370(%rsp), %xmm3
140064b49:     	movl	0x290(%rsp), %esi
140064b50:     	cmpl	%esi, %r13d
140064b53:     	movl	$0x70, %edx
140064b58:     	cmoveq	%r8, %rdx
140064b5c:     	addsd	%xmm1, %xmm2
140064b60:     	cmpl	%esi, %r12d
140064b63:     	cmoveq	%rcx, %rdx
140064b67:     	movl	0x38(%rsp), %ebx
140064b6b:     	cmpl	%ebx, %r13d
140064b6e:     	movl	$0x70, %esi
140064b73:     	cmoveq	%r8, %rsi
140064b77:     	addsd	%xmm2, %xmm3
140064b7b:     	cmpl	%ebx, %r12d
140064b7e:     	cmoveq	%rcx, %rsi
140064b82:     	subsd	%xmm3, %xmm0
140064b86:     	movsd	0x60(%rsp,%rsi), %xmm2
140064b8c:     	movsd	0x68(%rsp,%rsi), %xmm3
140064b92:     	movsd	0x70(%rsp,%rsi), %xmm1
140064b98:     	subsd	0x60(%rsp,%rdx), %xmm2
140064b9e:     	subsd	0x68(%rsp,%rdx), %xmm3
140064ba4:     	subsd	0x70(%rsp,%rdx), %xmm1
140064baa:     	mulsd	0x3f0(%rsp), %xmm2
140064bb3:     	movsd	%xmm0, 0x110(%rsp,%r14,8)
140064bbd:     	mulsd	0x3f8(%rsp), %xmm3
140064bc6:     	addsd	%xmm2, %xmm3
140064bca:     	mulsd	0x400(%rsp), %xmm1
140064bd3:     	addsd	%xmm3, %xmm1
140064bd7:     	movsd	0x78(%rsp,%rsi), %xmm2
140064bdd:     	movsd	0x80(%rsp,%rsi), %xmm3
140064be6:     	movsd	0x88(%rsp,%rsi), %xmm0
140064bef:     	mulsd	0x420(%rsp), %xmm2
140064bf8:     	mulsd	0x428(%rsp), %xmm3
140064c01:     	mulsd	0x430(%rsp), %xmm0
140064c0a:     	addsd	%xmm2, %xmm3
140064c0e:     	addsd	%xmm3, %xmm0
140064c12:     	addsd	%xmm1, %xmm0
140064c16:     	movsd	0x78(%rsp,%rdx), %xmm1
140064c1c:     	movsd	0x80(%rsp,%rdx), %xmm2
140064c25:     	movsd	0x88(%rsp,%rdx), %xmm3
140064c2e:     	mulsd	0x408(%rsp), %xmm1
140064c37:     	mulsd	0x410(%rsp), %xmm2
140064c40:     	mulsd	0x418(%rsp), %xmm3
140064c49:     	movl	0x2b0(%rsp), %esi
140064c50:     	cmpl	%esi, %r13d
140064c53:     	movl	$0x70, %edx
140064c58:     	cmoveq	%r8, %rdx
140064c5c:     	addsd	%xmm1, %xmm2
140064c60:     	cmpl	%esi, %r12d
140064c63:     	cmoveq	%rcx, %rdx
140064c67:     	movl	0x280(%rsp), %ebx
140064c6e:     	cmpl	%ebx, %r13d
140064c71:     	movl	$0x70, %esi
140064c76:     	cmoveq	%r8, %rsi
140064c7a:     	addsd	%xmm2, %xmm3
140064c7e:     	cmpl	%ebx, %r12d
140064c81:     	cmoveq	%rcx, %rsi
140064c85:     	subsd	%xmm3, %xmm0
140064c89:     	movsd	0x60(%rsp,%rsi), %xmm2
140064c8f:     	movsd	0x68(%rsp,%rsi), %xmm3
140064c95:     	movsd	0x70(%rsp,%rsi), %xmm1
140064c9b:     	subsd	0x60(%rsp,%rdx), %xmm2
140064ca1:     	subsd	0x68(%rsp,%rdx), %xmm3
140064ca7:     	subsd	0x70(%rsp,%rdx), %xmm1
140064cad:     	mulsd	0x498(%rsp), %xmm2
140064cb6:     	movsd	%xmm0, 0x130(%rsp,%r14,8)
140064cc0:     	mulsd	0x4a0(%rsp), %xmm3
140064cc9:     	addsd	%xmm2, %xmm3
140064ccd:     	mulsd	0x4a8(%rsp), %xmm1
140064cd6:     	addsd	%xmm3, %xmm1
140064cda:     	movsd	0x78(%rsp,%rsi), %xmm2
140064ce0:     	movsd	0x80(%rsp,%rsi), %xmm3
140064ce9:     	movsd	0x88(%rsp,%rsi), %xmm0
140064cf2:     	mulsd	0x4c8(%rsp), %xmm2
140064cfb:     	mulsd	0x4d0(%rsp), %xmm3
140064d04:     	mulsd	0x4d8(%rsp), %xmm0
140064d0d:     	addsd	%xmm2, %xmm3
140064d11:     	addsd	%xmm3, %xmm0
140064d15:     	addsd	%xmm1, %xmm0
140064d19:     	movsd	0x78(%rsp,%rdx), %xmm1
140064d1f:     	movsd	0x80(%rsp,%rdx), %xmm2
140064d28:     	movsd	0x88(%rsp,%rdx), %xmm3
140064d31:     	mulsd	0x4b0(%rsp), %xmm1
140064d3a:     	mulsd	0x4b8(%rsp), %xmm2
140064d43:     	mulsd	0x4c0(%rsp), %xmm3
140064d4c:     	movl	0x270(%rsp), %esi
140064d53:     	cmpl	%esi, %r13d
140064d56:     	movl	$0x70, %edx
140064d5b:     	cmoveq	%r8, %rdx
140064d5f:     	addsd	%xmm1, %xmm2
140064d63:     	cmpl	%esi, %r12d
140064d66:     	cmoveq	%rcx, %rdx
140064d6a:     	movl	0x260(%rsp), %ebx
140064d71:     	cmpl	%ebx, %r13d
140064d74:     	movl	$0x70, %esi
140064d79:     	cmoveq	%r8, %rsi
140064d7d:     	addsd	%xmm2, %xmm3
140064d81:     	cmpl	%ebx, %r12d
140064d84:     	cmoveq	%rcx, %rsi
140064d88:     	subsd	%xmm3, %xmm0
140064d8c:     	movsd	0x60(%rsp,%rsi), %xmm2
140064d92:     	movsd	0x68(%rsp,%rsi), %xmm3
140064d98:     	movsd	0x70(%rsp,%rsi), %xmm1
140064d9e:     	subsd	0x60(%rsp,%rdx), %xmm2
140064da4:     	subsd	0x68(%rsp,%rdx), %xmm3
140064daa:     	subsd	0x70(%rsp,%rdx), %xmm1
140064db0:     	mulsd	0x540(%rsp), %xmm2
140064db9:     	movsd	%xmm0, 0x150(%rsp,%r14,8)
140064dc3:     	mulsd	0x548(%rsp), %xmm3
140064dcc:     	addsd	%xmm2, %xmm3
140064dd0:     	mulsd	0x550(%rsp), %xmm1
140064dd9:     	addsd	%xmm3, %xmm1
140064ddd:     	movsd	0x78(%rsp,%rsi), %xmm0
140064de3:     	movsd	0x80(%rsp,%rsi), %xmm2
140064dec:     	movsd	0x88(%rsp,%rsi), %xmm3
140064df5:     	mulsd	0x570(%rsp), %xmm0
140064dfe:     	mulsd	0x578(%rsp), %xmm2
140064e07:     	mulsd	0x580(%rsp), %xmm3
140064e10:     	addsd	%xmm0, %xmm2
140064e14:     	addsd	%xmm2, %xmm3
140064e18:     	addsd	%xmm1, %xmm3
140064e1c:     	movsd	0x78(%rsp,%rdx), %xmm0
140064e22:     	movsd	0x80(%rsp,%rdx), %xmm1
140064e2b:     	movsd	0x88(%rsp,%rdx), %xmm2
140064e34:     	mulsd	0x558(%rsp), %xmm0
140064e3d:     	mulsd	0x560(%rsp), %xmm1
140064e46:     	mulsd	0x568(%rsp), %xmm2
140064e4f:     	addsd	%xmm0, %xmm1
140064e53:     	addsd	%xmm1, %xmm2
140064e57:     	subsd	%xmm2, %xmm3
140064e5b:     	movsd	%xmm3, 0x170(%rsp,%r14,8)
140064e65:     	movq	%r9, %rsi
140064e68:     	movq	0x40(%rsp), %rdx
140064e6d:     	movq	0x1c0(%rsp), %rbp
140064e75:     	cmpb	$0x0, 0x1b0(%rsp)
140064e7d:     	jne	0x1400646f0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x520>
140064e83:     	nopw	%cs:(%rax,%rax)
140064e90:     	movl	(%rsi), %r9d
140064e93:     	cmpl	%r9d, %r13d
140064e96:     	movl	$0x70, %r15d
140064e9c:     	cmoveq	%r8, %r15
140064ea0:     	movl	0x4(%rsi), %ebx
140064ea3:     	cmpl	%r9d, %r12d
140064ea6:     	cmoveq	%rcx, %r15
140064eaa:     	cmpl	%ebx, %r13d
140064ead:     	movl	$0x70, %r9d
140064eb3:     	cmoveq	%r8, %r9
140064eb7:     	cmpl	%ebx, %r12d
140064eba:     	cmoveq	%rcx, %r9
140064ebe:     	movsd	0x60(%rsp,%r9), %xmm0
140064ec5:     	subsd	0x60(%rsp,%r15), %xmm0
140064ecc:     	mulsd	0x8(%rsi), %xmm0
140064ed1:     	movupd	0x68(%rsp,%r9), %xmm1
140064ed8:     	movupd	0x68(%rsp,%r15), %xmm2
140064edf:     	subpd	%xmm2, %xmm1
140064ee3:     	movupd	0x10(%rsi), %xmm2
140064ee8:     	mulpd	%xmm1, %xmm2
140064eec:     	addsd	%xmm2, %xmm0
140064ef0:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140064ef4:     	addsd	%xmm0, %xmm2
140064ef8:     	movsd	0x78(%rsp,%r9), %xmm0
140064eff:     	mulsd	0x38(%rsi), %xmm0
140064f04:     	movupd	0x80(%rsp,%r9), %xmm1
140064f0e:     	movupd	0x40(%rsi), %xmm3
140064f13:     	mulpd	%xmm1, %xmm3
140064f17:     	addsd	%xmm3, %xmm0
140064f1b:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
140064f1f:     	addsd	%xmm0, %xmm3
140064f23:     	movsd	0x78(%rsp,%r15), %xmm0
140064f2a:     	mulsd	0x20(%rsi), %xmm0
140064f2f:     	addsd	%xmm2, %xmm3
140064f33:     	movupd	0x80(%rsp,%r15), %xmm1
140064f3d:     	movupd	0x28(%rsi), %xmm2
140064f42:     	mulpd	%xmm1, %xmm2
140064f46:     	addsd	%xmm2, %xmm0
140064f4a:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140064f4e:     	addsd	%xmm0, %xmm2
140064f52:     	subsd	%xmm2, %xmm3
140064f56:     	movsd	%xmm3, (%rdx)
140064f5a:     	addq	$0x28, %rdx
140064f5e:     	addq	$0xa8, %rsi
140064f65:     	decq	%rbp
140064f68:     	jne	0x140064e90 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xcc0>
140064f6e:     	jmp	0x1400646f0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x520>
140064f73:     	movq	0x248(%rsp), %rbx
140064f7b:     	movq	(%rbx), %rcx
140064f7e:     	movq	0x8(%rbx), %rdx
140064f82:     	subq	%rcx, %rdx
140064f85:     	movq	0x210(%rsp), %r14
140064f8d:     	movabsq	$-0x30c30c30c30c30c3, %r15 # imm = 0xCF3CF3CF3CF3CF3D
140064f97:     	movabsq	$-0x3333333333333333, %r11 # imm = 0xCCCCCCCCCCCCCCCD
140064fa1:     	movq	0x200(%rsp), %rsi
140064fa9:     	je	0x1400650a5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xed5>
140064faf:     	sarq	$0x3, %rdx
140064fb3:     	imulq	%r15, %rdx
140064fb7:     	leaq	0x20(%r14), %r8
140064fbb:     	jmp	0x14006508d <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xebd>
140064fc0:     	movslq	(%rcx), %r9
140064fc3:     	imulq	$0xb8, %r9, %r9
140064fca:     	movslq	0x4(%rcx), %r10
140064fce:     	imulq	$0xb8, %r10, %r10
140064fd5:     	movsd	(%rax,%r10), %xmm1
140064fdb:     	movsd	0x8(%rax,%r10), %xmm2
140064fe2:     	movsd	0x10(%rax,%r10), %xmm3
140064fe9:     	subsd	(%rax,%r9), %xmm1
140064fef:     	subsd	0x8(%rax,%r9), %xmm2
140064ff6:     	subsd	0x10(%rax,%r9), %xmm3
140064ffd:     	mulsd	0x8(%rcx), %xmm1
140065002:     	mulsd	0x10(%rcx), %xmm2
140065007:     	addsd	%xmm1, %xmm2
14006500b:     	mulsd	0x18(%rcx), %xmm3
140065010:     	addsd	%xmm2, %xmm3
140065014:     	movsd	0x18(%rax,%r10), %xmm1
14006501b:     	movsd	0x20(%rax,%r10), %xmm2
140065022:     	movsd	0x28(%rax,%r10), %xmm4
140065029:     	mulsd	0x38(%rcx), %xmm1
14006502e:     	mulsd	0x40(%rcx), %xmm2
140065033:     	mulsd	0x48(%rcx), %xmm4
140065038:     	addsd	%xmm1, %xmm2
14006503c:     	addsd	%xmm2, %xmm4
140065040:     	addsd	%xmm3, %xmm4
140065044:     	movsd	0x18(%rax,%r9), %xmm1
14006504b:     	movsd	0x20(%rax,%r9), %xmm2
140065052:     	movsd	0x28(%rax,%r9), %xmm3
140065059:     	mulsd	0x20(%rcx), %xmm1
14006505e:     	mulsd	0x28(%rcx), %xmm2
140065063:     	mulsd	0x30(%rcx), %xmm3
140065068:     	addsd	%xmm1, %xmm2
14006506c:     	addsd	%xmm2, %xmm3
140065070:     	subsd	%xmm3, %xmm4
140065074:     	subsd	%xmm0, %xmm4
140065078:     	movsd	%xmm4, (%r8)
14006507d:     	addq	$0x28, %r8
140065081:     	addq	$0xa8, %rcx
140065088:     	decq	%rdx
14006508b:     	je	0x1400650a5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xed5>
14006508d:     	xorpd	%xmm0, %xmm0
140065091:     	cmpb	$0x1, 0x60(%rcx)
140065095:     	jne	0x140064fc0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xdf0>
14006509b:     	movsd	0x68(%rcx), %xmm0
1400650a0:     	jmp	0x140064fc0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xdf0>
1400650a5:     	subq	%r14, %rsi
1400650a8:     	je	0x1400650e3 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xf13>
1400650aa:     	movq	%rsi, %rax
1400650ad:     	sarq	$0x3, %rax
1400650b1:     	imulq	%r11, %rax
1400650b5:     	movabsq	$0x666666666666666, %rcx # imm = 0x666666666666666
1400650bf:     	cmpq	%rcx, %rax
1400650c2:     	ja	0x14006659e <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x23ce>
1400650c8:     	movq	%rsi, %rcx
1400650cb:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
1400650d0:     	movq	%rax, %r12
1400650d3:     	movq	%rax, %rcx
1400650d6:     	movq	%r14, %rdx
1400650d9:     	movq	%rsi, %r8
1400650dc:     	callq	0x140073050 <memmove>
1400650e1:     	jmp	0x1400650e6 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xf16>
1400650e3:     	xorl	%r12d, %r12d
1400650e6:     	movq	0x38(%rbx), %rax
1400650ea:     	subq	0x30(%rbx), %rax
1400650ee:     	shrq	$0x2, %rax
1400650f2:     	testl	%eax, %eax
1400650f4:     	jle	0x140065380 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x11b0>
1400650fa:     	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
1400650ff:     	leaq	0x20(%r12), %rcx
140065104:     	xorl	%edx, %edx
140065106:     	jmp	0x14006516a <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xf9a>
140065108:     	nopl	(%rax,%rax)
140065110:     	movupd	(%r12,%r9,8), %xmm0
140065116:     	movupd	0x10(%r12,%r9,8), %xmm2
14006511d:     	movsd	0x20(%r12,%r9,8), %xmm1
140065124:     	movq	0x48(%rbx), %r10
140065128:     	movq	(%r10,%rdx,8), %r10
14006512c:     	shlq	$0x3, %r10
140065130:     	addq	0x60(%rbx), %r10
140065134:     	movsd	(%r10,%r8,8), %xmm3
14006513a:     	divsd	%xmm3, %xmm1
14006513e:     	unpcklpd	%xmm3, %xmm3            # xmm3 = xmm3[0,0]
140065142:     	divpd	%xmm3, %xmm0
140065146:     	divpd	%xmm3, %xmm2
14006514a:     	movupd	%xmm0, (%r12,%r9,8)
140065150:     	movupd	%xmm2, 0x10(%r12,%r9,8)
140065157:     	movsd	%xmm1, 0x20(%r12,%r9,8)
14006515e:     	incq	%rdx
140065161:     	cmpq	%rax, %rdx
140065164:     	je	0x140065234 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1064>
14006516a:     	movq	0x30(%rbx), %r8
14006516e:     	movslq	(%r8,%rdx,4), %r11
140065172:     	movq	%rdx, %r8
140065175:     	subq	%r11, %r8
140065178:     	jle	0x140065210 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1040>
14006517e:     	movq	0x48(%rbx), %r9
140065182:     	movq	(%r9,%rdx,8), %r9
140065186:     	shlq	$0x3, %r9
14006518a:     	addq	0x60(%rbx), %r9
14006518e:     	leaq	(%rdx,%rdx,4), %rsi
140065192:     	leaq	(%r12,%rsi,8), %r10
140065196:     	movupd	(%r12,%rsi,8), %xmm0
14006519c:     	movupd	0x10(%r12,%rsi,8), %xmm1
1400651a3:     	movsd	0x20(%r12,%rsi,8), %xmm2
1400651aa:     	leaq	(%r11,%r11,4), %r11
1400651ae:     	leaq	(%rcx,%r11,8), %r11
1400651b2:     	xorl	%esi, %esi
1400651b4:     	nopw	%cs:(%rax,%rax)
1400651c0:     	movsd	(%r9,%rsi,8), %xmm3
1400651c6:     	movsd	(%r11), %xmm4
1400651cb:     	mulsd	%xmm3, %xmm4
1400651cf:     	subsd	%xmm4, %xmm2
1400651d3:     	movupd	-0x20(%r11), %xmm4
1400651d9:     	unpcklpd	%xmm3, %xmm3            # xmm3 = xmm3[0,0]
1400651dd:     	mulpd	%xmm3, %xmm4
1400651e1:     	subpd	%xmm4, %xmm0
1400651e5:     	movupd	%xmm0, (%r10)
1400651ea:     	movupd	-0x10(%r11), %xmm4
1400651f0:     	mulpd	%xmm3, %xmm4
1400651f4:     	subpd	%xmm4, %xmm1
1400651f8:     	movupd	%xmm1, 0x10(%r10)
1400651fe:     	movsd	%xmm2, 0x20(%r10)
140065204:     	incq	%rsi
140065207:     	addq	$0x28, %r11
14006520b:     	cmpq	%rsi, %r8
14006520e:     	jne	0x1400651c0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xff0>
140065210:     	movq	0x78(%rbx), %r9
140065214:     	cmpb	$0x0, (%r9,%rdx)
140065219:     	leaq	(%rdx,%rdx,4), %r9
14006521d:     	je	0x140065110 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xf40>
140065223:     	xorpd	%xmm0, %xmm0
140065227:     	xorpd	%xmm1, %xmm1
14006522b:     	xorpd	%xmm2, %xmm2
14006522f:     	jmp	0x14006514a <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0xf7a>
140065234:     	leaq	-0x1(%rax), %rdx
140065238:     	jmp	0x14006524d <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x107d>
14006523a:     	nopw	(%rax,%rax)
140065240:     	decq	%rdx
140065243:     	cmpq	$0x2, %r8
140065247:     	jb	0x140065380 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x11b0>
14006524d:     	movq	%rax, %r8
140065250:     	decq	%rax
140065253:     	movq	0x78(%rbx), %r9
140065257:     	cmpb	$0x0, -0x1(%r9,%r8)
14006525d:     	leaq	(%rax,%rax,4), %r9
140065261:     	je	0x140065280 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x10b0>
140065263:     	xorpd	%xmm0, %xmm0
140065267:     	xorpd	%xmm1, %xmm1
14006526b:     	xorpd	%xmm2, %xmm2
14006526f:     	jmp	0x1400652c8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x10f8>
140065271:     	nopw	%cs:(%rax,%rax)
140065280:     	movupd	(%r12,%r9,8), %xmm0
140065286:     	movupd	0x10(%r12,%r9,8), %xmm2
14006528d:     	movsd	0x20(%r12,%r9,8), %xmm1
140065294:     	movq	0x30(%rbx), %r10
140065298:     	movq	0x48(%rbx), %r11
14006529c:     	movq	(%r11,%rax,8), %r11
1400652a0:     	movslq	(%r10,%rax,4), %r10
1400652a4:     	movq	%rax, %rsi
1400652a7:     	subq	%r10, %rsi
1400652aa:     	shlq	$0x3, %r11
1400652ae:     	addq	0x60(%rbx), %r11
1400652b2:     	movsd	(%r11,%rsi,8), %xmm3
1400652b8:     	divsd	%xmm3, %xmm1
1400652bc:     	unpcklpd	%xmm3, %xmm3            # xmm3 = xmm3[0,0]
1400652c0:     	divpd	%xmm3, %xmm0
1400652c4:     	divpd	%xmm3, %xmm2
1400652c8:     	movupd	%xmm0, (%r12,%r9,8)
1400652ce:     	movupd	%xmm2, 0x10(%r12,%r9,8)
1400652d5:     	movsd	%xmm1, 0x20(%r12,%r9,8)
1400652dc:     	movq	0x30(%rbx), %r10
1400652e0:     	movslq	(%r10,%rax,4), %rsi
1400652e4:     	cmpq	%rsi, %rax
1400652e7:     	jle	0x140065240 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1070>
1400652ed:     	leaq	(%r12,%r9,8), %r9
1400652f1:     	movq	0x48(%rbx), %r10
1400652f5:     	movq	(%r10,%rax,8), %r10
1400652f9:     	shlq	$0x3, %r10
1400652fd:     	addq	0x60(%rbx), %r10
140065301:     	movq	%rdx, %r11
140065304:     	subq	%rsi, %r11
140065307:     	leaq	(%rsi,%rsi,4), %rsi
14006530b:     	leaq	(%rcx,%rsi,8), %rsi
14006530f:     	xorl	%edi, %edi
140065311:     	nopw	%cs:(%rax,%rax)
140065320:     	movsd	(%r10,%rdi,8), %xmm0
140065326:     	movsd	0x20(%r9), %xmm1
14006532c:     	mulsd	%xmm0, %xmm1
140065330:     	unpcklpd	%xmm0, %xmm0            # xmm0 = xmm0[0,0]
140065334:     	movupd	(%r9), %xmm2
140065339:     	movupd	0x10(%r9), %xmm3
14006533f:     	mulpd	%xmm0, %xmm2
140065343:     	movupd	-0x20(%rsi), %xmm4
140065348:     	subpd	%xmm2, %xmm4
14006534c:     	movupd	-0x10(%rsi), %xmm2
140065351:     	mulpd	%xmm0, %xmm3
140065355:     	subpd	%xmm3, %xmm2
140065359:     	movupd	%xmm4, -0x20(%rsi)
14006535e:     	movupd	%xmm2, -0x10(%rsi)
140065363:     	movsd	(%rsi), %xmm0
140065367:     	subsd	%xmm1, %xmm0
14006536b:     	movsd	%xmm0, (%rsi)
14006536f:     	incq	%rdi
140065372:     	addq	$0x28, %rsi
140065376:     	cmpq	%rdi, %r11
140065379:     	jne	0x140065320 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1150>
14006537b:     	jmp	0x140065240 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1070>
140065380:     	movq	0x8(%rbx), %rax
140065384:     	subq	(%rbx), %rax
140065387:     	movapd	%xmm12, 0x320(%rsp)
140065391:     	je	0x140065547 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1377>
140065397:     	movapd	%xmm13, 0x40(%rsp)
14006539e:     	sarq	$0x3, %rax
1400653a2:     	imulq	%r15, %rax
1400653a6:     	movapd	0x110(%rsp), %xmm3
1400653af:     	movapd	0x120(%rsp), %xmm4
1400653b8:     	movapd	0x130(%rsp), %xmm5
1400653c1:     	movapd	0x140(%rsp), %xmm6
1400653ca:     	movapd	0x150(%rsp), %xmm0
1400653d3:     	movapd	0x160(%rsp), %xmm1
1400653dc:     	movapd	0x170(%rsp), %xmm2
1400653e5:     	movapd	0x190(%rsp), %xmm11
1400653ef:     	movapd	0x180(%rsp), %xmm9
1400653f9:     	movl	$0x10, %ecx
1400653fe:     	movapd	0x1a0(%rsp), %xmm10
140065408:     	nopl	(%rax,%rax)
140065410:     	movupd	-0x10(%r12,%rcx), %xmm14
140065417:     	movupd	(%r12,%rcx), %xmm12
14006541d:     	movupd	-0x10(%r14,%rcx), %xmm8
140065424:     	movupd	(%r14,%rcx), %xmm13
14006542a:     	movapd	%xmm8, %xmm7
14006542f:     	unpcklpd	%xmm8, %xmm7            # xmm7 = xmm7[0],xmm8[0]
140065434:     	movapd	%xmm7, %xmm15
140065439:     	mulpd	%xmm14, %xmm15
14006543e:     	subpd	%xmm15, %xmm3
140065443:     	mulpd	%xmm12, %xmm7
140065448:     	subpd	%xmm7, %xmm4
14006544c:     	movsd	0x10(%r12,%rcx), %xmm7
140065453:     	unpcklpd	%xmm7, %xmm7            # xmm7 = xmm7[0,0]
140065457:     	movapd	%xmm7, %xmm15
14006545c:     	mulpd	%xmm8, %xmm15
140065461:     	subpd	%xmm15, %xmm11
140065466:     	unpckhpd	%xmm8, %xmm8            # xmm8 = xmm8[1,1]
14006546b:     	movapd	%xmm14, %xmm15
140065470:     	mulpd	%xmm8, %xmm15
140065475:     	subpd	%xmm15, %xmm5
14006547a:     	mulpd	%xmm12, %xmm8
14006547f:     	subpd	%xmm8, %xmm6
140065484:     	movapd	%xmm13, %xmm8
140065489:     	unpcklpd	%xmm13, %xmm8           # xmm8 = xmm8[0],xmm13[0]
14006548e:     	movapd	%xmm14, %xmm15
140065493:     	mulpd	%xmm8, %xmm15
140065498:     	subpd	%xmm15, %xmm0
14006549d:     	mulpd	%xmm12, %xmm8
1400654a2:     	subpd	%xmm8, %xmm1
1400654a7:     	mulpd	%xmm13, %xmm7
1400654ac:     	subpd	%xmm7, %xmm10
1400654b1:     	unpckhpd	%xmm13, %xmm13          # xmm13 = xmm13[1,1]
1400654b6:     	mulpd	%xmm13, %xmm14
1400654bb:     	subpd	%xmm14, %xmm2
1400654c0:     	mulpd	%xmm12, %xmm13
1400654c5:     	subpd	%xmm13, %xmm9
1400654ca:     	addq	$0x28, %rcx
1400654ce:     	decq	%rax
1400654d1:     	jne	0x140065410 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1240>
1400654d7:     	movapd	%xmm3, 0x110(%rsp)
1400654e0:     	movapd	%xmm4, 0x120(%rsp)
1400654e9:     	movapd	%xmm5, 0x130(%rsp)
1400654f2:     	movapd	%xmm6, 0x140(%rsp)
1400654fb:     	movapd	%xmm11, 0x190(%rsp)
140065505:     	movapd	%xmm0, 0x150(%rsp)
14006550e:     	movapd	%xmm1, 0x160(%rsp)
140065517:     	movapd	%xmm2, 0x170(%rsp)
140065520:     	movapd	%xmm9, 0x180(%rsp)
14006552a:     	movapd	%xmm10, 0x1a0(%rsp)
140065534:     	movapd	0x40(%rsp), %xmm13
14006553b:     	movapd	0x320(%rsp), %xmm12
140065545:     	jmp	0x14006554c <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x137c>
140065547:     	testq	%r12, %r12
14006554a:     	je	0x140065554 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1384>
14006554c:     	movq	%r12, %rcx
14006554f:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140065554:     	testq	%r14, %r14
140065557:     	je	0x140065561 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1391>
140065559:     	movq	%r14, %rcx
14006555c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140065561:     	xorpd	%xmm0, %xmm0
140065565:     	movupd	%xmm0, 0x1e8(%rsp)
14006556e:     	movq	$0x0, 0x1f8(%rsp)
14006557a:     	movapd	%xmm0, 0x90(%rsp)
140065583:     	movapd	%xmm0, 0x80(%rsp)
14006558c:     	movapd	%xmm0, 0x70(%rsp)
140065592:     	movapd	%xmm0, 0x60(%rsp)
140065598:     	movq	$0x0, 0xa0(%rsp)
1400655a4:     	movsd	0x190(%rsp), %xmm3
1400655ad:     	movapd	0x120(%rsp), %xmm0
1400655b6:     	mulpd	%xmm13, %xmm0
1400655bb:     	movapd	0x110(%rsp), %xmm1
1400655c4:     	mulpd	%xmm12, %xmm1
1400655c9:     	xorpd	%xmm6, %xmm6
1400655cd:     	movapd	%xmm1, %xmm2
1400655d1:     	addsd	%xmm6, %xmm2
1400655d5:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
1400655d9:     	addsd	%xmm2, %xmm1
1400655dd:     	addsd	%xmm0, %xmm1
1400655e1:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
1400655e5:     	addsd	%xmm1, %xmm0
1400655e9:     	subsd	%xmm0, %xmm3
1400655ed:     	movapd	0x129bb(%rip), %xmm0    # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
1400655f5:     	movapd	%xmm3, 0x40(%rsp)
1400655fb:     	xorpd	%xmm3, %xmm0
1400655ff:     	movlpd	%xmm0, 0x1e0(%rsp)
140065608:     	leaq	0x60(%rsp), %rcx
14006560d:     	xorl	%edx, %edx
14006560f:     	callq	0x140049c90 <_ZN2kp13ProfileMatrix6addRowEi>
140065614:     	movq	0x60(%rsp), %rax
140065619:     	movq	0x78(%rsp), %rcx
14006561e:     	movq	(%rcx), %rcx
140065621:     	shlq	$0x3, %rcx
140065625:     	addq	0x90(%rsp), %rcx
14006562d:     	movslq	(%rax), %rax
140065630:     	movsd	0x110(%rsp), %xmm0
140065639:     	shlq	$0x3, %rax
14006563d:     	subq	%rax, %rcx
140065640:     	movsd	%xmm0, (%rcx)
140065644:     	movsd	0x198(%rsp), %xmm7
14006564d:     	movapd	0x140(%rsp), %xmm0
140065656:     	mulpd	%xmm13, %xmm0
14006565b:     	movapd	0x130(%rsp), %xmm1
140065664:     	mulpd	%xmm12, %xmm1
140065669:     	addsd	%xmm1, %xmm6
14006566d:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065671:     	addsd	%xmm6, %xmm1
140065675:     	addsd	%xmm0, %xmm1
140065679:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
14006567d:     	addsd	%xmm1, %xmm0
140065681:     	subsd	%xmm0, %xmm7
140065685:     	movapd	0x12923(%rip), %xmm0    # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
14006568d:     	xorpd	%xmm7, %xmm0
140065691:     	movlpd	%xmm0, 0x1e8(%rsp)
14006569a:     	leaq	0x60(%rsp), %rcx
14006569f:     	xorl	%edx, %edx
1400656a1:     	callq	0x140049c90 <_ZN2kp13ProfileMatrix6addRowEi>
1400656a6:     	movq	0x60(%rsp), %rax
1400656ab:     	movq	0x78(%rsp), %rcx
1400656b0:     	movq	0x8(%rcx), %rcx
1400656b4:     	shlq	$0x3, %rcx
1400656b8:     	addq	0x90(%rsp), %rcx
1400656c0:     	movslq	0x4(%rax), %rax
1400656c4:     	movsd	0x130(%rsp), %xmm0
1400656cd:     	leaq	(,%rax,8), %rdx
1400656d5:     	movq	%rcx, %r8
1400656d8:     	subq	%rdx, %r8
1400656db:     	movsd	%xmm0, (%r8)
1400656e0:     	movsd	0x138(%rsp), %xmm0
1400656e9:     	movl	$0x1, %esi
1400656ee:     	movl	$0x1, %edx
1400656f3:     	subq	%rax, %rdx
1400656f6:     	movsd	%xmm0, (%rcx,%rdx,8)
1400656fb:     	movsd	0x1a0(%rsp), %xmm3
140065704:     	movapd	0x160(%rsp), %xmm0
14006570d:     	mulpd	%xmm13, %xmm0
140065712:     	movapd	0x150(%rsp), %xmm1
14006571b:     	mulpd	%xmm12, %xmm1
140065720:     	xorpd	%xmm6, %xmm6
140065724:     	movapd	%xmm1, %xmm2
140065728:     	addsd	%xmm6, %xmm2
14006572c:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065730:     	addsd	%xmm2, %xmm1
140065734:     	addsd	%xmm0, %xmm1
140065738:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
14006573c:     	addsd	%xmm1, %xmm0
140065740:     	subsd	%xmm0, %xmm3
140065744:     	movapd	0x12864(%rip), %xmm0    # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
14006574c:     	movapd	%xmm3, 0x100(%rsp)
140065755:     	xorpd	%xmm3, %xmm0
140065759:     	movlpd	%xmm0, 0x1f0(%rsp)
140065762:     	leaq	0x60(%rsp), %rcx
140065767:     	xorl	%edx, %edx
140065769:     	callq	0x140049c90 <_ZN2kp13ProfileMatrix6addRowEi>
14006576e:     	movq	0x60(%rsp), %rax
140065773:     	movq	0x78(%rsp), %rcx
140065778:     	movq	0x10(%rcx), %rcx
14006577c:     	movslq	0x8(%rax), %rax
140065780:     	shlq	$0x3, %rcx
140065784:     	addq	0x90(%rsp), %rcx
14006578c:     	movsd	0x150(%rsp), %xmm0
140065795:     	leaq	(,%rax,8), %rdx
14006579d:     	movq	%rcx, %r8
1400657a0:     	subq	%rdx, %r8
1400657a3:     	movsd	%xmm0, (%r8)
1400657a8:     	movsd	0x158(%rsp), %xmm0
1400657b1:     	subq	%rax, %rsi
1400657b4:     	movsd	%xmm0, (%rcx,%rsi,8)
1400657b9:     	movsd	0x160(%rsp), %xmm0
1400657c2:     	movl	$0x2, %esi
1400657c7:     	movl	$0x2, %edx
1400657cc:     	subq	%rax, %rdx
1400657cf:     	movsd	%xmm0, (%rcx,%rdx,8)
1400657d4:     	movsd	0x1a8(%rsp), %xmm8
1400657de:     	movapd	0x180(%rsp), %xmm0
1400657e7:     	mulpd	%xmm13, %xmm0
1400657ec:     	movapd	0x170(%rsp), %xmm1
1400657f5:     	mulpd	%xmm12, %xmm1
1400657fa:     	addsd	%xmm1, %xmm6
1400657fe:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065802:     	addsd	%xmm6, %xmm1
140065806:     	addsd	%xmm0, %xmm1
14006580a:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
14006580e:     	addsd	%xmm1, %xmm0
140065812:     	subsd	%xmm0, %xmm8
140065817:     	movapd	0x12791(%rip), %xmm0    # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
14006581f:     	xorpd	%xmm8, %xmm0
140065824:     	movlpd	%xmm0, 0x1f8(%rsp)
14006582d:     	leaq	0x60(%rsp), %rcx
140065832:     	xorl	%edx, %edx
140065834:     	callq	0x140049c90 <_ZN2kp13ProfileMatrix6addRowEi>
140065839:     	movq	0x60(%rsp), %rax
14006583e:     	movq	0x78(%rsp), %rcx
140065843:     	movq	0x18(%rcx), %rcx
140065847:     	movslq	0xc(%rax), %rax
14006584b:     	shlq	$0x3, %rcx
14006584f:     	addq	0x90(%rsp), %rcx
140065857:     	movsd	0x170(%rsp), %xmm0
140065860:     	leaq	(,%rax,8), %rdx
140065868:     	movq	%rcx, %r8
14006586b:     	subq	%rdx, %r8
14006586e:     	movsd	%xmm0, (%r8)
140065873:     	movsd	0x178(%rsp), %xmm0
14006587c:     	movl	$0x1, %edx
140065881:     	subq	%rax, %rdx
140065884:     	movsd	%xmm0, (%rcx,%rdx,8)
140065889:     	movsd	0x180(%rsp), %xmm0
140065892:     	subq	%rax, %rsi
140065895:     	movsd	%xmm0, (%rcx,%rsi,8)
14006589a:     	movsd	0x188(%rsp), %xmm0
1400658a3:     	movl	$0x3, %edx
1400658a8:     	subq	%rax, %rdx
1400658ab:     	movsd	%xmm0, (%rcx,%rdx,8)
1400658b0:     	movl	0x1b78a(%rip), %eax     # 0x140081040 <_tls_index>
1400658b6:     	movq	%gs:0x58, %rcx
1400658bf:     	movq	(%rcx,%rax,8), %rax
1400658c3:     	cmpb	$0x0, 0xd0(%rax)
1400658ca:     	je	0x140066549 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x2379>
1400658d0:     	movapd	%xmm13, %xmm14
1400658d5:     	movapd	%xmm8, 0x5e0(%rsp)
1400658df:     	movapd	%xmm7, %xmm8
1400658e4:     	movl	0x1b756(%rip), %eax     # 0x140081040 <_tls_index>
1400658ea:     	movq	%gs:0x58, %rcx
1400658f3:     	movq	(%rcx,%rax,8), %rax
1400658f7:     	leaq	0x100(%rax), %r14
1400658fe:     	leaq	0x60(%rsp), %rcx
140065903:     	movsd	0x126b5(%rip), %xmm2    # 0x140077fc0 <_ZTSN2kp6SphereE+0x128>
14006590b:     	movq	%r14, %rdx
14006590e:     	callq	0x1400633a0 <_ZN2kp14factorCholeskyINSt3__16vectorIcNS1_9allocatorIcEEEEEEvRNS_13ProfileMatrixERT_d>
140065913:     	leaq	0x60(%rsp), %rcx
140065918:     	leaq	0x1e0(%rsp), %r8
140065920:     	movq	%r14, %rdx
140065923:     	callq	0x140066600 <_ZN2kp13solveFactoredINSt3__16vectorIcNS1_9allocatorIcEEEENS1_5arrayIdLy4EEEEEvRKNS_13ProfileMatrixERKT_RT0_>
140065928:     	movaps	0x140(%rsp), %xmm0
140065930:     	movaps	%xmm0, 0x270(%rsp)
140065938:     	movaps	0x130(%rsp), %xmm0
140065940:     	movaps	%xmm0, 0x260(%rsp)
140065948:     	movaps	0x120(%rsp), %xmm0
140065950:     	movaps	%xmm0, 0x280(%rsp)
140065958:     	movaps	0x110(%rsp), %xmm0
140065960:     	movaps	%xmm0, 0x1c0(%rsp)
140065968:     	movsd	0x148(%rsp), %xmm0
140065971:     	movsd	0x138(%rsp), %xmm3
14006597a:     	movsd	0x128(%rsp), %xmm1
140065983:     	movsd	0x118(%rsp), %xmm4
14006598c:     	movapd	0x1e0(%rsp), %xmm10
140065996:     	movapd	0x1f0(%rsp), %xmm6
14006599f:     	movapd	%xmm10, %xmm2
1400659a4:     	mulpd	%xmm10, %xmm2
1400659a9:     	movapd	%xmm6, %xmm5
1400659ad:     	mulpd	%xmm6, %xmm5
1400659b1:     	movapd	%xmm2, %xmm7
1400659b5:     	unpcklpd	%xmm5, %xmm7            # xmm7 = xmm7[0],xmm5[0]
1400659b9:     	movhlps	%xmm2, %xmm5            # xmm5 = xmm2[1],xmm5[1]
1400659bc:     	addpd	%xmm7, %xmm5
1400659c0:     	sqrtpd	%xmm5, %xmm11
1400659c5:     	movapd	0x220(%rsp), %xmm5
1400659ce:     	unpcklpd	0x250(%rsp), %xmm5      # xmm5 = xmm5[0],mem[0]
1400659d7:     	movapd	%xmm5, %xmm2
1400659db:     	divpd	%xmm11, %xmm2
1400659e0:     	movapd	%xmm5, 0x2a0(%rsp)
1400659e9:     	cmpnlepd	%xmm5, %xmm11
1400659ef:     	movapd	%xmm2, %xmm5
1400659f3:     	unpcklpd	%xmm2, %xmm5            # xmm5 = xmm5[0],xmm2[0]
1400659f7:     	mulpd	%xmm10, %xmm5
1400659fc:     	movapd	%xmm11, %xmm9
140065a01:     	unpcklpd	%xmm11, %xmm9           # xmm9 = xmm9[0],xmm11[0]
140065a06:     	andpd	%xmm9, %xmm5
140065a0b:     	andnpd	%xmm10, %xmm9
140065a10:     	orpd	%xmm5, %xmm9
140065a15:     	xorl	%eax, %eax
140065a17:     	ucomisd	0x1e0(%rsp), %xmm9
140065a21:     	movaps	0x180(%rsp), %xmm5
140065a29:     	movaps	%xmm5, 0x210(%rsp)
140065a31:     	movaps	0x170(%rsp), %xmm5
140065a39:     	movaps	%xmm5, 0x200(%rsp)
140065a41:     	movaps	0x160(%rsp), %xmm5
140065a49:     	movaps	%xmm5, 0x1b0(%rsp)
140065a51:     	movaps	0x150(%rsp), %xmm5
140065a59:     	movaps	%xmm5, 0x1d0(%rsp)
140065a61:     	movsd	0x188(%rsp), %xmm15
140065a6b:     	movsd	0x178(%rsp), %xmm13
140065a75:     	movsd	0x168(%rsp), %xmm5
140065a7e:     	movsd	0x158(%rsp), %xmm12
140065a88:     	movq	0x2d0(%rsp), %rsi
140065a90:     	jne	0x140065af5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1925>
140065a92:     	jp	0x140065af5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1925>
140065a94:     	pshufd	$0xee, %xmm9, %xmm7     # xmm7 = xmm9[2,3,2,3]
140065a9a:     	ucomisd	0x1e8(%rsp), %xmm7
140065aa3:     	jne	0x140065af5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1925>
140065aa5:     	jp	0x140065af5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1925>
140065aa7:     	movapd	%xmm14, %xmm7
140065aac:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140065ab0:     	mulpd	%xmm6, %xmm2
140065ab4:     	unpckhpd	%xmm11, %xmm11          # xmm11 = xmm11[1,1]
140065ab9:     	andpd	%xmm11, %xmm2
140065abe:     	andnpd	%xmm6, %xmm11
140065ac3:     	orpd	%xmm2, %xmm11
140065ac8:     	ucomisd	0x1f0(%rsp), %xmm11
140065ad2:     	movapd	%xmm8, %xmm9
140065ad7:     	jne	0x140065aff <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x192f>
140065ad9:     	jp	0x140065aff <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x192f>
140065adb:     	unpckhpd	%xmm11, %xmm11          # xmm11 = xmm11[1,1]
140065ae0:     	cmpeqsd	0x1f8(%rsp), %xmm11
140065aeb:     	movq	%xmm11, %rax
140065af0:     	andl	$0x1, %eax
140065af3:     	jmp	0x140065aff <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x192f>
140065af5:     	movapd	%xmm14, %xmm7
140065afa:     	movapd	%xmm8, %xmm9
140065aff:     	movapd	0x124c8(%rip), %xmm11   # 0x140077fd0 <_ZTSN2kp6SphereE+0x138>
140065b08:     	movapd	0x200(%rsp), %xmm2
140065b11:     	andpd	%xmm11, %xmm2
140065b16:     	andpd	%xmm11, %xmm13
140065b1b:     	addsd	%xmm2, %xmm13
140065b20:     	movapd	0x210(%rsp), %xmm2
140065b29:     	andpd	%xmm11, %xmm2
140065b2e:     	addsd	%xmm13, %xmm2
140065b33:     	andpd	%xmm11, %xmm15
140065b38:     	addsd	%xmm2, %xmm15
140065b3d:     	movapd	0x1c0(%rsp), %xmm2
140065b46:     	andpd	%xmm11, %xmm2
140065b4b:     	andpd	%xmm11, %xmm4
140065b50:     	addsd	%xmm2, %xmm4
140065b54:     	movapd	0x280(%rsp), %xmm2
140065b5d:     	andpd	%xmm11, %xmm2
140065b62:     	addsd	%xmm4, %xmm2
140065b66:     	andpd	%xmm11, %xmm1
140065b6b:     	addsd	%xmm2, %xmm1
140065b6f:     	movapd	0x260(%rsp), %xmm2
140065b78:     	andpd	%xmm11, %xmm2
140065b7d:     	andpd	%xmm11, %xmm3
140065b82:     	addsd	%xmm2, %xmm3
140065b86:     	movapd	0x270(%rsp), %xmm2
140065b8f:     	andpd	%xmm11, %xmm2
140065b94:     	addsd	%xmm3, %xmm2
140065b98:     	xorpd	%xmm8, %xmm8
140065b9d:     	maxsd	%xmm8, %xmm1
140065ba2:     	andpd	%xmm11, %xmm0
140065ba7:     	addsd	%xmm2, %xmm0
140065bab:     	maxsd	%xmm1, %xmm0
140065baf:     	movapd	0x1d0(%rsp), %xmm1
140065bb8:     	andpd	%xmm11, %xmm1
140065bbd:     	andpd	%xmm11, %xmm12
140065bc2:     	addsd	%xmm1, %xmm12
140065bc7:     	movapd	0x1b0(%rsp), %xmm1
140065bd0:     	andpd	%xmm11, %xmm1
140065bd5:     	addsd	%xmm12, %xmm1
140065bda:     	andpd	%xmm11, %xmm5
140065bdf:     	addsd	%xmm1, %xmm5
140065be3:     	maxsd	%xmm0, %xmm5
140065be7:     	maxsd	%xmm5, %xmm15
140065bec:     	movapd	0x220(%rsp), %xmm0
140065bf5:     	addsd	0x250(%rsp), %xmm0
140065bfe:     	movapd	%xmm15, 0x290(%rsp)
140065c08:     	mulsd	%xmm15, %xmm0
140065c0d:     	movapd	0x40(%rsp), %xmm1
140065c13:     	mulsd	%xmm1, %xmm1
140065c17:     	movapd	%xmm9, %xmm14
140065c1c:     	mulsd	%xmm9, %xmm14
140065c21:     	addsd	%xmm1, %xmm14
140065c26:     	movapd	0x100(%rsp), %xmm15
140065c30:     	mulsd	%xmm15, %xmm15
140065c35:     	movapd	%xmm14, %xmm1
140065c3a:     	addsd	%xmm15, %xmm1
140065c3f:     	movapd	0x5e0(%rsp), %xmm13
140065c49:     	movapd	%xmm13, %xmm12
140065c4e:     	mulsd	%xmm13, %xmm12
140065c53:     	addsd	%xmm12, %xmm1
140065c58:     	sqrtsd	%xmm1, %xmm1
140065c5c:     	addsd	%xmm0, %xmm1
140065c60:     	mulsd	0x12378(%rip), %xmm1    # 0x140077fe0 <_ZTSN2kp6SphereE+0x148>
140065c68:     	movsd	%xmm1, 0x38(%rsp)
140065c6e:     	testb	%al, %al
140065c70:     	je	0x140065dc8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1bf8>
140065c76:     	movapd	0x120(%rsp), %xmm0
140065c7f:     	mulpd	%xmm6, %xmm0
140065c83:     	movapd	0x110(%rsp), %xmm1
140065c8c:     	mulpd	%xmm10, %xmm1
140065c91:     	movapd	%xmm1, %xmm2
140065c95:     	addsd	%xmm8, %xmm2
140065c9a:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065c9e:     	addsd	%xmm2, %xmm1
140065ca2:     	addsd	%xmm0, %xmm1
140065ca6:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
140065caa:     	addsd	%xmm1, %xmm0
140065cae:     	addsd	0x40(%rsp), %xmm0
140065cb4:     	andpd	0x12314(%rip), %xmm0    # 0x140077fd0 <_ZTSN2kp6SphereE+0x138>
140065cbc:     	movsd	0x38(%rsp), %xmm1
140065cc2:     	ucomisd	%xmm0, %xmm1
140065cc6:     	jb	0x140065dc8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1bf8>
140065ccc:     	movapd	0x140(%rsp), %xmm1
140065cd5:     	mulpd	%xmm6, %xmm1
140065cd9:     	movapd	0x130(%rsp), %xmm2
140065ce2:     	mulpd	%xmm10, %xmm2
140065ce7:     	xorpd	%xmm0, %xmm0
140065ceb:     	movapd	%xmm2, %xmm3
140065cef:     	addsd	%xmm0, %xmm3
140065cf3:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140065cf7:     	addsd	%xmm3, %xmm2
140065cfb:     	addsd	%xmm1, %xmm2
140065cff:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065d03:     	addsd	%xmm2, %xmm1
140065d07:     	addsd	%xmm9, %xmm1
140065d0c:     	andpd	0x122bc(%rip), %xmm1    # 0x140077fd0 <_ZTSN2kp6SphereE+0x138>
140065d14:     	movsd	0x38(%rsp), %xmm2
140065d1a:     	ucomisd	%xmm1, %xmm2
140065d1e:     	jb	0x140065dc8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1bf8>
140065d24:     	movapd	0x160(%rsp), %xmm1
140065d2d:     	mulpd	%xmm6, %xmm1
140065d31:     	movapd	0x150(%rsp), %xmm2
140065d3a:     	mulpd	%xmm10, %xmm2
140065d3f:     	addsd	%xmm2, %xmm0
140065d43:     	unpckhpd	%xmm2, %xmm2            # xmm2 = xmm2[1,1]
140065d47:     	addsd	%xmm0, %xmm2
140065d4b:     	addsd	%xmm1, %xmm2
140065d4f:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065d53:     	addsd	%xmm2, %xmm1
140065d57:     	addsd	0x100(%rsp), %xmm1
140065d60:     	andpd	0x12268(%rip), %xmm1    # 0x140077fd0 <_ZTSN2kp6SphereE+0x138>
140065d68:     	movsd	0x38(%rsp), %xmm0
140065d6e:     	ucomisd	%xmm1, %xmm0
140065d72:     	jb	0x140065dc8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1bf8>
140065d74:     	movapd	0x180(%rsp), %xmm0
140065d7d:     	mulpd	%xmm6, %xmm0
140065d81:     	movapd	0x170(%rsp), %xmm1
140065d8a:     	mulpd	%xmm10, %xmm1
140065d8f:     	xorpd	%xmm2, %xmm2
140065d93:     	addsd	%xmm1, %xmm2
140065d97:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
140065d9b:     	addsd	%xmm2, %xmm1
140065d9f:     	addsd	%xmm0, %xmm1
140065da3:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
140065da7:     	addsd	%xmm1, %xmm0
140065dab:     	addsd	%xmm13, %xmm0
140065db0:     	andpd	0x12218(%rip), %xmm0    # 0x140077fd0 <_ZTSN2kp6SphereE+0x138>
140065db8:     	movsd	0x38(%rsp), %xmm1
140065dbe:     	ucomisd	%xmm0, %xmm1
140065dc2:     	jae	0x1400661db <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x200b>
140065dc8:     	movapd	0x320(%rsp), %xmm4
140065dd1:     	movapd	%xmm4, %xmm0
140065dd5:     	mulpd	%xmm4, %xmm0
140065dd9:     	movapd	%xmm7, %xmm1
140065ddd:     	mulpd	%xmm7, %xmm1
140065de1:     	movapd	%xmm0, %xmm2
140065de5:     	unpcklpd	%xmm1, %xmm2            # xmm2 = xmm2[0],xmm1[0]
140065de9:     	movhlps	%xmm0, %xmm1            # xmm1 = xmm0[1],xmm1[1]
140065dec:     	addpd	%xmm2, %xmm1
140065df0:     	sqrtpd	%xmm1, %xmm6
140065df4:     	movapd	0x2a0(%rsp), %xmm1
140065dfd:     	movapd	%xmm1, %xmm0
140065e01:     	divpd	%xmm6, %xmm0
140065e05:     	cmpnlepd	%xmm1, %xmm6
140065e0a:     	movapd	%xmm6, %xmm10
140065e0f:     	unpcklpd	%xmm6, %xmm10           # xmm10 = xmm10[0],xmm6[0]
140065e14:     	movapd	%xmm0, %xmm1
140065e18:     	unpcklpd	%xmm0, %xmm1            # xmm1 = xmm1[0],xmm0[0]
140065e1c:     	mulpd	%xmm4, %xmm1
140065e20:     	andpd	%xmm10, %xmm1
140065e25:     	andnpd	%xmm4, %xmm10
140065e2a:     	orpd	%xmm1, %xmm10
140065e2f:     	unpckhpd	%xmm0, %xmm0            # xmm0 = xmm0[1,1]
140065e33:     	mulpd	%xmm7, %xmm0
140065e37:     	unpckhpd	%xmm6, %xmm6            # xmm6 = xmm6[1,1]
140065e3b:     	andpd	%xmm6, %xmm0
140065e3f:     	andnpd	%xmm7, %xmm6
140065e43:     	orpd	%xmm0, %xmm6
140065e47:     	movapd	0x290(%rsp), %xmm5
140065e50:     	ucomisd	%xmm8, %xmm5
140065e55:     	jne	0x140065e89 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1cb9>
140065e57:     	jp	0x140065e89 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1cb9>
140065e59:     	xorpd	%xmm0, %xmm0
140065e5d:     	ucomisd	%xmm0, %xmm14
140065e62:     	jne	0x140066165 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1f95>
140065e68:     	jp	0x140066165 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1f95>
140065e6e:     	addsd	%xmm12, %xmm15
140065e73:     	ucomisd	%xmm0, %xmm15
140065e78:     	jne	0x1400661a8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1fd8>
140065e7e:     	jnp	0x1400661db <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x200b>
140065e84:     	jmp	0x1400661a8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1fd8>
140065e89:     	movdqa	0x1c0(%rsp), %xmm8
140065e93:     	movdqa	%xmm8, %xmm1
140065e98:     	movdqa	0x260(%rsp), %xmm0
140065ea1:     	punpcklqdq	%xmm0, %xmm1    # xmm1 = xmm1[0],xmm0[0]
140065ea5:     	movdqa	%xmm1, 0x2b0(%rsp)
140065eae:     	punpckhqdq	%xmm0, %xmm8    # xmm8 = xmm8[1],xmm0[1]
140065eb3:     	movdqa	%xmm8, 0x1c0(%rsp)
140065ebd:     	movapd	0x1d0(%rsp), %xmm0
140065ec6:     	movapd	%xmm0, %xmm15
140065ecb:     	movapd	0x200(%rsp), %xmm1
140065ed4:     	unpcklpd	%xmm1, %xmm15           # xmm15 = xmm15[0],xmm1[0]
140065ed9:     	unpckhpd	%xmm1, %xmm0            # xmm0 = xmm0[1],xmm1[1]
140065edd:     	movapd	%xmm0, 0x1d0(%rsp)
140065ee6:     	movapd	0x1b0(%rsp), %xmm0
140065eef:     	movapd	%xmm0, %xmm14
140065ef4:     	movapd	0x210(%rsp), %xmm1
140065efd:     	unpcklpd	%xmm1, %xmm14           # xmm14 = xmm14[0],xmm1[0]
140065f02:     	unpckhpd	%xmm1, %xmm0            # xmm0 = xmm0[1],xmm1[1]
140065f06:     	movapd	%xmm0, 0x1b0(%rsp)
140065f0f:     	movapd	0x280(%rsp), %xmm12
140065f19:     	movapd	%xmm12, %xmm0
140065f1e:     	movapd	0x270(%rsp), %xmm1
140065f27:     	unpcklpd	%xmm1, %xmm0            # xmm0 = xmm0[0],xmm1[0]
140065f2b:     	unpckhpd	%xmm1, %xmm12           # xmm12 = xmm12[1],xmm1[1]
140065f30:     	movapd	0x40(%rsp), %xmm1
140065f36:     	unpcklpd	%xmm9, %xmm1            # xmm1 = xmm1[0],xmm9[0]
140065f3b:     	movapd	%xmm1, 0x40(%rsp)
140065f41:     	unpcklpd	%xmm5, %xmm5            # xmm5 = xmm5[0,0]
140065f45:     	movapd	0x100(%rsp), %xmm1
140065f4e:     	unpcklpd	%xmm13, %xmm1           # xmm1 = xmm1[0],xmm13[0]
140065f53:     	movapd	%xmm1, 0x100(%rsp)
140065f5c:     	movl	$0x7f, %eax
140065f61:     	xorpd	%xmm1, %xmm1
140065f65:     	nopw	%cs:(%rax,%rax)
140065f70:     	movapd	%xmm10, %xmm9
140065f75:     	movapd	%xmm6, %xmm2
140065f79:     	movapd	%xmm10, %xmm6
140065f7e:     	unpcklpd	%xmm10, %xmm6           # xmm6 = xmm6[0],xmm10[0]
140065f83:     	movapd	0x2b0(%rsp), %xmm3
140065f8c:     	mulpd	%xmm6, %xmm3
140065f90:     	movapd	%xmm10, %xmm4
140065f95:     	unpckhpd	%xmm10, %xmm4           # xmm4 = xmm4[1],xmm10[1]
140065f9a:     	movapd	0x1c0(%rsp), %xmm7
140065fa3:     	mulpd	%xmm4, %xmm7
140065fa7:     	mulpd	%xmm15, %xmm6
140065fac:     	mulpd	0x1d0(%rsp), %xmm4
140065fb5:     	movapd	%xmm2, %xmm8
140065fba:     	unpcklpd	%xmm2, %xmm8            # xmm8 = xmm8[0],xmm2[0]
140065fbf:     	movapd	%xmm14, %xmm10
140065fc4:     	mulpd	%xmm8, %xmm10
140065fc9:     	addpd	%xmm1, %xmm3
140065fcd:     	addpd	%xmm7, %xmm3
140065fd1:     	movapd	%xmm2, %xmm7
140065fd5:     	unpckhpd	%xmm2, %xmm7            # xmm7 = xmm7[1],xmm2[1]
140065fd9:     	mulpd	%xmm0, %xmm8
140065fde:     	addpd	%xmm3, %xmm8
140065fe3:     	movapd	0x1b0(%rsp), %xmm13
140065fed:     	mulpd	%xmm7, %xmm13
140065ff2:     	mulpd	%xmm12, %xmm7
140065ff7:     	addpd	%xmm8, %xmm7
140065ffc:     	addpd	0x40(%rsp), %xmm7
140066002:     	divpd	%xmm5, %xmm7
140066006:     	movapd	%xmm9, %xmm3
14006600b:     	subpd	%xmm7, %xmm3
14006600f:     	movapd	%xmm3, %xmm7
140066013:     	mulpd	%xmm3, %xmm7
140066017:     	addpd	%xmm1, %xmm6
14006601b:     	addpd	%xmm4, %xmm6
14006601f:     	addpd	%xmm10, %xmm6
140066024:     	addpd	%xmm13, %xmm6
140066029:     	addpd	0x100(%rsp), %xmm6
140066032:     	divpd	%xmm5, %xmm6
140066036:     	movapd	%xmm2, %xmm4
14006603a:     	subpd	%xmm6, %xmm4
14006603e:     	movapd	%xmm4, %xmm6
140066042:     	mulpd	%xmm4, %xmm6
140066046:     	movapd	%xmm7, %xmm8
14006604b:     	unpcklpd	%xmm6, %xmm8            # xmm8 = xmm8[0],xmm6[0]
140066050:     	movhlps	%xmm7, %xmm6            # xmm6 = xmm7[1],xmm6[1]
140066053:     	addpd	%xmm8, %xmm6
140066058:     	sqrtpd	%xmm6, %xmm6
14006605c:     	xorl	%ecx, %ecx
14006605e:     	movapd	0x220(%rsp), %xmm7
140066067:     	ucomisd	%xmm6, %xmm7
14006606b:     	setb	%cl
14006606e:     	movapd	0x2a0(%rsp), %xmm13
140066078:     	divpd	%xmm6, %xmm13
14006607d:     	movapd	%xmm13, %xmm7
140066082:     	unpcklpd	%xmm13, %xmm7           # xmm7 = xmm7[0],xmm13[0]
140066087:     	mulpd	%xmm3, %xmm7
14006608b:     	movd	%ecx, %xmm8
140066090:     	pshufd	$0x0, %xmm8, %xmm10     # xmm10 = xmm8[0,0,0,0]
140066096:     	pslld	$0x1f, %xmm10
14006609c:     	psrad	$0x1f, %xmm10
1400660a2:     	andpd	%xmm10, %xmm7
1400660a7:     	andnpd	%xmm3, %xmm10
1400660ac:     	unpckhpd	%xmm6, %xmm6            # xmm6 = xmm6[1,1]
1400660b0:     	xorl	%ecx, %ecx
1400660b2:     	movapd	0x250(%rsp), %xmm3
1400660bb:     	ucomisd	%xmm6, %xmm3
1400660bf:     	orpd	%xmm7, %xmm10
1400660c4:     	setb	%cl
1400660c7:     	unpckhpd	%xmm13, %xmm13          # xmm13 = xmm13[1,1]
1400660cc:     	mulpd	%xmm4, %xmm13
1400660d1:     	movd	%ecx, %xmm3
1400660d5:     	pshufd	$0x0, %xmm3, %xmm6      # xmm6 = xmm3[0,0,0,0]
1400660da:     	pslld	$0x1f, %xmm6
1400660df:     	psrad	$0x1f, %xmm6
1400660e4:     	andpd	%xmm6, %xmm13
1400660e9:     	andnpd	%xmm4, %xmm6
1400660ed:     	orpd	%xmm13, %xmm6
1400660f2:     	movapd	%xmm10, %xmm3
1400660f7:     	subpd	%xmm9, %xmm3
1400660fc:     	movapd	%xmm3, %xmm4
140066100:     	andpd	%xmm11, %xmm4
140066105:     	xorpd	%xmm7, %xmm7
140066109:     	maxsd	%xmm7, %xmm4
14006610d:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
140066111:     	andpd	%xmm11, %xmm3
140066116:     	maxsd	%xmm4, %xmm3
14006611a:     	movapd	%xmm6, %xmm4
14006611e:     	subpd	%xmm2, %xmm4
140066122:     	movapd	%xmm4, %xmm2
140066126:     	andpd	%xmm11, %xmm2
14006612b:     	maxsd	%xmm3, %xmm2
14006612f:     	unpckhpd	%xmm4, %xmm4            # xmm4 = xmm4[1,1]
140066133:     	andpd	%xmm11, %xmm4
140066138:     	maxsd	%xmm2, %xmm4
14006613c:     	mulsd	0x290(%rsp), %xmm4
140066145:     	subl	$0x1, %eax
140066148:     	setb	%cl
14006614b:     	movsd	0x38(%rsp), %xmm2
140066151:     	ucomisd	%xmm4, %xmm2
140066155:     	jae	0x1400661db <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x200b>
14006615b:     	testb	%cl, %cl
14006615d:     	je	0x140065f70 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1da0>
140066163:     	jmp	0x1400661db <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x200b>
140066165:     	xorps	%xmm1, %xmm1
140066168:     	sqrtsd	%xmm14, %xmm1
14006616d:     	movapd	0x220(%rsp), %xmm10
140066177:     	xorpd	0x11e30(%rip), %xmm10   # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
140066180:     	divsd	%xmm1, %xmm10
140066185:     	movapd	0x40(%rsp), %xmm1
14006618b:     	unpcklpd	%xmm9, %xmm1            # xmm1 = xmm1[0],xmm9[0]
140066190:     	unpcklpd	%xmm10, %xmm10          # xmm10 = xmm10[0,0]
140066195:     	mulpd	%xmm1, %xmm10
14006619a:     	addsd	%xmm12, %xmm15
14006619f:     	ucomisd	%xmm0, %xmm15
1400661a4:     	jne	0x1400661a8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1fd8>
1400661a6:     	jnp	0x1400661db <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x200b>
1400661a8:     	xorps	%xmm0, %xmm0
1400661ab:     	sqrtsd	%xmm15, %xmm0
1400661b0:     	movapd	0x250(%rsp), %xmm6
1400661b9:     	xorpd	0x11def(%rip), %xmm6    # 0x140077fb0 <_ZTSN2kp6SphereE+0x118>
1400661c1:     	divsd	%xmm0, %xmm6
1400661c5:     	movapd	0x100(%rsp), %xmm0
1400661ce:     	unpcklpd	%xmm13, %xmm0           # xmm0 = xmm0[0],xmm13[0]
1400661d3:     	unpcklpd	%xmm6, %xmm6            # xmm6 = xmm6[0,0]
1400661d7:     	mulpd	%xmm0, %xmm6
1400661db:     	movq	0x90(%rsp), %rcx
1400661e3:     	testq	%rcx, %rcx
1400661e6:     	je	0x1400661f5 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x2025>
1400661e8:     	movq	%rcx, 0x98(%rsp)
1400661f0:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400661f5:     	movq	0x78(%rsp), %rcx
1400661fa:     	testq	%rcx, %rcx
1400661fd:     	movsd	0x240(%rsp), %xmm7
140066206:     	movsd	0x238(%rsp), %xmm8
140066210:     	je	0x14006621f <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x204f>
140066212:     	movq	%rcx, 0x80(%rsp)
14006621a:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14006621f:     	movq	0x60(%rsp), %rcx
140066224:     	testq	%rcx, %rcx
140066227:     	je	0x140066233 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x2063>
140066229:     	movq	%rcx, 0x68(%rsp)
14006622e:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140066233:     	movq	(%rsi), %rdi
140066236:     	movslq	(%rdi), %rax
140066239:     	movq	0x2c8(%rsp), %rbp
140066241:     	movq	(%rbp), %rcx
140066245:     	imulq	$0xb8, %rax, %r12
14006624c:     	addq	%rcx, %r12
14006624f:     	movslq	0x4(%rdi), %rax
140066253:     	imulq	$0xb8, %rax, %r13
14006625a:     	addq	%rcx, %r13
14006625d:     	leaq	0x250(%rdi), %rcx
140066264:     	movq	0x30(%rdi), %rax
140066268:     	movq	%rax, 0x350(%rsp)
140066270:     	movups	0x20(%rdi), %xmm0
140066274:     	movaps	%xmm0, 0x340(%rsp)
14006627c:     	movq	0x48(%rdi), %rax
140066280:     	movq	%rax, 0x368(%rsp)
140066288:     	movups	0x38(%rdi), %xmm0
14006628c:     	movups	%xmm0, 0x358(%rsp)
140066294:     	movq	0x60(%rdi), %rax
140066298:     	movq	%rax, 0x380(%rsp)
1400662a0:     	movups	0x50(%rdi), %xmm0
1400662a4:     	movaps	%xmm0, 0x370(%rsp)
1400662ac:     	movups	0x68(%rdi), %xmm0
1400662b0:     	movups	%xmm0, 0x388(%rsp)
1400662b8:     	movq	0x78(%rdi), %rax
1400662bc:     	movq	%rax, 0x398(%rsp)
1400662c4:     	movups	0x80(%rdi), %xmm0
1400662cb:     	movaps	%xmm0, 0x3a0(%rsp)
1400662d3:     	movq	0x90(%rdi), %rax
1400662da:     	movq	%rax, 0x3b0(%rsp)
1400662e2:     	movapd	%xmm10, 0x330(%rsp)
1400662ec:     	movsd	%xmm8, 0x28(%rsp)
1400662f3:     	movq	%rsi, %rbx
1400662f6:     	leaq	0x330(%rsp), %rsi
1400662fe:     	movq	%rsi, 0x20(%rsp)
140066303:     	leaq	0x340(%rsp), %r14
14006630b:     	movq	%r12, %rdx
14006630e:     	movq	%r13, %r8
140066311:     	movq	%r14, %r9
140066314:     	callq	0x14005f1e0 <_ZN2kp14CentreFriction10setTangentERNS_10SolverBodyES2_RKNS0_5FrameENS_7Vector2Ed>
140066319:     	leaq	0x298(%rdi), %rcx
140066320:     	movups	0x38(%rdi), %xmm0
140066324:     	movaps	%xmm0, 0x300(%rsp)
14006632c:     	movq	0x48(%rdi), %rax
140066330:     	movq	%rax, 0x310(%rsp)
140066338:     	movups	0x50(%rdi), %xmm0
14006633c:     	movaps	%xmm0, 0x2e0(%rsp)
140066344:     	movq	0x60(%rdi), %rax
140066348:     	movq	%rax, 0x2f0(%rsp)
140066350:     	movsd	%xmm8, 0x30(%rsp)
140066357:     	movsd	0x700(%rsp), %xmm8
140066361:     	movsd	%xmm8, 0x28(%rsp)
140066368:     	leaq	0x2e0(%rsp), %rdi
140066370:     	movq	%rdi, 0x20(%rsp)
140066375:     	leaq	0x300(%rsp), %r15
14006637d:     	movq	%r12, %rdx
140066380:     	movq	%r13, %r8
140066383:     	movq	%r15, %r9
140066386:     	callq	0x14006bb50 <_ZN2kp15RollingFriction5solveERNS_10SolverBodyES2_NS_7Vector3ES3_dd>
14006638b:     	movq	0x8(%rbx), %r13
14006638f:     	movslq	(%r13), %rax
140066393:     	movq	(%rbp), %rcx
140066397:     	imulq	$0xb8, %rax, %rbx
14006639e:     	addq	%rcx, %rbx
1400663a1:     	movslq	0x4(%r13), %rax
1400663a5:     	imulq	$0xb8, %rax, %r12
1400663ac:     	addq	%rcx, %r12
1400663af:     	leaq	0x250(%r13), %rcx
1400663b6:     	movq	0x30(%r13), %rax
1400663ba:     	movq	%rax, 0x350(%rsp)
1400663c2:     	movups	0x20(%r13), %xmm0
1400663c7:     	movaps	%xmm0, 0x340(%rsp)
1400663cf:     	movq	0x48(%r13), %rax
1400663d3:     	movq	%rax, 0x368(%rsp)
1400663db:     	movups	0x38(%r13), %xmm0
1400663e0:     	movups	%xmm0, 0x358(%rsp)
1400663e8:     	movq	0x60(%r13), %rax
1400663ec:     	movq	%rax, 0x380(%rsp)
1400663f4:     	movups	0x50(%r13), %xmm0
1400663f9:     	movaps	%xmm0, 0x370(%rsp)
140066401:     	movups	0x68(%r13), %xmm0
140066406:     	movups	%xmm0, 0x388(%rsp)
14006640e:     	movq	0x78(%r13), %rax
140066412:     	movq	%rax, 0x398(%rsp)
14006641a:     	movq	0x90(%r13), %rax
140066421:     	movq	%rax, 0x3b0(%rsp)
140066429:     	movups	0x80(%r13), %xmm0
140066431:     	movaps	%xmm0, 0x3a0(%rsp)
140066439:     	movapd	%xmm6, 0x330(%rsp)
140066442:     	movsd	%xmm7, 0x28(%rsp)
140066448:     	movq	%rsi, 0x20(%rsp)
14006644d:     	movq	%rbx, %rdx
140066450:     	movq	%r12, %r8
140066453:     	movq	%r14, %r9
140066456:     	callq	0x14005f1e0 <_ZN2kp14CentreFriction10setTangentERNS_10SolverBodyES2_RKNS0_5FrameENS_7Vector2Ed>
14006645b:     	leaq	0x298(%r13), %rcx
140066462:     	movups	0x38(%r13), %xmm0
140066467:     	movaps	%xmm0, 0x300(%rsp)
14006646f:     	movq	0x48(%r13), %rax
140066473:     	movq	%rax, 0x310(%rsp)
14006647b:     	movupd	0x50(%r13), %xmm0
140066481:     	movapd	%xmm0, 0x2e0(%rsp)
14006648a:     	movq	0x60(%r13), %rax
14006648e:     	movq	%rax, 0x2f0(%rsp)
140066496:     	movsd	%xmm7, 0x30(%rsp)
14006649c:     	movsd	%xmm8, 0x28(%rsp)
1400664a3:     	movq	%rdi, 0x20(%rsp)
1400664a8:     	movq	%rbx, %rdx
1400664ab:     	movq	%r12, %r8
1400664ae:     	movq	%r15, %r9
1400664b1:     	callq	0x14006bb50 <_ZN2kp15RollingFriction5solveERNS_10SolverBodyES2_NS_7Vector3ES3_dd>
1400664b6:     	xorpd	%xmm2, %xmm2
1400664ba:     	movq	0x248(%rsp), %rcx
1400664c2:     	movq	%rbp, %rdx
1400664c5:     	movsd	0x2d8(%rsp), %xmm3
1400664ce:     	callq	0x140049880 <_ZNK2kp12DirectJoints5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEdd>
1400664d3:     	movl	0x5c(%rsp), %ebp
1400664d7:     	andb	$0x1, %bpl
1400664db:     	movl	%ebp, %eax
1400664dd:     	movaps	0x5f0(%rsp), %xmm6
1400664e5:     	movaps	0x600(%rsp), %xmm7
1400664ed:     	movaps	0x610(%rsp), %xmm8
1400664f6:     	movaps	0x620(%rsp), %xmm9
1400664ff:     	movaps	0x630(%rsp), %xmm10
140066508:     	movaps	0x640(%rsp), %xmm11
140066511:     	movaps	0x650(%rsp), %xmm12
14006651a:     	movaps	0x660(%rsp), %xmm13
140066523:     	movaps	0x670(%rsp), %xmm14
14006652c:     	movaps	0x680(%rsp), %xmm15
140066535:     	addq	$0x698, %rsp            # imm = 0x698
14006653c:     	popq	%rbx
14006653d:     	popq	%rbp
14006653e:     	popq	%rdi
14006653f:     	popq	%rsi
140066540:     	popq	%r12
140066542:     	popq	%r13
140066544:     	popq	%r14
140066546:     	popq	%r15
140066548:     	retq
140066549:     	xorpd	%xmm0, %xmm0
14006654d:     	movl	0x1aaed(%rip), %eax     # 0x140081040 <_tls_index>
140066553:     	movq	%gs:0x58, %rcx
14006655c:     	movq	(%rcx,%rax,8), %rsi
140066560:     	movupd	%xmm0, 0x100(%rsi)
140066568:     	movq	$0x0, 0x110(%rsi)
140066573:     	leaq	0x100(%rsi), %rdx
14006657a:     	leaq	-0x22951(%rip), %rcx    # 0x140043c30 <_ZNSt3__16vectorIcNS_9allocatorIcEEED2B9nqe230106Ev>
140066581:     	leaq	0x1abe8(%rip), %r8      # 0x140081170 <__dso_handle>
140066588:     	callq	0x140027940 <__cxa_thread_atexit>
14006658d:     	movb	$0x1, 0xd0(%rsi)
140066594:     	jmp	0x1400658d0 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x1700>
140066599:     	callq	0x1400665e0 <_ZNSt3__16vectorIN2kp12_GLOBAL__N_18GuideRhsENS1_13StepAllocatorIS3_EEE20__throw_length_errorB9nqe230106Ev>
14006659e:     	callq	0x1400665e0 <_ZNSt3__16vectorIN2kp12_GLOBAL__N_18GuideRhsENS1_13StepAllocatorIS3_EEE20__throw_length_errorB9nqe230106Ev>
1400665a3:     	movq	%rax, %rsi
1400665a6:     	testq	%r14, %r14
1400665a9:     	je	0x1400665b8 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x23e8>
1400665ab:     	movq	0x210(%rsp), %rcx
1400665b3:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400665b8:     	movq	%rsi, %rcx
1400665bb:     	callq	0x140072ed0 <_Unwind_Resume>
1400665c0:     	jmp	0x1400665c2 <_ZN2kp15CoupledFriction5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEERKNS_12DirectJointsEdd+0x23f2>
1400665c2:     	movq	%rax, %rsi
1400665c5:     	leaq	0x60(%rsp), %rcx
1400665ca:     	callq	0x140063030 <_ZN2kp13ProfileMatrixD2Ev>
1400665cf:     	movq	%rsi, %rcx
1400665d2:     	callq	0x140072ed0 <_Unwind_Resume>
1400665d7:     	int3
1400665d8:     	nopl	(%rax,%rax)

SoftStep::step

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140020220 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE>:
140020220:     	pushq	%r15
140020222:     	pushq	%r14
140020224:     	pushq	%r13
140020226:     	pushq	%r12
140020228:     	pushq	%rsi
140020229:     	pushq	%rdi
14002022a:     	pushq	%rbp
14002022b:     	pushq	%rbx
14002022c:     	subq	$0x948, %rsp            # imm = 0x948
140020233:     	movapd	%xmm15, 0x930(%rsp)
14002023d:     	movapd	%xmm14, 0x920(%rsp)
140020247:     	movapd	%xmm13, 0x910(%rsp)
140020251:     	movapd	%xmm12, 0x900(%rsp)
14002025b:     	movaps	%xmm11, 0x8f0(%rsp)
140020264:     	movaps	%xmm10, 0x8e0(%rsp)
14002026d:     	movapd	%xmm9, 0x8d0(%rsp)
140020277:     	movaps	%xmm8, 0x8c0(%rsp)
140020280:     	movaps	%xmm7, 0x8b0(%rsp)
140020288:     	movaps	%xmm6, 0x8a0(%rsp)
140020290:     	movq	%r8, %rbx
140020293:     	movq	%rdx, %r14
140020296:     	movsd	0x9b8(%rsp), %xmm7
14002029f:     	cvtsi2sdl	(%rcx), %xmm0
1400202a3:     	movsd	0x10(%rcx), %xmm10
1400202a9:     	movapd	%xmm7, %xmm1
1400202ad:     	divsd	%xmm0, %xmm1
1400202b1:     	movapd	%xmm1, 0x50(%rsp)
1400202b7:     	unpcklpd	%xmm1, %xmm1            # xmm1 = xmm1[0,0]
1400202bb:     	movapd	0x558bd(%rip), %xmm0    # 0x140075b80 <_ZTSNSt3__110__function6__baseIFvyEEE+0x88>
1400202c3:     	movapd	%xmm1, 0x700(%rsp)
1400202cc:     	divpd	%xmm1, %xmm0
1400202d0:     	movsd	0x38(%rcx), %xmm1
1400202d5:     	movapd	%xmm1, %xmm2
1400202d9:     	unpcklpd	%xmm10, %xmm2           # xmm2 = xmm2[0],xmm10[0]
1400202de:     	movapd	%xmm0, %xmm3
1400202e2:     	cmpltpd	%xmm2, %xmm3
1400202e7:     	movmskpd	%xmm3, %eax
1400202eb:     	testb	$0x2, %al
1400202ed:     	je	0x1400202f9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xd9>
1400202ef:     	movapd	%xmm0, %xmm10
1400202f4:     	unpckhpd	%xmm0, %xmm10           # xmm10 = xmm10[1],xmm0[1]
1400202f9:     	movsd	0x40(%rcx), %xmm2
1400202fe:     	testb	$0x1, %al
140020300:     	jne	0x140020306 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xe6>
140020302:     	movapd	%xmm1, %xmm0
140020306:     	movq	%rcx, 0x170(%rsp)
14002030e:     	movsd	0x18(%rcx), %xmm11
140020314:     	mulsd	0x5588c(%rip), %xmm0    # 0x140075ba8 <_ZTSNSt3__110__function6__baseIFvyEEE+0xb0>
14002031c:     	addsd	%xmm2, %xmm2
140020320:     	movapd	0x50(%rsp), %xmm1
140020326:     	mulsd	%xmm0, %xmm1
14002032a:     	addsd	%xmm1, %xmm2
14002032e:     	mulsd	%xmm2, %xmm1
140020332:     	movapd	%xmm1, %xmm3
140020336:     	movsd	0x55862(%rip), %xmm4    # 0x140075ba0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xa8>
14002033e:     	addsd	%xmm4, %xmm3
140020342:     	divsd	%xmm3, %xmm4
140020346:     	divsd	%xmm2, %xmm0
14002034a:     	movsd	%xmm0, 0x2e8(%rsp)
140020353:     	mulsd	%xmm4, %xmm1
140020357:     	movsd	%xmm1, 0x2f0(%rsp)
140020360:     	movsd	%xmm4, 0x2f8(%rsp)
140020369:     	movq	(%r9), %rsi
14002036c:     	movq	%r9, 0x248(%rsp)
140020374:     	movq	0x8(%r9), %rdi
140020378:     	cmpq	%rdi, %rsi
14002037b:     	je	0x140020399 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x179>
14002037d:     	nopl	(%rax)
140020380:     	movq	(%rsi), %rcx
140020383:     	movq	(%rcx), %rax
140020386:     	movq	%r14, %rdx
140020389:     	movapd	%xmm7, %xmm2
14002038d:     	callq	*0x28(%rax)
140020390:     	addq	$0x8, %rsi
140020394:     	cmpq	%rdi, %rsi
140020397:     	jne	0x140020380 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x160>
140020399:     	movq	0x8(%r14), %rax
14002039d:     	movq	%r14, 0x48(%rsp)
1400203a2:     	movq	(%r14), %rcx
1400203a5:     	xorpd	%xmm12, %xmm12
1400203aa:     	movapd	%xmm12, 0x130(%rsp)
1400203b4:     	movq	$0x0, 0x140(%rsp)
1400203c0:     	subq	%rcx, %rax
1400203c3:     	je	0x140020992 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x772>
1400203c9:     	sarq	$0x3, %rax
1400203cd:     	movabsq	$0x51b3bea3677d46cf, %rcx # imm = 0x51B3BEA3677D46CF
1400203d7:     	imulq	%rcx, %rax
1400203db:     	movabsq	$0x1642c8590b21642, %rcx # imm = 0x1642C8590B21642
1400203e5:     	cmpq	%rcx, %rax
1400203e8:     	ja	0x140023fee <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dce>
1400203ee:     	imulq	$0xb8, %rax, %rdi
1400203f5:     	movq	%rdi, %rcx
1400203f8:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
1400203fd:     	movq	%rax, %r14
140020400:     	movq	%rax, 0x130(%rsp)
140020408:     	movq	%rax, %rcx
14002040b:     	addq	%rdi, %rcx
14002040e:     	movq	%rcx, 0x140(%rsp)
140020416:     	addq	$-0xb8, %rdi
14002041d:     	movq	%rdi, %rax
140020420:     	shrq	$0x3, %rax
140020424:     	movabsq	$0x1642c8590b21642d, %rdx # imm = 0x1642C8590B21642D
14002042e:     	mulq	%rdx
140020431:     	shrl	%edx
140020433:     	incl	%edx
140020435:     	movq	%r14, %rax
140020438:     	andl	$0x7, %edx
14002043b:     	movq	0x48(%rsp), %r8
140020440:     	movabsq	$0x3ff0000000000000, %r9 # imm = 0x3FF0000000000000
14002044a:     	je	0x1400204c3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2a3>
14002044c:     	imulq	$0xb8, %rdx, %rdx
140020453:     	xorpd	%xmm0, %xmm0
140020457:     	movq	%r14, %rax
14002045a:     	nopw	(%rax,%rax)
140020460:     	movupd	%xmm0, 0x80(%rax)
140020468:     	movupd	%xmm0, 0x70(%rax)
14002046d:     	movupd	%xmm0, 0x60(%rax)
140020472:     	movupd	%xmm0, 0x50(%rax)
140020477:     	movupd	%xmm0, 0x40(%rax)
14002047c:     	movupd	%xmm0, 0x30(%rax)
140020481:     	movupd	%xmm0, 0x20(%rax)
140020486:     	movupd	%xmm0, 0x10(%rax)
14002048b:     	movupd	%xmm0, (%rax)
14002048f:     	movq	$0x0, 0x90(%rax)
14002049a:     	movq	%r9, 0x98(%rax)
1400204a1:     	movupd	%xmm0, 0xa0(%rax)
1400204a9:     	movq	$0x0, 0xb0(%rax)
1400204b4:     	addq	$0xb8, %rax
1400204ba:     	addq	$-0xb8, %rdx
1400204c1:     	jne	0x140020460 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x240>
1400204c3:     	cmpq	$0x508, %rdi            # imm = 0x508
1400204ca:     	jb	0x14002083e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x61e>
1400204d0:     	xorpd	%xmm0, %xmm0
1400204d4:     	nopw	%cs:(%rax,%rax)
1400204e0:     	movupd	%xmm0, 0x80(%rax)
1400204e8:     	movupd	%xmm0, 0x70(%rax)
1400204ed:     	movupd	%xmm0, 0x60(%rax)
1400204f2:     	movupd	%xmm0, 0x50(%rax)
1400204f7:     	movupd	%xmm0, 0x40(%rax)
1400204fc:     	movupd	%xmm0, 0x30(%rax)
140020501:     	movupd	%xmm0, 0x20(%rax)
140020506:     	movupd	%xmm0, 0x10(%rax)
14002050b:     	movupd	%xmm0, (%rax)
14002050f:     	movq	$0x0, 0x90(%rax)
14002051a:     	movq	%r9, 0x98(%rax)
140020521:     	movupd	%xmm0, 0xa0(%rax)
140020529:     	movq	$0x0, 0xb0(%rax)
140020534:     	movupd	%xmm0, 0xb8(%rax)
14002053c:     	movupd	%xmm0, 0xc8(%rax)
140020544:     	movupd	%xmm0, 0xd8(%rax)
14002054c:     	movupd	%xmm0, 0xe8(%rax)
140020554:     	movupd	%xmm0, 0xf8(%rax)
14002055c:     	movupd	%xmm0, 0x108(%rax)
140020564:     	movupd	%xmm0, 0x118(%rax)
14002056c:     	movupd	%xmm0, 0x128(%rax)
140020574:     	movupd	%xmm0, 0x138(%rax)
14002057c:     	movq	$0x0, 0x148(%rax)
140020587:     	movq	%r9, 0x150(%rax)
14002058e:     	movupd	%xmm0, 0x158(%rax)
140020596:     	movq	$0x0, 0x168(%rax)
1400205a1:     	movupd	%xmm0, 0x170(%rax)
1400205a9:     	movupd	%xmm0, 0x180(%rax)
1400205b1:     	movupd	%xmm0, 0x190(%rax)
1400205b9:     	movupd	%xmm0, 0x1a0(%rax)
1400205c1:     	movupd	%xmm0, 0x1b0(%rax)
1400205c9:     	movupd	%xmm0, 0x1c0(%rax)
1400205d1:     	movupd	%xmm0, 0x1d0(%rax)
1400205d9:     	movupd	%xmm0, 0x1e0(%rax)
1400205e1:     	movupd	%xmm0, 0x1f0(%rax)
1400205e9:     	movq	$0x0, 0x200(%rax)
1400205f4:     	movq	%r9, 0x208(%rax)
1400205fb:     	movupd	%xmm0, 0x210(%rax)
140020603:     	movq	$0x0, 0x220(%rax)
14002060e:     	movupd	%xmm0, 0x228(%rax)
140020616:     	movupd	%xmm0, 0x238(%rax)
14002061e:     	movupd	%xmm0, 0x248(%rax)
140020626:     	movupd	%xmm0, 0x258(%rax)
14002062e:     	movupd	%xmm0, 0x268(%rax)
140020636:     	movupd	%xmm0, 0x278(%rax)
14002063e:     	movupd	%xmm0, 0x288(%rax)
140020646:     	movupd	%xmm0, 0x298(%rax)
14002064e:     	movupd	%xmm0, 0x2a8(%rax)
140020656:     	movq	$0x0, 0x2b8(%rax)
140020661:     	movq	%r9, 0x2c0(%rax)
140020668:     	movupd	%xmm0, 0x2c8(%rax)
140020670:     	movq	$0x0, 0x2d8(%rax)
14002067b:     	movupd	%xmm0, 0x360(%rax)
140020683:     	movupd	%xmm0, 0x350(%rax)
14002068b:     	movupd	%xmm0, 0x340(%rax)
140020693:     	movupd	%xmm0, 0x330(%rax)
14002069b:     	movupd	%xmm0, 0x320(%rax)
1400206a3:     	movupd	%xmm0, 0x310(%rax)
1400206ab:     	movupd	%xmm0, 0x300(%rax)
1400206b3:     	movupd	%xmm0, 0x2f0(%rax)
1400206bb:     	movupd	%xmm0, 0x2e0(%rax)
1400206c3:     	movq	$0x0, 0x370(%rax)
1400206ce:     	movq	%r9, 0x378(%rax)
1400206d5:     	movupd	%xmm0, 0x380(%rax)
1400206dd:     	movq	$0x0, 0x390(%rax)
1400206e8:     	movupd	%xmm0, 0x418(%rax)
1400206f0:     	movupd	%xmm0, 0x408(%rax)
1400206f8:     	movupd	%xmm0, 0x3f8(%rax)
140020700:     	movupd	%xmm0, 0x3e8(%rax)
140020708:     	movupd	%xmm0, 0x3d8(%rax)
140020710:     	movupd	%xmm0, 0x3c8(%rax)
140020718:     	movupd	%xmm0, 0x3b8(%rax)
140020720:     	movupd	%xmm0, 0x3a8(%rax)
140020728:     	movupd	%xmm0, 0x398(%rax)
140020730:     	movq	$0x0, 0x428(%rax)
14002073b:     	movq	%r9, 0x430(%rax)
140020742:     	movupd	%xmm0, 0x438(%rax)
14002074a:     	movq	$0x0, 0x448(%rax)
140020755:     	movupd	%xmm0, 0x4d0(%rax)
14002075d:     	movupd	%xmm0, 0x4c0(%rax)
140020765:     	movupd	%xmm0, 0x4b0(%rax)
14002076d:     	movupd	%xmm0, 0x4a0(%rax)
140020775:     	movupd	%xmm0, 0x490(%rax)
14002077d:     	movupd	%xmm0, 0x480(%rax)
140020785:     	movupd	%xmm0, 0x470(%rax)
14002078d:     	movupd	%xmm0, 0x460(%rax)
140020795:     	movupd	%xmm0, 0x450(%rax)
14002079d:     	movq	$0x0, 0x4e0(%rax)
1400207a8:     	movq	%r9, 0x4e8(%rax)
1400207af:     	movupd	%xmm0, 0x4f0(%rax)
1400207b7:     	movq	$0x0, 0x500(%rax)
1400207c2:     	movupd	%xmm0, 0x588(%rax)
1400207ca:     	movupd	%xmm0, 0x578(%rax)
1400207d2:     	movupd	%xmm0, 0x568(%rax)
1400207da:     	movupd	%xmm0, 0x558(%rax)
1400207e2:     	movupd	%xmm0, 0x548(%rax)
1400207ea:     	movupd	%xmm0, 0x538(%rax)
1400207f2:     	movupd	%xmm0, 0x528(%rax)
1400207fa:     	movupd	%xmm0, 0x518(%rax)
140020802:     	movupd	%xmm0, 0x508(%rax)
14002080a:     	movq	$0x0, 0x598(%rax)
140020815:     	movq	%r9, 0x5a0(%rax)
14002081c:     	movupd	%xmm0, 0x5a8(%rax)
140020824:     	movq	$0x0, 0x5b8(%rax)
14002082f:     	addq	$0x5c0, %rax            # imm = 0x5C0
140020835:     	cmpq	%rcx, %rax
140020838:     	jne	0x1400204e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2c0>
14002083e:     	movq	%rcx, 0x138(%rsp)
140020846:     	movq	(%r8), %r12
140020849:     	cmpq	%r12, 0x8(%r8)
14002084d:     	je	0x140020992 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x772>
140020853:     	xorl	%esi, %esi
140020855:     	xorpd	%xmm13, %xmm13
14002085a:     	leaq	0x430(%rsp), %r15
140020862:     	movq	%r14, %rdi
140020865:     	xorl	%r13d, %r13d
140020868:     	jmp	0x1400208ef <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x6cf>
14002086d:     	nopl	(%rax)
140020870:     	movq	0x470(%rsp), %rax
140020878:     	movq	%rax, 0x70(%rdi)
14002087c:     	movupd	0x430(%rsp), %xmm0
140020885:     	movupd	0x440(%rsp), %xmm1
14002088e:     	movupd	0x450(%rsp), %xmm2
140020897:     	movupd	0x460(%rsp), %xmm3
1400208a0:     	movupd	%xmm3, 0x60(%rdi)
1400208a5:     	movupd	%xmm2, 0x50(%rdi)
1400208aa:     	movupd	%xmm1, 0x40(%rdi)
1400208af:     	movupd	%xmm0, 0x30(%rdi)
1400208b4:     	incq	%r13
1400208b7:     	movq	0x48(%rsp), %rax
1400208bc:     	movq	(%rax), %r12
1400208bf:     	movq	0x8(%rax), %rax
1400208c3:     	subq	%r12, %rax
1400208c6:     	sarq	$0x3, %rax
1400208ca:     	movabsq	$0x51b3bea3677d46cf, %rcx # imm = 0x51B3BEA3677D46CF
1400208d4:     	imulq	%rcx, %rax
1400208d8:     	addq	$0xb8, %rdi
1400208df:     	addq	$0x178, %rsi            # imm = 0x178
1400208e6:     	cmpq	%rax, %r13
1400208e9:     	jae	0x140020992 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x772>
1400208ef:     	movsd	0x68(%r12,%rsi), %xmm0
1400208f6:     	ucomisd	%xmm13, %xmm0
1400208fb:     	jne	0x140020920 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x700>
1400208fd:     	jp	0x140020920 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x700>
1400208ff:     	movupd	0x148(%r12,%rsi), %xmm1
140020909:     	movsd	0x158(%r12,%rsi), %xmm0
140020913:     	jmp	0x14002093a <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x71a>
140020915:     	nopw	%cs:(%rax,%rax)
140020920:     	movupd	0x38(%r12,%rsi), %xmm2
140020927:     	movapd	%xmm0, %xmm1
14002092b:     	unpcklpd	%xmm0, %xmm1            # xmm1 = xmm1[0],xmm0[0]
14002092f:     	mulpd	%xmm2, %xmm1
140020933:     	mulsd	0x48(%r12,%rsi), %xmm0
14002093a:     	addq	%rsi, %r12
14002093d:     	movupd	%xmm1, (%rdi)
140020941:     	movsd	%xmm0, 0x10(%rdi)
140020946:     	movq	%r15, %rcx
140020949:     	movq	%r12, %rdx
14002094c:     	callq	0x14000ec60 <_ZNK2kp4Body15angularVelocityEv>
140020951:     	movq	0x440(%rsp), %rax
140020959:     	movq	%rax, 0x28(%rdi)
14002095d:     	movups	0x430(%rsp), %xmm0
140020965:     	movups	%xmm0, 0x18(%rdi)
140020969:     	movsd	0x68(%r12), %xmm0
140020970:     	ucomisd	%xmm13, %xmm0
140020975:     	jne	0x14002097d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x75d>
140020977:     	jnp	0x1400208b4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x694>
14002097d:     	movsd	%xmm0, 0x78(%rdi)
140020982:     	movq	%r15, %rcx
140020985:     	movq	%r12, %rdx
140020988:     	callq	0x140025fd0 <_ZN2kp21inverseInertiaInWorldERKNS_4BodyE>
14002098d:     	jmp	0x140020870 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x650>
140020992:     	unpcklpd	%xmm10, %xmm10          # xmm10 = xmm10[0,0]
140020997:     	movapd	0x551c1(%rip), %xmm0    # 0x140075b60 <_ZTSNSt3__110__function6__baseIFvyEEE+0x68>
14002099f:     	movapd	0x50(%rsp), %xmm6
1400209a5:     	movsd	%xmm6, %xmm0            # xmm0 = xmm6[0],xmm0[1]
1400209a9:     	mulpd	0x551de(%rip), %xmm10   # 0x140075b90 <_ZTSNSt3__110__function6__baseIFvyEEE+0x98>
1400209b2:     	movapd	%xmm11, %xmm2
1400209b7:     	addsd	%xmm11, %xmm2
1400209bc:     	mulpd	%xmm10, %xmm0
1400209c1:     	mulsd	0x55186(%rip), %xmm11   # 0x140075b50 <_ZTSNSt3__110__function6__baseIFvyEEE+0x58>
1400209ca:     	addsd	%xmm0, %xmm2
1400209ce:     	addsd	%xmm11, %xmm11
1400209d3:     	movapd	0x55195(%rip), %xmm3    # 0x140075b70 <_ZTSNSt3__110__function6__baseIFvyEEE+0x78>
1400209db:     	unpcklpd	%xmm11, %xmm3           # xmm3 = xmm3[0],xmm11[0]
1400209e0:     	movapd	%xmm2, %xmm1
1400209e4:     	unpcklpd	%xmm6, %xmm1            # xmm1 = xmm1[0],xmm6[0]
1400209e8:     	mulpd	%xmm0, %xmm1
1400209ec:     	addpd	%xmm1, %xmm3
1400209f0:     	movapd	%xmm1, %xmm4
1400209f4:     	mulpd	%xmm3, %xmm4
1400209f8:     	unpckhpd	%xmm4, %xmm4            # xmm4 = xmm4[1,1]
1400209fc:     	movapd	%xmm4, %xmm5
140020a00:     	movsd	0x55197(%rip), %xmm8    # 0x140075ba0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xa8>
140020a09:     	addsd	%xmm8, %xmm5
140020a0e:     	unpcklpd	%xmm8, %xmm10           # xmm10 = xmm10[0],xmm8[0]
140020a13:     	unpcklpd	%xmm5, %xmm2            # xmm2 = xmm2[0],xmm5[0]
140020a17:     	divpd	%xmm2, %xmm10
140020a1c:     	movsd	%xmm8, %xmm0            # xmm0 = xmm8[0],xmm0[1]
140020a21:     	movapd	%xmm10, %xmm2
140020a26:     	unpckhpd	%xmm10, %xmm2           # xmm2 = xmm2[1],xmm10[1]
140020a2b:     	divpd	%xmm3, %xmm0
140020a2f:     	mulsd	%xmm0, %xmm1
140020a33:     	movapd	%xmm2, %xmm3
140020a37:     	mulsd	%xmm4, %xmm3
140020a3b:     	movq	0x48(%rsp), %rax
140020a40:     	movq	%rax, 0x300(%rsp)
140020a48:     	leaq	0x130(%rsp), %rax
140020a50:     	movq	%rax, 0x308(%rsp)
140020a58:     	movlpd	%xmm10, 0x310(%rsp)
140020a62:     	movsd	%xmm1, 0x318(%rsp)
140020a6b:     	movupd	%xmm0, 0x320(%rsp)
140020a74:     	movsd	%xmm3, 0x330(%rsp)
140020a7d:     	movsd	%xmm2, 0x338(%rsp)
140020a86:     	movsd	%xmm6, 0x340(%rsp)
140020a8f:     	movq	0x170(%rsp), %rax
140020a97:     	movzbl	0x48(%rax), %eax
140020a9b:     	movb	%al, 0x348(%rsp)
140020aa2:     	movapd	%xmm12, 0xf0(%rsp)
140020aac:     	movq	$0x0, 0x100(%rsp)
140020ab8:     	movapd	%xmm12, 0x110(%rsp)
140020ac2:     	movq	$0x0, 0x120(%rsp)
140020ace:     	movq	0x8(%rbx), %rdx
140020ad2:     	subq	(%rbx), %rdx
140020ad5:     	sarq	$0x3, %rdx
140020ad9:     	movabsq	$0x4fcace213f2b3885, %rax # imm = 0x4FCACE213F2B3885
140020ae3:     	imulq	%rax, %rdx
140020ae7:     	leaq	0x110(%rsp), %rcx
140020aef:     	callq	0x140026490 <_ZNSt3__16vectorIN2kp11SoftContactENS1_13StepAllocatorIS2_EEE7reserveB9nqe230106Ey>
140020af4:     	movq	0x8(%rbx), %rsi
140020af8:     	subq	(%rbx), %rsi
140020afb:     	movabsq	$0x1fffffffffffffff, %rcx # imm = 0x1FFFFFFFFFFFFFFF
140020b05:     	sarq	$0x3, %rsi
140020b09:     	movabsq	$0x4fcace213f2b3885, %rax # imm = 0x4FCACE213F2B3885
140020b13:     	imulq	%rax, %rsi
140020b17:     	movq	0xf0(%rsp), %r14
140020b1f:     	movq	0x100(%rsp), %rax
140020b27:     	subq	%r14, %rax
140020b2a:     	sarq	$0x3, %rax
140020b2e:     	cmpq	%rax, %rsi
140020b31:     	jbe	0x140020ba6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x986>
140020b33:     	cmpq	%rcx, %rsi
140020b36:     	ja	0x140023ffd <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ddd>
140020b3c:     	movq	0xf8(%rsp), %rdi
140020b44:     	leaq	(,%rsi,8), %rcx
140020b4c:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140020b51:     	subq	%r14, %rdi
140020b54:     	addq	%rax, %rdi
140020b57:     	leaq	(%rax,%rsi,8), %r14
140020b5b:     	movq	0xf0(%rsp), %rdx
140020b63:     	movq	0xf8(%rsp), %r8
140020b6b:     	subq	%rdx, %r8
140020b6e:     	movq	%rdi, %rsi
140020b71:     	subq	%r8, %rsi
140020b74:     	movq	%rsi, %rcx
140020b77:     	callq	0x140072ff0 <memcpy>
140020b7c:     	movq	0xf0(%rsp), %rcx
140020b84:     	movq	%rsi, 0xf0(%rsp)
140020b8c:     	movq	%rdi, 0xf8(%rsp)
140020b94:     	movq	%r14, 0x100(%rsp)
140020b9c:     	testq	%rcx, %rcx
140020b9f:     	je	0x140020ba6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x986>
140020ba1:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140020ba6:     	movq	0x9c0(%rsp), %rax
140020bae:     	movq	(%rax), %r15
140020bb1:     	movq	$0x0, 0x80(%rsp)
140020bbd:     	movq	(%rbx), %rax
140020bc0:     	movq	0x8(%rbx), %rcx
140020bc4:     	cmpq	%rax, %rcx
140020bc7:     	je	0x140020ed2 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xcb2>
140020bcd:     	xorl	%edx, %edx
140020bcf:     	xorpd	%xmm11, %xmm11
140020bd4:     	leaq	0x430(%rsp), %r12
140020bdc:     	leaq	0x350(%rsp), %rsi
140020be4:     	leaq	0x80(%rsp), %r13
140020bec:     	leaq	0xf0(%rsp), %rbp
140020bf4:     	jmp	0x140020c48 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xa28>
140020bf6:     	nopw	%cs:(%rax,%rax)
140020c00:     	movq	%rcx, 0x440(%rsp)
140020c08:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140020c0d:     	movq	0x80(%rsp), %rdx
140020c15:     	movq	(%rbx), %rax
140020c18:     	movq	0x8(%rbx), %rcx
140020c1c:     	incq	%rdx
140020c1f:     	movq	%rdx, 0x80(%rsp)
140020c27:     	movq	%rcx, %r8
140020c2a:     	subq	%rax, %r8
140020c2d:     	sarq	$0x3, %r8
140020c31:     	movabsq	$0x4fcace213f2b3885, %r9 # imm = 0x4FCACE213F2B3885
140020c3b:     	imulq	%r9, %r8
140020c3f:     	cmpq	%r8, %rdx
140020c42:     	jae	0x140020ed2 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xcb2>
140020c48:     	imulq	$0x268, %rdx, %r14      # imm = 0x268
140020c4f:     	cmpl	$0x0, 0x250(%rax,%r14)
140020c58:     	je	0x140020c1c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9fc>
140020c5a:     	addq	%rax, %r14
140020c5d:     	movq	0x300(%rsp), %r9
140020c65:     	movslq	(%r14), %r8
140020c68:     	movq	(%r9), %r10
140020c6b:     	imulq	$0x178, %r8, %r9        # imm = 0x178
140020c72:     	movsd	0x68(%r10,%r9), %xmm0
140020c79:     	ucomisd	%xmm11, %xmm0
140020c7e:     	movl	0x4(%r14), %r9d
140020c82:     	jne	0x140020ca4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xa84>
140020c84:     	jp	0x140020ca4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xa84>
140020c86:     	movslq	%r9d, %r11
140020c89:     	imulq	$0x178, %r11, %r11      # imm = 0x178
140020c90:     	movsd	0x68(%r10,%r11), %xmm0
140020c97:     	ucomisd	%xmm11, %xmm0
140020c9c:     	jne	0x140020ca4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xa84>
140020c9e:     	jnp	0x140020c1c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9fc>
140020ca4:     	movl	%r8d, 0x430(%rsp)
140020cac:     	movl	%r9d, 0x434(%rsp)
140020cb4:     	movl	$0x0, 0x438(%rsp)
140020cbf:     	movq	0x8(%r14), %rax
140020cc3:     	movq	%rax, 0x43c(%rsp)
140020ccb:     	leaq	0x7e0(%rsp), %rcx
140020cd3:     	movq	0x9c0(%rsp), %rdx
140020cdb:     	movq	%r12, %r8
140020cde:     	movq	%r15, %r9
140020ce1:     	callq	0x140026600 <_ZNK2kp13ContactForces2ofERKNS_9ContactIdEPKNSt3__14pairIS1_NS_12ContactForceEEE>
140020ce6:     	movq	0x300(%rsp), %r8
140020cee:     	movslq	(%r14), %rax
140020cf1:     	movq	(%r8), %rcx
140020cf4:     	imulq	$0x178, %rax, %rax      # imm = 0x178
140020cfb:     	movsd	0x68(%rcx,%rax), %xmm0
140020d01:     	movl	$0x28, %eax
140020d06:     	ucomisd	%xmm11, %xmm0
140020d0b:     	jne	0x140020d0f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xaef>
140020d0d:     	jnp	0x140020d33 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xb13>
140020d0f:     	movslq	0x4(%r14), %rax
140020d13:     	imulq	$0x178, %rax, %rax      # imm = 0x178
140020d1a:     	ucomisd	0x68(%rcx,%rax), %xmm11
140020d21:     	movl	$0x28, %eax
140020d26:     	movl	$0x10, %ecx
140020d2b:     	cmovneq	%rcx, %rax
140020d2f:     	cmovpq	%rcx, %rax
140020d33:     	movq	0x7e8(%rsp), %r15
140020d3b:     	shlq	$0x6, %r15
140020d3f:     	addq	0x7e0(%rsp), %r15
140020d47:     	movq	0x308(%rsp), %r9
140020d4f:     	addq	%rsp, %rax
140020d52:     	addq	$0x300, %rax            # imm = 0x300
140020d58:     	movups	0x7e0(%rsp), %xmm0
140020d60:     	movaps	%xmm0, 0x350(%rsp)
140020d68:     	movsd	0x340(%rsp), %xmm0
140020d71:     	movzbl	0x348(%rsp), %ecx
140020d79:     	movb	%cl, 0x38(%rsp)
140020d7d:     	movsd	%xmm0, 0x30(%rsp)
140020d83:     	movq	%rsi, 0x28(%rsp)
140020d88:     	movq	%rax, 0x20(%rsp)
140020d8d:     	movb	$0x1, 0x40(%rsp)
140020d92:     	movq	%r12, %rcx
140020d95:     	movq	%r14, %rdx
140020d98:     	callq	0x14003d930 <_ZN2kp11SoftContactC2ERKNS_11ContactPairERKNSt3__16vectorINS_4BodyENS4_9allocatorIS6_EEEERKNS5_INS_10SolverBodyENS_13StepAllocatorISC_EEEERKNS_8SoftnessENS_4SpanINS4_4pairINS_9ContactIdENS_12ContactForceEEEEEdbb>
140020d9d:     	movq	0x118(%rsp), %rdi
140020da5:     	cmpq	0x120(%rsp), %rdi
140020dad:     	je	0x140020e22 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xc02>
140020daf:     	movq	0x430(%rsp), %rax
140020db7:     	movq	%rax, (%rdi)
140020dba:     	movq	0x438(%rsp), %rax
140020dc2:     	movq	$0x0, 0x438(%rsp)
140020dce:     	movq	%rax, 0x8(%rdi)
140020dd2:     	movq	0x440(%rsp), %rax
140020dda:     	movq	$0x0, 0x440(%rsp)
140020de6:     	movq	%rax, 0x10(%rdi)
140020dea:     	movq	0x448(%rsp), %rax
140020df2:     	movq	$0x0, 0x448(%rsp)
140020dfe:     	movq	%rax, 0x18(%rdi)
140020e02:     	leaq	0x20(%rdi), %rcx
140020e06:     	movl	$0x2a8, %r8d            # imm = 0x2A8
140020e0c:     	leaq	0x450(%rsp), %rdx
140020e14:     	callq	0x140072ff0 <memcpy>
140020e19:     	addq	$0x2c8, %rdi            # imm = 0x2C8
140020e20:     	jmp	0x140020e35 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xc15>
140020e22:     	leaq	0x110(%rsp), %rcx
140020e2a:     	movq	%r12, %rdx
140020e2d:     	callq	0x140026750 <_ZNSt3__16vectorIN2kp11SoftContactENS1_13StepAllocatorIS2_EEE24__emplace_back_slow_pathB9nqe230106IJS2_EEEPS2_DpOT_>
140020e32:     	movq	%rax, %rdi
140020e35:     	movq	%rdi, 0x118(%rsp)
140020e3d:     	movq	0xf8(%rsp), %rax
140020e45:     	movq	%rax, 0x730(%rsp)
140020e4d:     	leaq	0x730(%rsp), %rcx
140020e55:     	movq	%rcx, 0x350(%rsp)
140020e5d:     	movq	%r13, 0x358(%rsp)
140020e65:     	movq	%rbp, 0x360(%rsp)
140020e6d:     	cmpq	0x100(%rsp), %rax
140020e75:     	je	0x140020ea4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xc84>
140020e77:     	movq	0x80(%rsp), %rcx
140020e7f:     	movq	%rcx, (%rax)
140020e82:     	addq	$0x8, %rax
140020e86:     	movq	%rax, 0xf8(%rsp)
140020e8e:     	movq	0x438(%rsp), %rcx
140020e96:     	testq	%rcx, %rcx
140020e99:     	jne	0x140020c00 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9e0>
140020e9f:     	jmp	0x140020c0d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9ed>
140020ea4:     	movq	%rsi, %rcx
140020ea7:     	callq	0x140026950 <_ZZNSt3__16vectorIyN2kp13StepAllocatorIyEEE12emplace_backB9nqe230106IJRKyEEERyDpOT_ENKUlvE0_clB9nqe230106Ev>
140020eac:     	movq	0x730(%rsp), %rax
140020eb4:     	movq	%rax, 0xf8(%rsp)
140020ebc:     	movq	0x438(%rsp), %rcx
140020ec4:     	testq	%rcx, %rcx
140020ec7:     	jne	0x140020c00 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9e0>
140020ecd:     	jmp	0x140020c0d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x9ed>
140020ed2:     	xorpd	%xmm0, %xmm0
140020ed6:     	movapd	%xmm0, 0x1e0(%rsp)
140020edf:     	movq	$0x0, 0x1f0(%rsp)
140020eeb:     	movq	0xf0(%rsp), %rsi
140020ef3:     	movq	0xf8(%rsp), %rdi
140020efb:     	subq	%rsi, %rdi
140020efe:     	movq	0x170(%rsp), %r15
140020f06:     	je	0x140020f42 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xd22>
140020f08:     	js	0x140023ff3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dd3>
140020f0e:     	movq	%rdi, %rcx
140020f11:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140020f16:     	movq	%rax, 0x1e0(%rsp)
140020f1e:     	movq	%rax, %r14
140020f21:     	addq	%rdi, %r14
140020f24:     	movq	%r14, 0x1f0(%rsp)
140020f2c:     	movq	%rax, %rcx
140020f2f:     	movq	%rsi, %rdx
140020f32:     	movq	%rdi, %r8
140020f35:     	callq	0x140073050 <memmove>
140020f3a:     	movq	%r14, 0x1e8(%rsp)
140020f42:     	movsd	0x28(%r15), %xmm0
140020f48:     	movsd	0x50(%r15), %xmm1
140020f4e:     	movsd	%xmm1, 0x28(%rsp)
140020f54:     	movsd	%xmm0, 0x20(%rsp)
140020f5a:     	leaq	0x7e0(%rsp), %r14
140020f62:     	leaq	0x1e0(%rsp), %r9
140020f6a:     	movq	%r14, %rcx
140020f6d:     	movq	%rbx, %rdx
140020f70:     	movq	0x48(%rsp), %r8
140020f75:     	callq	0x140044460 <_ZN2kp14MissedContactsC2ERKNSt3__16vectorINS_11ContactPairENS1_9allocatorIS3_EEEERKNS2_INS_4BodyENS4_IS9_EEEENS2_IyNS_13StepAllocatorIyEEEEdd>
140020f7a:     	movq	0x1e0(%rsp), %rcx
140020f82:     	testq	%rcx, %rcx
140020f85:     	movabsq	$0x51b3bea3677d46cf, %rdi # imm = 0x51B3BEA3677D46CF
140020f8f:     	je	0x140020f9e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xd7e>
140020f91:     	movq	%rcx, 0x1e8(%rsp)
140020f99:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140020f9e:     	movq	0x9b0(%rsp), %rax
140020fa6:     	movups	(%rax), %xmm0
140020fa9:     	movaps	%xmm0, 0x710(%rsp)
140020fb1:     	movq	0x10(%rax), %rax
140020fb5:     	movq	%rax, 0x720(%rsp)
140020fbd:     	movsd	0x28(%r15), %xmm0
140020fc3:     	mulsd	0x54b85(%rip), %xmm0    # 0x140075b50 <_ZTSNSt3__110__function6__baseIFvyEEE+0x58>
140020fcb:     	movsd	%xmm0, 0x28(%rsp)
140020fd1:     	movsd	%xmm7, 0x20(%rsp)
140020fd7:     	leaq	0x730(%rsp), %r12
140020fdf:     	leaq	0x710(%rsp), %r9
140020fe7:     	movq	%r12, %rcx
140020fea:     	movq	0x48(%rsp), %rsi
140020fef:     	movq	%rsi, %rdx
140020ff2:     	movq	%rbx, %r8
140020ff5:     	callq	0x140046070 <_ZN2kp9PairReachC2ERKNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS9_EEEENS_7Vector3Edd>
140020ffa:     	movq	%rsi, 0x80(%rsp)
140021002:     	leaq	0x130(%rsp), %rax
14002100a:     	movq	%rax, 0x88(%rsp)
140021012:     	xorpd	%xmm0, %xmm0
140021016:     	movupd	%xmm0, 0x90(%rsp)
14002101f:     	movupd	%xmm0, 0xa0(%rsp)
140021028:     	movupd	%xmm0, 0xb0(%rsp)
140021031:     	movupd	%xmm0, 0xc0(%rsp)
14002103a:     	movq	$0x0, 0xd0(%rsp)
140021046:     	movq	(%rsi), %rax
140021049:     	movq	0x8(%rsi), %rbx
14002104d:     	movupd	%xmm0, 0xd8(%rsp)
140021056:     	movq	$0x0, 0xe8(%rsp)
140021062:     	subq	%rax, %rbx
140021065:     	movabsq	$0x1fffffffffffffff, %rcx # imm = 0x1FFFFFFFFFFFFFFF
14002106f:     	je	0x14002141b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x11fb>
140021075:     	sarq	$0x3, %rbx
140021079:     	imulq	%rdi, %rbx
14002107d:     	cmpq	%rcx, %rbx
140021080:     	ja	0x140023ff8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dd8>
140021086:     	leaq	(,%rbx,8), %rsi
14002108e:     	movq	%rsi, %rcx
140021091:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140021096:     	movq	%rax, %rdi
140021099:     	movq	%rax, 0xd8(%rsp)
1400210a1:     	leaq	(%rax,%rbx,8), %rax
1400210a5:     	movq	%rax, 0xe8(%rsp)
1400210ad:     	xorl	%r13d, %r13d
1400210b0:     	movq	%rdi, %rcx
1400210b3:     	xorl	%edx, %edx
1400210b5:     	movq	%rsi, %r8
1400210b8:     	callq	0x140073000 <memset>
1400210bd:     	addq	%rsi, %rdi
1400210c0:     	movq	%rdi, 0xe0(%rsp)
1400210c8:     	movq	0x80(%rsp), %rdx
1400210d0:     	movq	(%rdx), %rax
1400210d3:     	movq	0x8(%rdx), %rsi
1400210d7:     	subq	%rax, %rsi
1400210da:     	je	0x140021421 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1201>
1400210e0:     	sarq	$0x3, %rsi
1400210e4:     	movabsq	$0x51b3bea3677d46cf, %rdi # imm = 0x51B3BEA3677D46CF
1400210ee:     	imulq	%rdi, %rsi
1400210f2:     	movabsq	$0x333333333333333, %rax # imm = 0x333333333333333
1400210fc:     	cmpq	%rax, %rsi
1400210ff:     	ja	0x140024002 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3de2>
140021105:     	movq	%rsi, %rax
140021108:     	shlq	$0x4, %rax
14002110c:     	leaq	(%rax,%rax,4), %rbx
140021110:     	movq	%rbx, %rcx
140021113:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140021118:     	movq	%rax, %r15
14002111b:     	movq	%rax, %r13
14002111e:     	leaq	-0x50(%rbx), %rcx
140021122:     	movq	%rcx, %rax
140021125:     	movabsq	$-0x3333333333333333, %rdx # imm = 0xCCCCCCCCCCCCCCCD
14002112f:     	mulq	%rdx
140021132:     	shrl	$0x6, %edx
140021135:     	incl	%edx
140021137:     	movq	%r15, %rax
14002113a:     	andl	$0x7, %edx
14002113d:     	movabsq	$0x3ff0000000000000, %r8 # imm = 0x3FF0000000000000
140021147:     	je	0x140021189 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xf69>
140021149:     	shll	$0x4, %edx
14002114c:     	leaq	(%rdx,%rdx,4), %rdx
140021150:     	xorpd	%xmm0, %xmm0
140021154:     	movq	%r13, %rax
140021157:     	nopw	(%rax,%rax)
140021160:     	movupd	%xmm0, 0x20(%rax)
140021165:     	movupd	%xmm0, 0x10(%rax)
14002116a:     	movupd	%xmm0, (%rax)
14002116e:     	movq	%r8, 0x30(%rax)
140021172:     	movupd	%xmm0, 0x38(%rax)
140021177:     	movq	$0x0, 0x48(%rax)
14002117f:     	addq	$0x50, %rax
140021183:     	addq	$-0x50, %rdx
140021187:     	jne	0x140021160 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xf40>
140021189:     	addq	%r15, %rbx
14002118c:     	cmpq	$0x230, %rcx            # imm = 0x230
140021193:     	jb	0x140021323 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1103>
140021199:     	xorpd	%xmm0, %xmm0
14002119d:     	nopl	(%rax)
1400211a0:     	movupd	%xmm0, 0x20(%rax)
1400211a5:     	movupd	%xmm0, 0x10(%rax)
1400211aa:     	movupd	%xmm0, (%rax)
1400211ae:     	movq	%r8, 0x30(%rax)
1400211b2:     	movupd	%xmm0, 0x38(%rax)
1400211b7:     	movq	$0x0, 0x48(%rax)
1400211bf:     	movupd	%xmm0, 0x50(%rax)
1400211c4:     	movupd	%xmm0, 0x60(%rax)
1400211c9:     	movupd	%xmm0, 0x70(%rax)
1400211ce:     	movq	%r8, 0x80(%rax)
1400211d5:     	movupd	%xmm0, 0x88(%rax)
1400211dd:     	movq	$0x0, 0x98(%rax)
1400211e8:     	movupd	%xmm0, 0xa0(%rax)
1400211f0:     	movupd	%xmm0, 0xb0(%rax)
1400211f8:     	movupd	%xmm0, 0xc0(%rax)
140021200:     	movq	%r8, 0xd0(%rax)
140021207:     	movupd	%xmm0, 0xd8(%rax)
14002120f:     	movq	$0x0, 0xe8(%rax)
14002121a:     	movupd	%xmm0, 0x110(%rax)
140021222:     	movupd	%xmm0, 0x100(%rax)
14002122a:     	movupd	%xmm0, 0xf0(%rax)
140021232:     	movq	%r8, 0x120(%rax)
140021239:     	movupd	%xmm0, 0x128(%rax)
140021241:     	movq	$0x0, 0x138(%rax)
14002124c:     	movupd	%xmm0, 0x140(%rax)
140021254:     	movupd	%xmm0, 0x150(%rax)
14002125c:     	movupd	%xmm0, 0x160(%rax)
140021264:     	movq	%r8, 0x170(%rax)
14002126b:     	movupd	%xmm0, 0x178(%rax)
140021273:     	movq	$0x0, 0x188(%rax)
14002127e:     	movupd	%xmm0, 0x190(%rax)
140021286:     	movupd	%xmm0, 0x1a0(%rax)
14002128e:     	movupd	%xmm0, 0x1b0(%rax)
140021296:     	movq	%r8, 0x1c0(%rax)
14002129d:     	movupd	%xmm0, 0x1c8(%rax)
1400212a5:     	movq	$0x0, 0x1d8(%rax)
1400212b0:     	movupd	%xmm0, 0x200(%rax)
1400212b8:     	movupd	%xmm0, 0x1f0(%rax)
1400212c0:     	movupd	%xmm0, 0x1e0(%rax)
1400212c8:     	movq	%r8, 0x210(%rax)
1400212cf:     	movupd	%xmm0, 0x218(%rax)
1400212d7:     	movq	$0x0, 0x228(%rax)
1400212e2:     	movupd	%xmm0, 0x250(%rax)
1400212ea:     	movupd	%xmm0, 0x240(%rax)
1400212f2:     	movupd	%xmm0, 0x230(%rax)
1400212fa:     	movq	%r8, 0x260(%rax)
140021301:     	movupd	%xmm0, 0x268(%rax)
140021309:     	movq	$0x0, 0x278(%rax)
140021314:     	addq	$0x280, %rax            # imm = 0x280
14002131a:     	cmpq	%rbx, %rax
14002131d:     	jne	0x1400211a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0xf80>
140021323:     	leaq	(%rsi,%rsi,4), %rax
140021327:     	shlq	$0x4, %rax
14002132b:     	addq	%rax, %r15
14002132e:     	movq	0x80(%rsp), %rdx
140021336:     	movq	(%rdx), %rax
140021339:     	cmpq	%rax, 0x8(%rdx)
14002133d:     	je	0x140021426 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1206>
140021343:     	leaq	0x448(%rsp), %rcx
14002134b:     	xorl	%r8d, %r8d
14002134e:     	movq	%r13, %r9
140021351:     	xorl	%r10d, %r10d
140021354:     	nopw	%cs:(%rax,%rax)
140021360:     	movq	0x10(%rax,%r8), %rdx
140021365:     	movq	%rdx, 0x440(%rsp)
14002136d:     	movups	(%rax,%r8), %xmm0
140021372:     	movaps	%xmm0, 0x430(%rsp)
14002137a:     	movq	0x60(%rax,%r8), %rdx
14002137f:     	movq	%rdx, 0x10(%rcx)
140021383:     	movups	0x50(%rax,%r8), %xmm0
140021389:     	movups	%xmm0, (%rcx)
14002138c:     	movups	0x18(%rax,%r8), %xmm0
140021392:     	movups	0x28(%rax,%r8), %xmm1
140021398:     	movups	%xmm1, 0x28(%rcx)
14002139c:     	movups	%xmm0, 0x18(%rcx)
1400213a0:     	movaps	0x470(%rsp), %xmm0
1400213a8:     	movups	%xmm0, 0x40(%r9)
1400213ad:     	movapd	0x430(%rsp), %xmm0
1400213b6:     	movapd	0x440(%rsp), %xmm1
1400213bf:     	movapd	0x450(%rsp), %xmm2
1400213c8:     	movapd	0x460(%rsp), %xmm3
1400213d1:     	movupd	%xmm3, 0x30(%r9)
1400213d7:     	movupd	%xmm2, 0x20(%r9)
1400213dd:     	movupd	%xmm1, 0x10(%r9)
1400213e3:     	movupd	%xmm0, (%r9)
1400213e8:     	incq	%r10
1400213eb:     	movq	0x80(%rsp), %rdx
1400213f3:     	movq	(%rdx), %rax
1400213f6:     	movq	0x8(%rdx), %r11
1400213fa:     	subq	%rax, %r11
1400213fd:     	sarq	$0x3, %r11
140021401:     	imulq	%rdi, %r11
140021405:     	addq	$0x50, %r9
140021409:     	addq	$0x178, %r8             # imm = 0x178
140021410:     	cmpq	%r11, %r10
140021413:     	jb	0x140021360 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1140>
140021419:     	jmp	0x140021426 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1206>
14002141b:     	xorl	%r13d, %r13d
14002141e:     	movq	%rsi, %rdx
140021421:     	xorl	%ebx, %ebx
140021423:     	xorl	%r15d, %r15d
140021426:     	movq	0x90(%rsp), %rcx
14002142e:     	testq	%rcx, %rcx
140021431:     	je	0x140021463 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1243>
140021433:     	leaq	0x90(%rsp), %rsi
14002143b:     	movq	%rcx, 0x98(%rsp)
140021443:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140021448:     	xorpd	%xmm0, %xmm0
14002144c:     	movupd	%xmm0, (%rsi)
140021450:     	movq	$0x0, 0x10(%rsi)
140021458:     	movq	0x80(%rsp), %rdx
140021460:     	movq	(%rdx), %rax
140021463:     	movq	%r13, 0x90(%rsp)
14002146b:     	movq	%rbx, 0x98(%rsp)
140021473:     	movq	%r15, 0xa0(%rsp)
14002147b:     	cmpq	%rax, 0x8(%rdx)
14002147f:     	movq	0x248(%rsp), %r15
140021487:     	je	0x1400215d9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13b9>
14002148d:     	xorl	%esi, %esi
14002148f:     	xorpd	%xmm7, %xmm7
140021493:     	xorpd	%xmm11, %xmm11
140021498:     	xorl	%edi, %edi
14002149a:     	xorl	%ebx, %ebx
14002149c:     	jmp	0x1400214ff <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12df>
14002149e:     	nop
1400214a0:     	movq	0x88(%rax,%rdi), %rcx
1400214a8:     	movq	(%rcx), %rax
1400214ab:     	callq	*0x18(%rax)
1400214ae:     	addsd	%xmm0, %xmm8
1400214b3:     	movq	0xd8(%rsp), %rax
1400214bb:     	movsd	%xmm8, (%rax,%rbx,8)
1400214c1:     	movq	0x80(%rsp), %rdx
1400214c9:     	movq	(%rdx), %rax
1400214cc:     	incq	%rbx
1400214cf:     	movq	0x8(%rdx), %rcx
1400214d3:     	subq	%rax, %rcx
1400214d6:     	sarq	$0x3, %rcx
1400214da:     	movabsq	$0x51b3bea3677d46cf, %r8 # imm = 0x51B3BEA3677D46CF
1400214e4:     	imulq	%r8, %rcx
1400214e8:     	addq	$0x178, %rdi            # imm = 0x178
1400214ef:     	addq	$0xb8, %rsi
1400214f6:     	cmpq	%rcx, %rbx
1400214f9:     	jae	0x1400215d9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13b9>
1400214ff:     	movq	0x88(%rsp), %rcx
140021507:     	movq	(%rcx), %rcx
14002150a:     	movsd	0x78(%rcx,%rsi), %xmm0
140021510:     	ucomisd	%xmm7, %xmm0
140021514:     	jne	0x140021518 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12f8>
140021516:     	jnp	0x140021560 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1340>
140021518:     	xorpd	%xmm8, %xmm8
14002151d:     	cmpb	$0x1, 0xd0(%rax,%rdi)
140021525:     	jne	0x1400214a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1280>
14002152b:     	movsd	0x98(%rax,%rdi), %xmm0
140021534:     	mulsd	%xmm0, %xmm0
140021538:     	movupd	0xa0(%rax,%rdi), %xmm1
140021541:     	mulpd	%xmm1, %xmm1
140021545:     	addsd	%xmm1, %xmm0
140021549:     	unpckhpd	%xmm1, %xmm1            # xmm1 = xmm1[1,1]
14002154d:     	addsd	%xmm0, %xmm1
140021551:     	xorps	%xmm8, %xmm8
140021555:     	sqrtsd	%xmm1, %xmm8
14002155a:     	jmp	0x1400214a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1280>
14002155f:     	nop
140021560:     	movsd	0x68(%rax,%rdi), %xmm0
140021566:     	ucomisd	%xmm7, %xmm0
14002156a:     	jne	0x1400214cc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12ac>
140021570:     	jp	0x1400214cc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12ac>
140021576:     	movupd	0x148(%rax,%rdi), %xmm0
14002157f:     	movupd	0x158(%rax,%rdi), %xmm1
140021588:     	cmpneqpd	%xmm11, %xmm1
14002158e:     	cmpneqpd	%xmm11, %xmm0
140021594:     	shufps	$0x88, %xmm1, %xmm0     # xmm0 = xmm0[0,2],xmm1[0,2]
140021598:     	movmskps	%xmm0, %ecx
14002159b:     	testl	%ecx, %ecx
14002159d:     	jne	0x1400215c5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13a5>
14002159f:     	movsd	0x168(%rax,%rdi), %xmm0
1400215a8:     	ucomisd	%xmm7, %xmm0
1400215ac:     	jne	0x1400215c5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13a5>
1400215ae:     	jp	0x1400215c5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13a5>
1400215b0:     	movsd	0x170(%rax,%rdi), %xmm0
1400215b9:     	ucomisd	%xmm7, %xmm0
1400215bd:     	jne	0x1400215c5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x13a5>
1400215bf:     	jnp	0x1400214cc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12ac>
1400215c5:     	cmpq	$0x0, 0x88(%rax,%rdi)
1400215ce:     	jne	0x140021518 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12f8>
1400215d4:     	jmp	0x1400214cc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x12ac>
1400215d9:     	movq	0x9c8(%rsp), %rsi
1400215e1:     	movq	0x8(%r15), %rdx
1400215e5:     	subq	(%r15), %rdx
1400215e8:     	sarq	$0x3, %rdx
1400215ec:     	movq	%rsi, %rcx
1400215ef:     	callq	0x140025be0 <_ZNSt3__16vectorINS0_IdNS_9allocatorIdEEEENS1_IS3_EEE6resizeB9nqe230106Ey>
1400215f4:     	movq	%r15, %rdi
1400215f7:     	xorpd	%xmm7, %xmm7
1400215fb:     	movapd	%xmm7, 0x410(%rsp)
140021604:     	movapd	%xmm7, 0x400(%rsp)
14002160d:     	movapd	%xmm7, 0x3f0(%rsp)
140021616:     	movapd	%xmm7, 0x3e0(%rsp)
14002161f:     	movapd	%xmm7, 0x3d0(%rsp)
140021628:     	movapd	%xmm7, 0x3c0(%rsp)
140021631:     	movapd	%xmm7, 0x3b0(%rsp)
14002163a:     	movapd	%xmm7, 0x3a0(%rsp)
140021643:     	movapd	%xmm7, 0x390(%rsp)
14002164c:     	movapd	%xmm7, 0x380(%rsp)
140021655:     	movapd	%xmm7, 0x370(%rsp)
14002165e:     	movapd	%xmm7, 0x360(%rsp)
140021667:     	movapd	%xmm7, 0x350(%rsp)
140021670:     	movq	$0x0, 0x420(%rsp)
14002167c:     	movq	0x170(%rsp), %r15
140021684:     	movzbl	0x60(%r15), %eax
140021689:     	movb	%al, 0x28(%rsp)
14002168d:     	movq	%rsi, 0x20(%rsp)
140021692:     	leaq	0x350(%rsp), %rcx
14002169a:     	leaq	0x130(%rsp), %r9
1400216a2:     	movq	%rdi, %rdx
1400216a5:     	movq	0x48(%rsp), %rsi
1400216aa:     	movq	%rsi, %r8
1400216ad:     	callq	0x1400243d0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb>
1400216b2:     	movapd	%xmm7, 0x290(%rsp)
1400216bb:     	movapd	%xmm7, 0x280(%rsp)
1400216c4:     	movapd	%xmm7, 0x270(%rsp)
1400216cd:     	movq	0x30(%r15), %xmm0
1400216d3:     	pshufd	$0xe1, %xmm0, %xmm0     # xmm0 = xmm0[1,0,2,3]
1400216d8:     	movq	%xmm0, 0x2a0(%rsp)
1400216e1:     	movsd	%xmm10, 0x2a8(%rsp)
1400216eb:     	movapd	%xmm7, 0x2b0(%rsp)
1400216f4:     	movapd	%xmm7, 0x2c0(%rsp)
1400216fd:     	movapd	%xmm7, 0x2d0(%rsp)
140021706:     	leaq	0x110(%rsp), %rax
14002170e:     	movq	%rax, 0x188(%rsp)
140021716:     	leaq	0x270(%rsp), %rax
14002171e:     	movq	%rax, 0x190(%rsp)
140021726:     	movq	%r14, 0x198(%rsp)
14002172e:     	movq	%r12, 0x1a0(%rsp)
140021736:     	leaq	0x300(%rsp), %rax
14002173e:     	movq	%rax, 0x1a8(%rsp)
140021746:     	movq	%rdi, 0x1b0(%rsp)
14002174e:     	movsd	0x20(%r15), %xmm0
140021754:     	movsd	%xmm0, 0x1b8(%rsp)
14002175d:     	movsd	0x70(%r15), %xmm0
140021763:     	movsd	%xmm0, 0x1c0(%rsp)
14002176c:     	movsd	0x50(%r15), %xmm0
140021772:     	movsd	%xmm0, 0x1c8(%rsp)
14002177b:     	leaq	0x80(%r15), %rax
140021782:     	movq	%rax, 0x1d0(%rsp)
14002178a:     	movq	(%rsi), %rax
14002178d:     	movq	0x8(%rsi), %rcx
140021791:     	cmpq	%rcx, %rax
140021794:     	je	0x1400217e2 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x15c2>
140021796:     	xorpd	%xmm0, %xmm0
14002179a:     	movabsq	$0x51b3bea3677d46cf, %rdi # imm = 0x51B3BEA3677D46CF
1400217a4:     	leaq	0x130(%rsp), %r12
1400217ac:     	nopl	(%rax)
1400217b0:     	movsd	0x100(%rax), %xmm1
1400217b8:     	ucomisd	%xmm0, %xmm1
1400217bc:     	jne	0x14002180b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x15eb>
1400217be:     	jp	0x14002180b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x15eb>
1400217c0:     	addq	$0x178, %rax            # imm = 0x178
1400217c6:     	cmpq	%rcx, %rax
1400217c9:     	jne	0x1400217b0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1590>
1400217cb:     	xorl	%eax, %eax
1400217cd:     	movb	%al, 0x1d8(%rsp)
1400217d4:     	movq	0xa0(%r15), %rcx
1400217db:     	testq	%rcx, %rcx
1400217de:     	jne	0x140021820 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1600>
1400217e0:     	jmp	0x140021839 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1619>
1400217e2:     	xorl	%eax, %eax
1400217e4:     	movabsq	$0x51b3bea3677d46cf, %rdi # imm = 0x51B3BEA3677D46CF
1400217ee:     	leaq	0x130(%rsp), %r12
1400217f6:     	movb	%al, 0x1d8(%rsp)
1400217fd:     	movq	0xa0(%r15), %rcx
140021804:     	testq	%rcx, %rcx
140021807:     	jne	0x140021820 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1600>
140021809:     	jmp	0x140021839 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1619>
14002180b:     	movb	$0x1, %al
14002180d:     	movb	%al, 0x1d8(%rsp)
140021814:     	movq	0xa0(%r15), %rcx
14002181b:     	testq	%rcx, %rcx
14002181e:     	je	0x140021839 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1619>
140021820:     	movl	$0x5, 0x430(%rsp)
14002182b:     	movq	(%rcx), %rax
14002182e:     	leaq	0x430(%rsp), %rdx
140021836:     	callq	*0x30(%rax)
140021839:     	cmpl	$0x0, (%r15)
14002183d:     	jle	0x1400239f1 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x37d1>
140021843:     	leaq	0x450(%rsp), %r13
14002184b:     	leaq	0x430(%rsp), %rbx
140021853:     	xorpd	%xmm7, %xmm7
140021857:     	xorpd	%xmm10, %xmm10
14002185c:     	movapd	0x5435b(%rip), %xmm12   # 0x140075bc0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xc8>
140021865:     	movapd	0x54342(%rip), %xmm13   # 0x140075bb0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xb8>
14002186e:     	movl	$0x0, 0x7c(%rsp)
140021876:     	jmp	0x140021893 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1673>
140021878:     	nopl	(%rax,%rax)
140021880:     	movl	0x7c(%rsp), %eax
140021884:     	incl	%eax
140021886:     	movl	%eax, 0x7c(%rsp)
14002188a:     	cmpl	(%r15), %eax
14002188d:     	jge	0x1400239f1 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x37d1>
140021893:     	movq	0x130(%rsp), %rax
14002189b:     	movq	0x138(%rsp), %rcx
1400218a3:     	subq	%rax, %rcx
1400218a6:     	movabsq	$-0x2c8590b21642c859, %r8 # imm = 0xD37A6F4DE9BD37A7
1400218b0:     	je	0x140021b10 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x18f0>
1400218b6:     	movq	0x9b0(%rsp), %rdx
1400218be:     	movupd	(%rdx), %xmm0
1400218c2:     	sarq	$0x3, %rcx
1400218c6:     	imulq	%r8, %rcx
1400218ca:     	mulpd	0x700(%rsp), %xmm0
1400218d3:     	movapd	%xmm0, 0x250(%rsp)
1400218dc:     	movsd	0x10(%rdx), %xmm0
1400218e1:     	mulsd	0x50(%rsp), %xmm0
1400218e7:     	movsd	%xmm0, 0x200(%rsp)
1400218f0:     	movq	0x48(%rsp), %rdx
1400218f5:     	movq	(%rdx), %rdx
1400218f8:     	movl	$0x140, %r8d            # imm = 0x140
1400218fe:     	addq	%r8, %rdx
140021901:     	jmp	0x140021a02 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x17e2>
140021906:     	nopw	%cs:(%rax,%rax)
140021910:     	movapd	0x50(%rsp), %xmm6
140021916:     	mulsd	%xmm6, %xmm5
14002191a:     	mulsd	%xmm5, %xmm1
14002191e:     	mulsd	%xmm5, %xmm9
140021923:     	mulsd	%xmm0, %xmm5
140021927:     	addsd	%xmm14, %xmm1
14002192c:     	unpckhpd	%xmm14, %xmm14          # xmm14 = xmm14[1,1]
140021931:     	addsd	%xmm9, %xmm14
140021936:     	addsd	%xmm5, %xmm15
14002193b:     	movsd	%xmm1, (%rax)
14002193f:     	movsd	%xmm14, 0x8(%rax)
140021945:     	movsd	%xmm15, 0x10(%rax)
14002194b:     	movsd	-0x10(%rdx), %xmm11
140021951:     	movsd	-0x8(%rdx), %xmm8
140021957:     	movsd	(%rdx), %xmm5
14002195b:     	movsd	0x30(%rax), %xmm0
140021960:     	mulsd	%xmm11, %xmm0
140021965:     	movsd	0x38(%rax), %xmm1
14002196a:     	mulsd	%xmm8, %xmm1
14002196f:     	addsd	%xmm0, %xmm1
140021973:     	movsd	0x40(%rax), %xmm9
140021979:     	mulsd	%xmm5, %xmm9
14002197e:     	addsd	%xmm1, %xmm9
140021983:     	movsd	0x48(%rax), %xmm0
140021988:     	mulsd	%xmm11, %xmm0
14002198d:     	movsd	0x50(%rax), %xmm1
140021992:     	mulsd	%xmm8, %xmm1
140021997:     	addsd	%xmm0, %xmm1
14002199b:     	movsd	0x58(%rax), %xmm0
1400219a0:     	mulsd	%xmm5, %xmm0
1400219a4:     	mulsd	0x60(%rax), %xmm11
1400219aa:     	addsd	%xmm1, %xmm0
1400219ae:     	mulsd	0x68(%rax), %xmm8
1400219b4:     	addsd	%xmm11, %xmm8
1400219b9:     	mulsd	0x70(%rax), %xmm5
1400219be:     	addsd	%xmm8, %xmm5
1400219c3:     	mulsd	%xmm6, %xmm9
1400219c8:     	mulsd	%xmm6, %xmm0
1400219cc:     	mulsd	%xmm6, %xmm5
1400219d0:     	addsd	%xmm9, %xmm3
1400219d5:     	addsd	%xmm0, %xmm4
1400219d9:     	addsd	%xmm5, %xmm2
1400219dd:     	movsd	%xmm3, 0x18(%rax)
1400219e2:     	movsd	%xmm4, 0x20(%rax)
1400219e7:     	movsd	%xmm2, 0x28(%rax)
1400219ec:     	addq	$0x178, %rdx            # imm = 0x178
1400219f3:     	addq	$0xb8, %rax
1400219f9:     	decq	%rcx
1400219fc:     	je	0x140021b10 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x18f0>
140021a02:     	movsd	0x78(%rax), %xmm5
140021a07:     	ucomisd	%xmm5, %xmm7
140021a0b:     	jae	0x1400219ec <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x17cc>
140021a0d:     	movsd	-0x38(%rdx), %xmm2
140021a12:     	movapd	0x50(%rsp), %xmm0
140021a18:     	mulsd	%xmm0, %xmm2
140021a1c:     	movsd	0x5417c(%rip), %xmm1    # 0x140075ba0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xa8>
140021a24:     	addsd	%xmm1, %xmm2
140021a28:     	movapd	%xmm1, %xmm14
140021a2d:     	divsd	%xmm2, %xmm14
140021a32:     	movsd	0x10(%rax), %xmm15
140021a38:     	mulsd	%xmm14, %xmm15
140021a3d:     	addsd	0x200(%rsp), %xmm15
140021a47:     	movupd	(%rax), %xmm2
140021a4b:     	unpcklpd	%xmm14, %xmm14          # xmm14 = xmm14[0,0]
140021a50:     	mulpd	%xmm2, %xmm14
140021a55:     	addpd	0x250(%rsp), %xmm14
140021a5f:     	movupd	%xmm14, (%rax)
140021a64:     	movsd	%xmm15, 0x10(%rax)
140021a6a:     	movsd	-0x30(%rdx), %xmm3
140021a6f:     	mulsd	%xmm0, %xmm3
140021a73:     	addsd	%xmm1, %xmm3
140021a77:     	movapd	%xmm1, %xmm2
140021a7b:     	divsd	%xmm3, %xmm2
140021a7f:     	movsd	0x18(%rax), %xmm3
140021a84:     	mulsd	%xmm2, %xmm3
140021a88:     	movsd	0x20(%rax), %xmm4
140021a8d:     	mulsd	%xmm2, %xmm4
140021a91:     	mulsd	0x28(%rax), %xmm2
140021a96:     	movsd	%xmm3, 0x18(%rax)
140021a9b:     	movsd	%xmm4, 0x20(%rax)
140021aa0:     	movsd	%xmm2, 0x28(%rax)
140021aa5:     	movupd	-0x18(%rdx), %xmm0
140021aaa:     	movupd	-0x28(%rdx), %xmm1
140021aaf:     	movsd	-0x20(%rdx), %xmm9
140021ab5:     	movapd	%xmm0, %xmm11
140021aba:     	cmpneqpd	%xmm10, %xmm11
140021ac0:     	movapd	%xmm1, %xmm8
140021ac5:     	cmpneqpd	%xmm10, %xmm8
140021acb:     	shufps	$0x88, %xmm11, %xmm8    # xmm8 = xmm8[0,2],xmm11[0,2]
140021ad0:     	movmskps	%xmm8, %r8d
140021ad4:     	testl	%r8d, %r8d
140021ad7:     	jne	0x140021910 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x16f0>
140021add:     	movsd	-0x8(%rdx), %xmm8
140021ae3:     	ucomisd	%xmm7, %xmm8
140021ae8:     	jne	0x140021910 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x16f0>
140021aee:     	jp	0x140021910 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x16f0>
140021af4:     	movsd	(%rdx), %xmm8
140021af9:     	ucomisd	%xmm7, %xmm8
140021afe:     	jne	0x140021910 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x16f0>
140021b04:     	jp	0x140021910 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x16f0>
140021b0a:     	jmp	0x1400219ec <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x17cc>
140021b0f:     	nop
140021b10:     	leaq	0x368(%rsp), %rcx
140021b18:     	movq	%r12, %rdx
140021b1b:     	callq	0x140049810 <_ZNK2kp12DirectJoints9warmStartERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>
140021b20:     	movq	0x350(%rsp), %rsi
140021b28:     	movq	0x358(%rsp), %rdi
140021b30:     	cmpq	%rdi, %rsi
140021b33:     	je	0x140021b57 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1937>
140021b35:     	nopw	%cs:(%rax,%rax)
140021b40:     	movq	%rsi, %rcx
140021b43:     	movq	%r12, %rdx
140021b46:     	callq	0x14004b190 <_ZNK2kp9SoftJoint9warmStartERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>
140021b4b:     	addq	$0x270, %rsi            # imm = 0x270
140021b52:     	cmpq	%rdi, %rsi
140021b55:     	jne	0x140021b40 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1920>
140021b57:     	leaq	0x54672(%rip), %rax     # 0x1400761d0 <_ZTVNSt3__110__function6__funcIZNK2kp8SoftStep4stepERNS_6vectorINS2_4BodyENS_9allocatorIS5_EEEERKNS4_INS2_11ContactPairENS6_ISA_EEEERKNS2_8JointSetENS2_7Vector3EdRNS2_13ContactForcesERNS4_INS4_IdNS6_IdEEEENS6_ISM_EEEEE3$_0FvyEEE+0x10>
140021b5e:     	movq	%rax, 0x430(%rsp)
140021b66:     	leaq	0x110(%rsp), %rdx
140021b6e:     	movq	%rdx, 0x438(%rsp)
140021b76:     	movq	%r12, 0x440(%rsp)
140021b7e:     	movq	%rbx, 0x450(%rsp)
140021b86:     	leaq	0x270(%rsp), %rcx
140021b8e:     	movq	%r12, %r8
140021b91:     	movq	%rbx, %r9
140021b94:     	callq	0x14004b8f0 <_ZN2kp13ContactLevels4eachERKNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_10SolverBodyENS4_IS9_EEEERKNS1_8functionIFvyEEE>
140021b99:     	movq	0x450(%rsp), %rcx
140021ba1:     	cmpq	%rbx, %rcx
140021ba4:     	je	0x140021bc0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x19a0>
140021ba6:     	movl	$0x28, %eax
140021bab:     	testq	%rcx, %rcx
140021bae:     	jne	0x140021bc5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x19a5>
140021bb0:     	movq	0xa0(%r15), %rcx
140021bb7:     	testq	%rcx, %rcx
140021bba:     	jne	0x140021bd7 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x19b7>
140021bbc:     	jmp	0x140021beb <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x19cb>
140021bbe:     	nop
140021bc0:     	movl	$0x20, %eax
140021bc5:     	movq	(%rcx), %rdx
140021bc8:     	callq	*(%rdx,%rax)
140021bcb:     	movq	0xa0(%r15), %rcx
140021bd2:     	testq	%rcx, %rcx
140021bd5:     	je	0x140021beb <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x19cb>
140021bd7:     	movl	$0x6, 0x430(%rsp)
140021be2:     	movq	(%rcx), %rax
140021be5:     	movq	%rbx, %rdx
140021be8:     	callq	*0x30(%rax)
140021beb:     	movsd	0x20(%r15), %xmm8
140021bf1:     	movsd	0x68(%r15), %xmm2
140021bf7:     	leaq	0x368(%rsp), %rcx
140021bff:     	movq	%r12, %rdx
140021c02:     	movapd	0x50(%rsp), %xmm3
140021c08:     	callq	0x140049880 <_ZNK2kp12DirectJoints5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEdd>
140021c0d:     	movq	0x350(%rsp), %rsi
140021c15:     	movq	0x358(%rsp), %rdi
140021c1d:     	cmpq	%rdi, %rsi
140021c20:     	je	0x140021c64 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1a44>
140021c22:     	nopw	%cs:(%rax,%rax)
140021c30:     	movsd	%xmm8, 0x28(%rsp)
140021c37:     	leaq	0x2e8(%rsp), %rax
140021c3f:     	movq	%rax, 0x20(%rsp)
140021c44:     	movq	%rsi, %rcx
140021c47:     	movq	%r12, %rdx
140021c4a:     	movb	$0x1, %r8b
140021c4d:     	movapd	0x50(%rsp), %xmm3
140021c53:     	callq	0x14004b210 <_ZN2kp9SoftJoint5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEbdRKNS_8SoftnessEd>
140021c58:     	addq	$0x270, %rsi            # imm = 0x270
140021c5f:     	cmpq	%rdi, %rsi
140021c62:     	jne	0x140021c30 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1a10>
140021c64:     	movq	0xa0(%r15), %rcx
140021c6b:     	testq	%rcx, %rcx
140021c6e:     	je	0x140021c84 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1a64>
140021c70:     	movl	$0x7, 0x430(%rsp)
140021c7b:     	movq	(%rcx), %rax
140021c7e:     	movq	%rbx, %rdx
140021c81:     	callq	*0x30(%rax)
140021c84:     	movl	(%r15), %eax
140021c87:     	subl	0x7c(%rsp), %eax
140021c8b:     	xorps	%xmm0, %xmm0
140021c8e:     	cvtsi2sd	%eax, %xmm0
140021c92:     	mulsd	0x50(%rsp), %xmm0
140021c98:     	movsd	%xmm0, 0x268(%rsp)
140021ca1:     	leaq	0x53fb0(%rip), %rax     # 0x140075c58 <_ZTVNSt3__110__function6__funcIZN2kp12_GLOBAL__N_112LiveContacts12solveAndMoveERNS3_6MovingEddEUlRKNS2_11ContactPairEE_FNS2_11SoftContactES9_EEE+0x10>
140021ca8:     	movq	%rax, 0x210(%rsp)
140021cb0:     	leaq	0x188(%rsp), %rax
140021cb8:     	movq	%rax, 0x218(%rsp)
140021cc0:     	leaq	0x210(%rsp), %rax
140021cc8:     	movq	%rax, 0x230(%rsp)
140021cd0:     	movl	$0x0, 0x184(%rsp)
140021cdb:     	movq	0x188(%rsp), %rdx
140021ce3:     	jmp	0x140021d07 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1ae7>
140021ce5:     	nopw	%cs:(%rax,%rax)
140021cf0:     	incl	0x184(%rsp)
140021cf7:     	leaq	0x430(%rsp), %rbx
140021cff:     	leaq	0x450(%rsp), %r13
140021d07:     	movq	0x190(%rsp), %rcx
140021d0f:     	movq	0x80(%rsp), %r8
140021d17:     	movq	0x88(%rsp), %r9
140021d1f:     	movsd	0x1b8(%rsp), %xmm0
140021d28:     	movsd	%xmm0, 0x30(%rsp)
140021d2e:     	movapd	0x50(%rsp), %xmm0
140021d34:     	movsd	%xmm0, 0x28(%rsp)
140021d3a:     	movq	$0x0, 0x38(%rsp)
140021d43:     	movb	$0x1, 0x20(%rsp)
140021d48:     	callq	0x14004d6c0 <_ZN2kp13IslandNormals5solveERNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_4BodyENS1_9allocatorIS8_EEEERNS2_INS_10SolverBodyENS4_ISE_EEEEbddPKNS2_IcNS4_IcEEEE>
140021d4d:     	cmpb	$0x1, 0x1d8(%rsp)
140021d55:     	jne	0x140021d95 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1b75>
140021d57:     	movq	0x188(%rsp), %rax
140021d5f:     	movq	(%rax), %rsi
140021d62:     	movq	0x8(%rax), %rdi
140021d66:     	cmpq	%rdi, %rsi
140021d69:     	je	0x140021d95 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1b75>
140021d6b:     	nopl	(%rax,%rax)
140021d70:     	movq	0x88(%rsp), %rdx
140021d78:     	movsd	0x1c0(%rsp), %xmm2
140021d81:     	movq	%rsi, %rcx
140021d84:     	callq	0x1400429c0 <_ZN2kp11SoftContact6bounceERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd>
140021d89:     	addq	$0x2c8, %rsi            # imm = 0x2C8
140021d90:     	cmpq	%rdi, %rsi
140021d93:     	jne	0x140021d70 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1b50>
140021d95:     	movq	0x1d0(%rsp), %rax
140021d9d:     	movq	0x20(%rax), %rcx
140021da1:     	testq	%rcx, %rcx
140021da4:     	je	0x140021dba <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1b9a>
140021da6:     	movl	$0x8, 0x430(%rsp)
140021db1:     	movq	(%rcx), %rax
140021db4:     	movq	%rbx, %rdx
140021db7:     	callq	*0x30(%rax)
140021dba:     	xorl	%ebp, %ebp
140021dbc:     	movabsq	$0x51b3bea3677d46cf, %r8 # imm = 0x51B3BEA3677D46CF
140021dc6:     	leaq	0x150(%rsp), %r14
140021dce:     	jmp	0x140021de5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1bc5>
140021dd0:     	incl	%ebp
140021dd2:     	cmpl	$0x3, %ebp
140021dd5:     	movabsq	$0x51b3bea3677d46cf, %r8 # imm = 0x51B3BEA3677D46CF
140021ddf:     	je	0x140022530 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2310>
140021de5:     	movq	0x80(%rsp), %rdx
140021ded:     	movq	(%rdx), %rax
140021df0:     	movq	0x8(%rdx), %rcx
140021df4:     	subq	%rax, %rcx
140021df7:     	je	0x140022000 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1de0>
140021dfd:     	sarq	$0x3, %rcx
140021e01:     	imulq	%r8, %rcx
140021e05:     	movq	0x88(%rsp), %r8
140021e0d:     	movq	(%r8), %r8
140021e10:     	addq	$0x18, %rax
140021e14:     	jmp	0x140021e36 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1c16>
140021e16:     	nopw	%cs:(%rax,%rax)
140021e20:     	addq	$0x178, %rax            # imm = 0x178
140021e26:     	addq	$0xb8, %r8
140021e2d:     	decq	%rcx
140021e30:     	je	0x140022000 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1de0>
140021e36:     	movsd	0x78(%r8), %xmm0
140021e3c:     	ucomisd	%xmm7, %xmm0
140021e40:     	jne	0x140021e44 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1c24>
140021e42:     	jnp	0x140021e20 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1c00>
140021e44:     	movupd	(%r8), %xmm1
140021e49:     	movupd	0x58(%rax), %xmm2
140021e4e:     	movapd	%xmm13, %xmm15
140021e53:     	divpd	%xmm2, %xmm15
140021e58:     	movhpd	0x68(%rax), %xmm0       # xmm0 = xmm0[0],mem[0]
140021e5d:     	movapd	%xmm13, %xmm3
140021e62:     	divpd	%xmm0, %xmm3
140021e66:     	movsd	0x10(%r8), %xmm0
140021e6c:     	mulsd	%xmm3, %xmm0
140021e70:     	movapd	%xmm3, %xmm2
140021e74:     	unpcklpd	%xmm3, %xmm2            # xmm2 = xmm2[0],xmm3[0]
140021e78:     	mulpd	%xmm1, %xmm2
140021e7c:     	movupd	%xmm2, 0x20(%rax)
140021e81:     	movsd	%xmm0, 0x30(%rax)
140021e86:     	movupd	0x18(%r8), %xmm4
140021e8c:     	movupd	0x20(%r8), %xmm5
140021e92:     	movsd	(%rax), %xmm14
140021e97:     	movsd	0x8(%rax), %xmm2
140021e9c:     	movupd	0x10(%rax), %xmm1
140021ea1:     	movapd	%xmm1, %xmm8
140021ea6:     	shufpd	$0x1, %xmm2, %xmm8      # xmm8 = xmm8[1],xmm2[0]
140021eac:     	movapd	%xmm5, %xmm9
140021eb1:     	mulpd	%xmm8, %xmm9
140021eb6:     	shufpd	$0x1, %xmm4, %xmm5      # xmm5 = xmm5[1],xmm4[0]
140021ebb:     	movupd	0x8(%rax), %xmm11
140021ec1:     	mulpd	%xmm5, %xmm11
140021ec6:     	mulpd	%xmm1, %xmm5
140021eca:     	subpd	%xmm5, %xmm9
140021ecf:     	addpd	%xmm9, %xmm9
140021ed4:     	movapd	%xmm14, %xmm0
140021ed9:     	unpcklpd	%xmm14, %xmm0           # xmm0 = xmm0[0],xmm14[0]
140021ede:     	movapd	%xmm0, %xmm5
140021ee2:     	mulpd	%xmm9, %xmm5
140021ee7:     	addpd	%xmm4, %xmm5
140021eeb:     	mulpd	%xmm8, %xmm4
140021ef0:     	subpd	%xmm4, %xmm11
140021ef5:     	addpd	%xmm11, %xmm11
140021efa:     	movapd	%xmm11, %xmm6
140021eff:     	unpckhpd	%xmm11, %xmm6           # xmm6 = xmm6[1],xmm11[1]
140021f04:     	mulsd	%xmm14, %xmm6
140021f09:     	addsd	0x28(%r8), %xmm6
140021f0f:     	movapd	%xmm8, %xmm4
140021f14:     	mulpd	%xmm11, %xmm4
140021f19:     	shufpd	$0x1, %xmm9, %xmm11     # xmm11 = xmm11[1],xmm9[0]
140021f1f:     	mulpd	%xmm1, %xmm11
140021f24:     	subpd	%xmm11, %xmm4
140021f29:     	addpd	%xmm5, %xmm4
140021f2d:     	mulpd	%xmm15, %xmm4
140021f32:     	movapd	%xmm1, %xmm5
140021f36:     	unpcklpd	%xmm2, %xmm5            # xmm5 = xmm5[0],xmm2[0]
140021f3a:     	mulpd	%xmm9, %xmm5
140021f3f:     	movapd	%xmm5, %xmm9
140021f44:     	unpckhpd	%xmm5, %xmm9            # xmm9 = xmm9[1],xmm5[1]
140021f49:     	subsd	%xmm9, %xmm5
140021f4e:     	addsd	%xmm6, %xmm5
140021f52:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
140021f56:     	mulsd	%xmm5, %xmm3
140021f5a:     	movapd	%xmm4, %xmm15
140021f5f:     	unpckhpd	%xmm4, %xmm15           # xmm15 = xmm15[1],xmm4[1]
140021f64:     	mulsd	%xmm2, %xmm15
140021f69:     	movapd	%xmm1, %xmm5
140021f6d:     	mulpd	%xmm4, %xmm5
140021f71:     	subsd	%xmm5, %xmm15
140021f76:     	movapd	%xmm2, %xmm6
140021f7a:     	mulsd	%xmm3, %xmm6
140021f7e:     	addsd	%xmm15, %xmm15
140021f83:     	mulsd	%xmm15, %xmm14
140021f88:     	addsd	%xmm3, %xmm14
140021f8d:     	unpcklpd	%xmm4, %xmm3            # xmm3 = xmm3[0],xmm4[0]
140021f91:     	mulpd	%xmm1, %xmm3
140021f95:     	shufpd	$0x1, %xmm6, %xmm5      # xmm5 = xmm5[1],xmm6[0]
140021f9a:     	subpd	%xmm5, %xmm3
140021f9e:     	addpd	%xmm3, %xmm3
140021fa2:     	mulpd	%xmm3, %xmm0
140021fa6:     	addpd	%xmm4, %xmm0
140021faa:     	movapd	%xmm3, %xmm4
140021fae:     	shufpd	$0x1, %xmm15, %xmm4     # xmm4 = xmm4[1],xmm15[0]
140021fb4:     	unpcklpd	%xmm3, %xmm15           # xmm15 = xmm15[0],xmm3[0]
140021fb9:     	mulpd	%xmm1, %xmm15
140021fbe:     	mulpd	%xmm8, %xmm4
140021fc3:     	subpd	%xmm4, %xmm15
140021fc8:     	addpd	%xmm0, %xmm15
140021fcd:     	mulsd	%xmm3, %xmm1
140021fd1:     	unpckhpd	%xmm3, %xmm3            # xmm3 = xmm3[1,1]
140021fd5:     	mulsd	%xmm2, %xmm3
140021fd9:     	subsd	%xmm1, %xmm3
140021fdd:     	addsd	%xmm14, %xmm3
140021fe2:     	movupd	%xmm15, 0x38(%rax)
140021fe8:     	movsd	%xmm3, 0x48(%rax)
140021fed:     	jmp	0x140021e20 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1c00>
140021ff2:     	nopw	%cs:(%rax,%rax)
140022000:     	movq	0x1a0(%rsp), %rcx
140022008:     	movapd	0x50(%rsp), %xmm2
14002200e:     	callq	0x140046b40 <_ZN2kp9PairReach8exceededERKNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEEd>
140022013:     	testb	%al, %al
140022015:     	je	0x140022530 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2310>
14002201b:     	movq	0x80(%rsp), %r8
140022023:     	movq	0x1a0(%rsp), %rdx
14002202b:     	movq	0x1b0(%rsp), %r9
140022033:     	movsd	0x1c8(%rsp), %xmm0
14002203c:     	movsd	%xmm0, 0x28(%rsp)
140022042:     	movsd	0x268(%rsp), %xmm0
14002204b:     	movsd	%xmm0, 0x20(%rsp)
140022051:     	leaq	0x60(%rsp), %rcx
140022056:     	callq	0x140046dc0 <_ZN2kp9PairReach8discoverERKNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS_8JointSetEdd>
14002205b:     	movl	%ebp, 0x20c(%rsp)
140022062:     	movq	0x60(%rsp), %r15
140022067:     	movq	0x68(%rsp), %rsi
14002206c:     	xorl	%edi, %edi
14002206e:     	cmpq	%rsi, %r15
140022071:     	je	0x140022415 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x21f5>
140022077:     	movq	%rsi, 0x200(%rsp)
14002207f:     	jmp	0x1400220b0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e90>
140022081:     	nopw	%cs:(%rax,%rax)
140022090:     	movq	%rcx, 0x440(%rsp)
140022098:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002209d:     	movb	$0x1, %dil
1400220a0:     	addq	$0x268, %r15            # imm = 0x268
1400220a7:     	cmpq	%rsi, %r15
1400220aa:     	je	0x140022410 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x21f0>
1400220b0:     	movq	0x198(%rsp), %rcx
1400220b8:     	movq	0x80(%rsp), %r8
1400220c0:     	cmpl	$0x0, 0x250(%r15)
1400220c8:     	setg	%r9b
1400220cc:     	movq	%r15, %rdx
1400220cf:     	callq	0x140044b40 <_ZN2kp14MissedContacts5adoptERKNS_11ContactPairERKNSt3__16vectorINS_4BodyENS4_9allocatorIS6_EEEEb>
1400220d4:     	cmpl	$0x0, 0x250(%r15)
1400220dc:     	jle	0x1400220a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e80>
1400220de:     	movq	0x1a8(%rsp), %rax
1400220e6:     	movq	(%rax), %r8
1400220e9:     	movslq	(%r15), %rcx
1400220ec:     	movq	(%r8), %rdx
1400220ef:     	imulq	$0x178, %rcx, %rcx      # imm = 0x178
1400220f6:     	movsd	0x68(%rdx,%rcx), %xmm0
1400220fc:     	movl	$0x28, %ecx
140022101:     	ucomisd	%xmm7, %xmm0
140022105:     	jne	0x140022109 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1ee9>
140022107:     	jnp	0x14002212c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1f0c>
140022109:     	movslq	0x4(%r15), %rcx
14002210d:     	imulq	$0x178, %rcx, %rcx      # imm = 0x178
140022114:     	ucomisd	0x68(%rdx,%rcx), %xmm7
14002211a:     	movl	$0x28, %ecx
14002211f:     	movl	$0x10, %edx
140022124:     	cmovneq	%rdx, %rcx
140022128:     	cmovpq	%rdx, %rcx
14002212c:     	movq	0x188(%rsp), %rbp
140022134:     	movq	0x8(%rax), %r9
140022138:     	addq	%rax, %rcx
14002213b:     	movapd	%xmm10, 0x150(%rsp)
140022145:     	movsd	0x40(%rax), %xmm0
14002214a:     	movzbl	0x48(%rax), %eax
14002214e:     	movb	%al, 0x38(%rsp)
140022152:     	movsd	%xmm0, 0x30(%rsp)
140022158:     	movq	%r14, 0x28(%rsp)
14002215d:     	movq	%rcx, 0x20(%rsp)
140022162:     	movb	$0x1, 0x40(%rsp)
140022167:     	movq	%rbx, %rcx
14002216a:     	movq	%r15, %rdx
14002216d:     	callq	0x14003d930 <_ZN2kp11SoftContactC2ERKNS_11ContactPairERKNSt3__16vectorINS_4BodyENS4_9allocatorIS6_EEEERKNS5_INS_10SolverBodyENS_13StepAllocatorISC_EEEERKNS_8SoftnessENS_4SpanINS4_4pairINS_9ContactIdENS_12ContactForceEEEEEdbb>
140022172:     	movq	0x8(%rbp), %r12
140022176:     	cmpq	0x10(%rbp), %r12
14002217a:     	je	0x140022200 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1fe0>
140022180:     	movq	0x430(%rsp), %rax
140022188:     	movq	%rax, (%r12)
14002218c:     	movq	0x438(%rsp), %rax
140022194:     	movq	$0x0, 0x438(%rsp)
1400221a0:     	movq	%rax, 0x8(%r12)
1400221a5:     	movq	0x440(%rsp), %rax
1400221ad:     	movq	%rax, 0x10(%r12)
1400221b2:     	movq	0x448(%rsp), %rax
1400221ba:     	movq	$0x0, 0x448(%rsp)
1400221c6:     	movq	%rax, 0x18(%r12)
1400221cb:     	leaq	0x20(%r12), %rcx
1400221d0:     	movl	$0x2a8, %r8d            # imm = 0x2A8
1400221d6:     	movq	%r13, %rdx
1400221d9:     	callq	0x140072ff0 <memcpy>
1400221de:     	addq	$0x2c8, %r12            # imm = 0x2C8
1400221e5:     	movq	%r12, 0x8(%rbp)
1400221e9:     	movq	0x438(%rsp), %rcx
1400221f1:     	testq	%rcx, %rcx
1400221f4:     	jne	0x140022090 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e70>
1400221fa:     	jmp	0x14002209d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e7d>
1400221ff:     	nop
140022200:     	subq	(%rbp), %r12
140022204:     	movq	%r12, %rax
140022207:     	sarq	$0x3, %rax
14002220b:     	movabsq	$-0xb81702e05c0b817, %rcx # imm = 0xF47E8FD1FA3F47E9
140022215:     	imulq	%rcx, %rax
140022219:     	leaq	0x1(%rax), %rsi
14002221d:     	movabsq	$0x5c0b81702e05c0, %rdx # imm = 0x5C0B81702E05C0
140022227:     	cmpq	%rdx, %rsi
14002222a:     	ja	0x140023fcb <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dab>
140022230:     	leaq	(%rax,%rax), %rcx
140022234:     	cmpq	%rsi, %rcx
140022237:     	cmovaq	%rcx, %rsi
14002223b:     	movabsq	$0x2e05c0b81702e0, %rcx # imm = 0x2E05C0B81702E0
140022245:     	cmpq	%rcx, %rax
140022248:     	cmovaeq	%rdx, %rsi
14002224c:     	testq	%rsi, %rsi
14002224f:     	movq	%rsi, 0x250(%rsp)
140022257:     	je	0x14002226a <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x204a>
140022259:     	imulq	$0x2c8, %rsi, %rcx      # imm = 0x2C8
140022260:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140022265:     	movq	%rax, %r14
140022268:     	jmp	0x14002226d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x204d>
14002226a:     	xorl	%r14d, %r14d
14002226d:     	leaq	(%r14,%r12), %rbx
140022271:     	movq	0x430(%rsp), %rax
140022279:     	movq	%rax, (%r14,%r12)
14002227d:     	movq	0x438(%rsp), %rax
140022285:     	movq	$0x0, 0x438(%rsp)
140022291:     	movq	%rax, 0x8(%r14,%r12)
140022296:     	movq	0x440(%rsp), %rax
14002229e:     	movq	$0x0, 0x440(%rsp)
1400222aa:     	movq	%rax, 0x10(%r14,%r12)
1400222af:     	movq	0x448(%rsp), %rax
1400222b7:     	movq	$0x0, 0x448(%rsp)
1400222c3:     	movq	%rax, 0x18(%r14,%r12)
1400222c8:     	leaq	(%r14,%r12), %rcx
1400222cc:     	addq	$0x20, %rcx
1400222d0:     	movl	$0x2a8, %r8d            # imm = 0x2A8
1400222d6:     	movq	%r13, %rdx
1400222d9:     	callq	0x140072ff0 <memcpy>
1400222de:     	movq	(%rbp), %rdi
1400222e2:     	movq	0x8(%rbp), %rsi
1400222e6:     	movq	%rdi, %rax
1400222e9:     	subq	%rsi, %rax
1400222ec:     	leaq	(%rax,%rbx), %r13
1400222f0:     	je	0x1400223a4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2184>
1400222f6:     	xorl	%ebx, %ebx
1400222f8:     	nopl	(%rax,%rax)
140022300:     	movq	(%rdi,%rbx), %rax
140022304:     	movq	%rax, (%r13,%rbx)
140022309:     	movq	0x8(%rdi,%rbx), %rax
14002230e:     	movq	$0x0, 0x8(%rdi,%rbx)
140022317:     	movq	%rax, 0x8(%r13,%rbx)
14002231c:     	movq	0x10(%rdi,%rbx), %rax
140022321:     	movq	$0x0, 0x10(%rdi,%rbx)
14002232a:     	movq	%rax, 0x10(%r13,%rbx)
14002232f:     	movq	0x18(%rdi,%rbx), %rax
140022334:     	movq	$0x0, 0x18(%rdi,%rbx)
14002233d:     	movq	%rax, 0x18(%r13,%rbx)
140022342:     	leaq	(%rdi,%rbx), %rdx
140022346:     	addq	$0x20, %rdx
14002234a:     	leaq	(%rbx,%r13), %rcx
14002234e:     	addq	$0x20, %rcx
140022352:     	movl	$0x2a8, %r8d            # imm = 0x2A8
140022358:     	callq	0x140072ff0 <memcpy>
14002235d:     	leaq	(%rdi,%rbx), %rax
140022361:     	addq	$0x2c8, %rax            # imm = 0x2C8
140022367:     	addq	$0x2c8, %rbx            # imm = 0x2C8
14002236e:     	cmpq	%rsi, %rax
140022371:     	jne	0x140022300 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x20e0>
140022373:     	jmp	0x14002238c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x216c>
140022375:     	nopw	%cs:(%rax,%rax)
140022380:     	addq	$0x2c8, %rdi            # imm = 0x2C8
140022387:     	cmpq	%rsi, %rdi
14002238a:     	je	0x1400223a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2180>
14002238c:     	movq	0x8(%rdi), %rcx
140022390:     	testq	%rcx, %rcx
140022393:     	je	0x140022380 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2160>
140022395:     	movq	%rcx, 0x10(%rdi)
140022399:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002239e:     	jmp	0x140022380 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2160>
1400223a0:     	movq	(%rbp), %rdi
1400223a4:     	imulq	$0x2c8, 0x250(%rsp), %rax # imm = 0x2C8
1400223b0:     	addq	%r14, %rax
1400223b3:     	addq	%r14, %r12
1400223b6:     	addq	$0x2c8, %r12            # imm = 0x2C8
1400223bd:     	movq	%r13, (%rbp)
1400223c1:     	movq	%r12, 0x8(%rbp)
1400223c5:     	movq	%rax, 0x10(%rbp)
1400223c9:     	testq	%rdi, %rdi
1400223cc:     	movq	0x200(%rsp), %rsi
1400223d4:     	je	0x1400223de <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x21be>
1400223d6:     	movq	%rdi, %rcx
1400223d9:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400223de:     	leaq	0x430(%rsp), %rbx
1400223e6:     	leaq	0x450(%rsp), %r13
1400223ee:     	leaq	0x150(%rsp), %r14
1400223f6:     	movq	%r12, 0x8(%rbp)
1400223fa:     	movq	0x438(%rsp), %rcx
140022402:     	testq	%rcx, %rcx
140022405:     	jne	0x140022090 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e70>
14002240b:     	jmp	0x14002209d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1e7d>
140022410:     	movq	0x60(%rsp), %r15
140022415:     	testq	%r15, %r15
140022418:     	je	0x14002246f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x224f>
14002241a:     	movq	0x68(%rsp), %rsi
14002241f:     	movq	%r15, %rcx
140022422:     	cmpq	%rsi, %r15
140022425:     	jne	0x14002243c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x221c>
140022427:     	jmp	0x140022465 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2245>
140022429:     	nopl	(%rax)
140022430:     	addq	$-0x268, %rsi           # imm = 0xFD98
140022437:     	cmpq	%r15, %rsi
14002243a:     	je	0x140022460 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2240>
14002243c:     	leaq	-0x230(%rsi), %rax
140022443:     	movq	-0x30(%rsi), %rcx
140022447:     	cmpq	%rcx, %rax
14002244a:     	je	0x140022430 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2210>
14002244c:     	callq	0x140072e60 <_ZdlPv>
140022451:     	jmp	0x140022430 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2210>
140022453:     	nopw	%cs:(%rax,%rax)
140022460:     	movq	0x60(%rsp), %rcx
140022465:     	movq	%r15, 0x68(%rsp)
14002246a:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002246f:     	testb	$0x1, %dil
140022473:     	movl	0x20c(%rsp), %ebp
14002247a:     	je	0x140022530 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2310>
140022480:     	movq	0x188(%rsp), %rdx
140022488:     	movq	0x190(%rsp), %rcx
140022490:     	movq	0x80(%rsp), %r8
140022498:     	movq	0x88(%rsp), %r9
1400224a0:     	movsd	0x1b8(%rsp), %xmm0
1400224a9:     	movsd	%xmm0, 0x30(%rsp)
1400224af:     	movapd	0x50(%rsp), %xmm0
1400224b5:     	movsd	%xmm0, 0x28(%rsp)
1400224bb:     	movq	$0x0, 0x38(%rsp)
1400224c4:     	movb	$0x1, 0x20(%rsp)
1400224c9:     	callq	0x14004d6c0 <_ZN2kp13IslandNormals5solveERNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_4BodyENS1_9allocatorIS8_EEEERNS2_INS_10SolverBodyENS4_ISE_EEEEbddPKNS2_IcNS4_IcEEEE>
1400224ce:     	cmpb	$0x1, 0x1d8(%rsp)
1400224d6:     	jne	0x140021dd0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1bb0>
1400224dc:     	movq	0x188(%rsp), %rax
1400224e4:     	movq	(%rax), %rsi
1400224e7:     	movq	0x8(%rax), %rdi
1400224eb:     	cmpq	%rdi, %rsi
1400224ee:     	je	0x140021dd0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1bb0>
1400224f4:     	nopw	%cs:(%rax,%rax)
140022500:     	movq	0x88(%rsp), %rdx
140022508:     	movsd	0x1c0(%rsp), %xmm2
140022511:     	movq	%rsi, %rcx
140022514:     	callq	0x1400429c0 <_ZN2kp11SoftContact6bounceERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd>
140022519:     	addq	$0x2c8, %rsi            # imm = 0x2C8
140022520:     	cmpq	%rdi, %rsi
140022523:     	jne	0x140022500 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x22e0>
140022525:     	jmp	0x140021dd0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1bb0>
14002252a:     	nopw	(%rax,%rax)
140022530:     	movq	0x1d0(%rsp), %rax
140022538:     	movq	0x20(%rax), %rcx
14002253c:     	testq	%rcx, %rcx
14002253f:     	je	0x140022555 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2335>
140022541:     	movl	$0x9, 0x430(%rsp)
14002254c:     	movq	(%rcx), %rax
14002254f:     	movq	%rbx, %rdx
140022552:     	callq	*0x30(%rax)
140022555:     	movq	0x198(%rsp), %r12
14002255d:     	movq	(%r12), %rax
140022561:     	movq	0x10(%r12), %r14
140022566:     	movq	0x8(%rax), %rcx
14002256a:     	subq	(%rax), %rcx
14002256d:     	sarq	$0x3, %rcx
140022571:     	movabsq	$0x4fcace213f2b3885, %rax # imm = 0x4FCACE213F2B3885
14002257b:     	imulq	%rax, %rcx
14002257f:     	subq	0x8(%r12), %r14
140022584:     	sarq	$0x3, %r14
140022588:     	imulq	%rax, %r14
14002258c:     	addq	%rcx, %r14
14002258f:     	movq	0xa8(%r12), %rax
140022597:     	movq	0x98(%r12), %rdi
14002259f:     	movq	%rax, %rcx
1400225a2:     	subq	%rdi, %rcx
1400225a5:     	sarq	$0x3, %rcx
1400225a9:     	cmpq	%rcx, %r14
1400225ac:     	jbe	0x140022660 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2440>
1400225b2:     	testq	%rdi, %rdi
1400225b5:     	je	0x1400225de <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x23be>
1400225b7:     	leaq	0x98(%r12), %rsi
1400225bf:     	movq	%rdi, 0xa0(%r12)
1400225c7:     	movq	%rdi, %rcx
1400225ca:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400225cf:     	movupd	%xmm10, (%rsi)
1400225d4:     	movq	$0x0, 0x10(%rsi)
1400225dc:     	xorl	%eax, %eax
1400225de:     	movabsq	$0x1fffffffffffffff, %rcx # imm = 0x1FFFFFFFFFFFFFFF
1400225e8:     	cmpq	%rcx, %r14
1400225eb:     	ja	0x140023fd0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3db0>
1400225f1:     	movq	%rax, %rdi
1400225f4:     	sarq	$0x2, %rdi
1400225f8:     	cmpq	%r14, %rdi
1400225fb:     	cmovbeq	%r14, %rdi
1400225ff:     	movabsq	$0x7ffffffffffffff8, %rdx # imm = 0x7FFFFFFFFFFFFFF8
140022609:     	cmpq	%rdx, %rax
14002260c:     	cmovaeq	%rcx, %rdi
140022610:     	cmpq	%rcx, %rdi
140022613:     	ja	0x140023fd0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3db0>
140022619:     	leaq	(,%rdi,8), %rcx
140022621:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140022626:     	movq	%rax, %rsi
140022629:     	movq	%rax, 0x98(%r12)
140022631:     	leaq	(%rax,%rdi,8), %rax
140022635:     	movq	%rax, 0xa8(%r12)
14002263d:     	leaq	(,%r14,8), %r8
140022645:     	movq	%rsi, %rcx
140022648:     	xorl	%edx, %edx
14002264a:     	callq	0x140073000 <memset>
14002264f:     	leaq	(%rsi,%r14,8), %rax
140022653:     	movq	%rax, 0xa0(%r12)
14002265b:     	jmp	0x1400226dc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x24bc>
140022660:     	movq	0xa0(%r12), %r15
140022668:     	movq	%r15, %rsi
14002266b:     	subq	%rdi, %rsi
14002266e:     	movq	%rsi, %rbx
140022671:     	sarq	$0x3, %rbx
140022675:     	cmpq	%r14, %rbx
140022678:     	movq	%r14, %r8
14002267b:     	cmovbq	%rbx, %r8
14002267f:     	testq	%r8, %r8
140022682:     	je	0x140022692 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2472>
140022684:     	shlq	$0x3, %r8
140022688:     	movq	%rdi, %rcx
14002268b:     	xorl	%edx, %edx
14002268d:     	callq	0x140073000 <memset>
140022692:     	movq	%r14, %r13
140022695:     	subq	%rbx, %r13
140022698:     	jbe	0x1400226c0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x24a0>
14002269a:     	shlq	$0x3, %r14
14002269e:     	subq	%rsi, %r14
1400226a1:     	movq	%r15, %rcx
1400226a4:     	xorl	%edx, %edx
1400226a6:     	movq	%r14, %r8
1400226a9:     	callq	0x140073000 <memset>
1400226ae:     	leaq	(%r15,%r13,8), %rax
1400226b2:     	jmp	0x1400226c4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x24a4>
1400226b4:     	nopw	%cs:(%rax,%rax)
1400226c0:     	leaq	(%rdi,%r14,8), %rax
1400226c4:     	movq	%rax, 0xa0(%r12)
1400226cc:     	leaq	0x430(%rsp), %rbx
1400226d4:     	leaq	0x450(%rsp), %r13
1400226dc:     	movapd	0x50(%rsp), %xmm0
1400226e2:     	movsd	%xmm0, 0x178(%rsp)
1400226eb:     	movq	0x80(%rsp), %rax
1400226f3:     	movq	0x8(%rax), %rdi
1400226f7:     	movq	(%rax), %rax
1400226fa:     	subq	%rax, %rdi
1400226fd:     	je	0x140022b90 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2970>
140022703:     	sarq	$0x3, %rdi
140022707:     	movabsq	$0x51b3bea3677d46cf, %rax # imm = 0x51B3BEA3677D46CF
140022711:     	imulq	%rax, %rdi
140022715:     	movabsq	$0x333333333333333, %rax # imm = 0x333333333333333
14002271f:     	cmpq	%rax, %rdi
140022722:     	ja	0x140023fda <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dba>
140022728:     	movq	%rdi, %rax
14002272b:     	shlq	$0x4, %rax
14002272f:     	leaq	(%rax,%rax,4), %r15
140022733:     	movq	%r15, %rcx
140022736:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
14002273b:     	movq	%rax, %r14
14002273e:     	movq	%rax, %rsi
140022741:     	leaq	-0x50(%r15), %rcx
140022745:     	movq	%rcx, %rax
140022748:     	movabsq	$-0x3333333333333333, %rdx # imm = 0xCCCCCCCCCCCCCCCD
140022752:     	mulq	%rdx
140022755:     	shrl	$0x6, %edx
140022758:     	incl	%edx
14002275a:     	movq	%r14, %rax
14002275d:     	andl	$0x7, %edx
140022760:     	movabsq	$0x3ff0000000000000, %r8 # imm = 0x3FF0000000000000
14002276a:     	je	0x1400227ad <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x258d>
14002276c:     	shll	$0x4, %edx
14002276f:     	leaq	(%rdx,%rdx,4), %rdx
140022773:     	movq	%rsi, %rax
140022776:     	nopw	%cs:(%rax,%rax)
140022780:     	movupd	%xmm10, 0x20(%rax)
140022786:     	movupd	%xmm10, 0x10(%rax)
14002278c:     	movupd	%xmm10, (%rax)
140022791:     	movq	%r8, 0x30(%rax)
140022795:     	movupd	%xmm10, 0x38(%rax)
14002279b:     	movq	$0x0, 0x48(%rax)
1400227a3:     	addq	$0x50, %rax
1400227a7:     	addq	$-0x50, %rdx
1400227ab:     	jne	0x140022780 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2560>
1400227ad:     	addq	%r14, %r15
1400227b0:     	cmpq	$0x230, %rcx            # imm = 0x230
1400227b7:     	jb	0x140022963 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2743>
1400227bd:     	nopl	(%rax)
1400227c0:     	movupd	%xmm10, 0x20(%rax)
1400227c6:     	movupd	%xmm10, 0x10(%rax)
1400227cc:     	movupd	%xmm10, (%rax)
1400227d1:     	movq	%r8, 0x30(%rax)
1400227d5:     	movupd	%xmm10, 0x38(%rax)
1400227db:     	movq	$0x0, 0x48(%rax)
1400227e3:     	movupd	%xmm10, 0x50(%rax)
1400227e9:     	movupd	%xmm10, 0x60(%rax)
1400227ef:     	movupd	%xmm10, 0x70(%rax)
1400227f5:     	movq	%r8, 0x80(%rax)
1400227fc:     	movupd	%xmm10, 0x88(%rax)
140022805:     	movq	$0x0, 0x98(%rax)
140022810:     	movupd	%xmm10, 0xa0(%rax)
140022819:     	movupd	%xmm10, 0xb0(%rax)
140022822:     	movupd	%xmm10, 0xc0(%rax)
14002282b:     	movq	%r8, 0xd0(%rax)
140022832:     	movupd	%xmm10, 0xd8(%rax)
14002283b:     	movq	$0x0, 0xe8(%rax)
140022846:     	movupd	%xmm10, 0x110(%rax)
14002284f:     	movupd	%xmm10, 0x100(%rax)
140022858:     	movupd	%xmm10, 0xf0(%rax)
140022861:     	movq	%r8, 0x120(%rax)
140022868:     	movupd	%xmm10, 0x128(%rax)
140022871:     	movq	$0x0, 0x138(%rax)
14002287c:     	movupd	%xmm10, 0x140(%rax)
140022885:     	movupd	%xmm10, 0x150(%rax)
14002288e:     	movupd	%xmm10, 0x160(%rax)
140022897:     	movq	%r8, 0x170(%rax)
14002289e:     	movupd	%xmm10, 0x178(%rax)
1400228a7:     	movq	$0x0, 0x188(%rax)
1400228b2:     	movupd	%xmm10, 0x190(%rax)
1400228bb:     	movupd	%xmm10, 0x1a0(%rax)
1400228c4:     	movupd	%xmm10, 0x1b0(%rax)
1400228cd:     	movq	%r8, 0x1c0(%rax)
1400228d4:     	movupd	%xmm10, 0x1c8(%rax)
1400228dd:     	movq	$0x0, 0x1d8(%rax)
1400228e8:     	movupd	%xmm10, 0x200(%rax)
1400228f1:     	movupd	%xmm10, 0x1f0(%rax)
1400228fa:     	movupd	%xmm10, 0x1e0(%rax)
140022903:     	movq	%r8, 0x210(%rax)
14002290a:     	movupd	%xmm10, 0x218(%rax)
140022913:     	movq	$0x0, 0x228(%rax)
14002291e:     	movupd	%xmm10, 0x250(%rax)
140022927:     	movupd	%xmm10, 0x240(%rax)
140022930:     	movupd	%xmm10, 0x230(%rax)
140022939:     	movq	%r8, 0x260(%rax)
140022940:     	movupd	%xmm10, 0x268(%rax)
140022949:     	movq	$0x0, 0x278(%rax)
140022954:     	addq	$0x280, %rax            # imm = 0x280
14002295a:     	cmpq	%r15, %rax
14002295d:     	jne	0x1400227c0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x25a0>
140022963:     	leaq	(%rdi,%rdi,4), %rax
140022967:     	shlq	$0x4, %rax
14002296b:     	addq	%rax, %r14
14002296e:     	movq	0x80(%rsp), %rax
140022976:     	movq	(%rax), %r8
140022979:     	cmpq	%r8, 0x8(%rax)
14002297d:     	je	0x140022a57 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2837>
140022983:     	xorl	%eax, %eax
140022985:     	movq	%rsi, %rcx
140022988:     	xorl	%edx, %edx
14002298a:     	movabsq	$0x51b3bea3677d46cf, %r10 # imm = 0x51B3BEA3677D46CF
140022994:     	nopw	%cs:(%rax,%rax)
1400229a0:     	movq	0x10(%r8,%rax), %r9
1400229a5:     	movq	%r9, 0x440(%rsp)
1400229ad:     	movups	(%r8,%rax), %xmm0
1400229b2:     	movaps	%xmm0, 0x430(%rsp)
1400229ba:     	movq	0x60(%r8,%rax), %r9
1400229bf:     	movq	%r9, 0x8(%r13)
1400229c3:     	movups	0x50(%r8,%rax), %xmm0
1400229c9:     	movups	%xmm0, -0x8(%r13)
1400229ce:     	movups	0x18(%r8,%rax), %xmm0
1400229d4:     	movups	0x28(%r8,%rax), %xmm1
1400229da:     	movups	%xmm1, 0x20(%r13)
1400229df:     	movups	%xmm0, 0x10(%r13)
1400229e4:     	movaps	0x470(%rsp), %xmm0
1400229ec:     	movups	%xmm0, 0x40(%rcx)
1400229f0:     	movapd	0x430(%rsp), %xmm0
1400229f9:     	movapd	0x440(%rsp), %xmm1
140022a02:     	movapd	0x450(%rsp), %xmm2
140022a0b:     	movapd	0x460(%rsp), %xmm3
140022a14:     	movupd	%xmm3, 0x30(%rcx)
140022a19:     	movupd	%xmm2, 0x20(%rcx)
140022a1e:     	movupd	%xmm1, 0x10(%rcx)
140022a23:     	movupd	%xmm0, (%rcx)
140022a27:     	incq	%rdx
140022a2a:     	movq	0x80(%rsp), %r9
140022a32:     	movq	(%r9), %r8
140022a35:     	movq	0x8(%r9), %r9
140022a39:     	subq	%r8, %r9
140022a3c:     	sarq	$0x3, %r9
140022a40:     	imulq	%r10, %r9
140022a44:     	addq	$0x50, %rcx
140022a48:     	addq	$0x178, %rax            # imm = 0x178
140022a4e:     	cmpq	%r9, %rdx
140022a51:     	jb	0x1400229a0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2780>
140022a57:     	movq	0xa8(%rsp), %rcx
140022a5f:     	testq	%rcx, %rcx
140022a62:     	je	0x140022a71 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2851>
140022a64:     	movq	%rcx, 0xb0(%rsp)
140022a6c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140022a71:     	movq	%rsi, 0xa8(%rsp)
140022a79:     	movq	%r15, 0xb0(%rsp)
140022a81:     	movq	%r14, 0xb8(%rsp)
140022a89:     	movq	0x88(%rsp), %rax
140022a91:     	leaq	0xc0(%rsp), %rcx
140022a99:     	cmpq	%rax, %rcx
140022a9c:     	je	0x140022c09 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x29e9>
140022aa2:     	movq	(%rax), %r15
140022aa5:     	movq	0x8(%rax), %rdi
140022aa9:     	movq	%rdi, %r14
140022aac:     	subq	%r15, %r14
140022aaf:     	movq	0xc0(%rsp), %rsi
140022ab7:     	movq	0xd0(%rsp), %rax
140022abf:     	movq	%rax, %rcx
140022ac2:     	subq	%rsi, %rcx
140022ac5:     	cmpq	%rcx, %r14
140022ac8:     	jbe	0x140022bb0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2990>
140022ace:     	testq	%rsi, %rsi
140022ad1:     	je	0x140022afa <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x28da>
140022ad3:     	movq	%rsi, 0xc8(%rsp)
140022adb:     	movq	%rsi, %rcx
140022ade:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140022ae3:     	leaq	0xc0(%rsp), %rax
140022aeb:     	movupd	%xmm10, (%rax)
140022af0:     	movq	$0x0, 0x10(%rax)
140022af8:     	xorl	%eax, %eax
140022afa:     	movq	%r14, %rcx
140022afd:     	sarq	$0x3, %rcx
140022b01:     	movabsq	$-0x2c8590b21642c859, %rdx # imm = 0xD37A6F4DE9BD37A7
140022b0b:     	imulq	%rdx, %rcx
140022b0f:     	movabsq	$0x1642c8590b21642, %r8 # imm = 0x1642C8590B21642
140022b19:     	cmpq	%r8, %rcx
140022b1c:     	ja	0x140023fd5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3db5>
140022b22:     	sarq	$0x3, %rax
140022b26:     	imulq	%rdx, %rax
140022b2a:     	leaq	(%rax,%rax), %rdx
140022b2e:     	cmpq	%rcx, %rdx
140022b31:     	cmovaq	%rdx, %rcx
140022b35:     	movabsq	$0xb21642c8590b21, %rdx # imm = 0xB21642C8590B21
140022b3f:     	cmpq	%rdx, %rax
140022b42:     	cmovaeq	%r8, %rcx
140022b46:     	cmpq	%r8, %rcx
140022b49:     	ja	0x140023fd5 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3db5>
140022b4f:     	imulq	$0xb8, %rcx, %rsi
140022b56:     	movq	%rsi, %rcx
140022b59:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140022b5e:     	movq	%rax, %rdi
140022b61:     	movq	%rax, 0xc0(%rsp)
140022b69:     	movq	%rax, 0xc8(%rsp)
140022b71:     	addq	%rax, %rsi
140022b74:     	movq	%rsi, 0xd0(%rsp)
140022b7c:     	movq	%rax, %rcx
140022b7f:     	movq	%r15, %rdx
140022b82:     	movq	%r14, %r8
140022b85:     	callq	0x140073050 <memmove>
140022b8a:     	addq	%r14, %rdi
140022b8d:     	jmp	0x140022c01 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x29e1>
140022b8f:     	nop
140022b90:     	xorl	%esi, %esi
140022b92:     	xorl	%r15d, %r15d
140022b95:     	xorl	%r14d, %r14d
140022b98:     	movq	0xa8(%rsp), %rcx
140022ba0:     	testq	%rcx, %rcx
140022ba3:     	jne	0x140022a64 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2844>
140022ba9:     	jmp	0x140022a71 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2851>
140022bae:     	nop
140022bb0:     	movq	0xc8(%rsp), %r8
140022bb8:     	subq	%rsi, %r8
140022bbb:     	cmpq	%r8, %r14
140022bbe:     	jbe	0x140022bed <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x29cd>
140022bc0:     	leaq	(%r15,%r8), %r14
140022bc4:     	movq	%rsi, %rcx
140022bc7:     	movq	%r15, %rdx
140022bca:     	callq	0x140073050 <memmove>
140022bcf:     	movq	0xc8(%rsp), %rsi
140022bd7:     	subq	%r14, %rdi
140022bda:     	movq	%rsi, %rcx
140022bdd:     	movq	%r14, %rdx
140022be0:     	movq	%rdi, %r8
140022be3:     	callq	0x140073050 <memmove>
140022be8:     	addq	%rsi, %rdi
140022beb:     	jmp	0x140022c01 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x29e1>
140022bed:     	movq	%rsi, %rcx
140022bf0:     	movq	%r15, %rdx
140022bf3:     	movq	%r14, %r8
140022bf6:     	callq	0x140073050 <memmove>
140022bfb:     	addq	%r14, %rsi
140022bfe:     	movq	%rsi, %rdi
140022c01:     	movq	%rdi, 0xc8(%rsp)
140022c09:     	movq	0x80(%rsp), %rcx
140022c11:     	movq	(%rcx), %rax
140022c14:     	movq	0x8(%rcx), %rcx
140022c18:     	movq	%rcx, %rdi
140022c1b:     	subq	%rax, %rdi
140022c1e:     	sarq	$0x3, %rdi
140022c22:     	movabsq	$0x51b3bea3677d46cf, %rdx # imm = 0x51B3BEA3677D46CF
140022c2c:     	imulq	%rdx, %rdi
140022c30:     	leaq	0x80(%rsp), %rdx
140022c38:     	movq	%rdx, 0x60(%rsp)
140022c3d:     	leaq	0x178(%rsp), %rdx
140022c45:     	movq	%rdx, 0x68(%rsp)
140022c4a:     	movq	%rdi, 0x150(%rsp)
140022c52:     	leaq	0x1f(%rdi), %rsi
140022c56:     	cmpq	$0xff, %rsi
140022c5d:     	ja	0x140022cb0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2a90>
140022c5f:     	cmpq	%rax, %rcx
140022c62:     	movq	0x170(%rsp), %r15
140022c6a:     	leaq	0x130(%rsp), %r12
140022c72:     	leaq	0x150(%rsp), %r14
140022c7a:     	je	0x140022d2f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2b0f>
140022c80:     	xorl	%esi, %esi
140022c82:     	nopw	%cs:(%rax,%rax)
140022c90:     	leaq	0x60(%rsp), %rcx
140022c95:     	movq	%rsi, %rdx
140022c98:     	callq	0x140024a00 <_ZZN2kp12_GLOBAL__N_16Moving7advanceEdENKUlyE_clEy>
140022c9d:     	incq	%rsi
140022ca0:     	cmpq	%rsi, %rdi
140022ca3:     	jne	0x140022c90 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2a70>
140022ca5:     	jmp	0x140022d2f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2b0f>
140022caa:     	nopw	(%rax,%rax)
140022cb0:     	callq	0x14000b130 <_ZN2kp10WorkerPool6sharedEv>
140022cb5:     	shrq	$0x5, %rsi
140022cb9:     	leaq	0x53100(%rip), %rcx     # 0x140075dc0 <_ZTVNSt3__110__function6__funcIZN2kp12_GLOBAL__N_16eachOfIZNS3_6Moving7advanceEdEUlyE_EEvyRKT_EUlyE_FvyEEE+0x10>
140022cc0:     	movq	%rcx, 0x430(%rsp)
140022cc8:     	leaq	0x150(%rsp), %r14
140022cd0:     	movq	%r14, 0x438(%rsp)
140022cd8:     	leaq	0x60(%rsp), %rcx
140022cdd:     	movq	%rcx, 0x440(%rsp)
140022ce5:     	movq	%rbx, 0x450(%rsp)
140022ced:     	movq	%rax, %rcx
140022cf0:     	movq	%rsi, %rdx
140022cf3:     	movq	%rbx, %r8
140022cf6:     	callq	0x14000b630 <_ZN2kp10WorkerPool3runEyRKNSt3__18functionIFvyEEE>
140022cfb:     	movq	0x450(%rsp), %rcx
140022d03:     	cmpq	%rbx, %rcx
140022d06:     	je	0x140022d14 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2af4>
140022d08:     	movl	$0x28, %eax
140022d0d:     	testq	%rcx, %rcx
140022d10:     	jne	0x140022d19 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2af9>
140022d12:     	jmp	0x140022d1f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2aff>
140022d14:     	movl	$0x20, %eax
140022d19:     	movq	(%rcx), %rdx
140022d1c:     	callq	*(%rdx,%rax)
140022d1f:     	movq	0x170(%rsp), %r15
140022d27:     	leaq	0x130(%rsp), %r12
140022d2f:     	movq	0x188(%rsp), %rcx
140022d37:     	movq	0x8(%rcx), %rdi
140022d3b:     	movq	(%rcx), %rax
140022d3e:     	movapd	%xmm10, 0x60(%rsp)
140022d45:     	movq	$0x0, 0x70(%rsp)
140022d4e:     	subq	%rax, %rdi
140022d51:     	je	0x140022db6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2b96>
140022d53:     	sarq	$0x3, %rdi
140022d57:     	movabsq	$-0xb81702e05c0b817, %rax # imm = 0xF47E8FD1FA3F47E9
140022d61:     	imulq	%rax, %rdi
140022d65:     	movabsq	$0x1fffffffffffffff, %rax # imm = 0x1FFFFFFFFFFFFFFF
140022d6f:     	cmpq	%rax, %rdi
140022d72:     	ja	0x140023fdf <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dbf>
140022d78:     	leaq	(,%rdi,8), %rsi
140022d80:     	movq	%rsi, %rcx
140022d83:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140022d88:     	movq	%rax, 0x60(%rsp)
140022d8d:     	leaq	(%rax,%rdi,8), %rcx
140022d91:     	movq	%rcx, 0x70(%rsp)
140022d96:     	movq	%rax, %rdi
140022d99:     	addq	%rsi, %rdi
140022d9c:     	movq	%rax, %rcx
140022d9f:     	xorl	%edx, %edx
140022da1:     	movq	%rsi, %r8
140022da4:     	callq	0x140073000 <memset>
140022da9:     	movq	%rdi, 0x68(%rsp)
140022dae:     	movq	0x188(%rsp), %rcx
140022db6:     	movq	(%rcx), %rax
140022db9:     	movq	0x8(%rcx), %rcx
140022dbd:     	movq	%rcx, %rdi
140022dc0:     	subq	%rax, %rdi
140022dc3:     	sarq	$0x3, %rdi
140022dc7:     	movabsq	$-0xb81702e05c0b817, %rdx # imm = 0xF47E8FD1FA3F47E9
140022dd1:     	imulq	%rdx, %rdi
140022dd5:     	leaq	0x188(%rsp), %rdx
140022ddd:     	movq	%rdx, 0x150(%rsp)
140022de5:     	leaq	0x80(%rsp), %rdx
140022ded:     	movq	%rdx, 0x158(%rsp)
140022df5:     	leaq	0x60(%rsp), %rdx
140022dfa:     	movq	%rdx, 0x160(%rsp)
140022e02:     	movq	%rdi, 0x178(%rsp)
140022e0a:     	leaq	0x1f(%rdi), %rsi
140022e0e:     	cmpq	$0xff, %rsi
140022e15:     	ja	0x140022f60 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2d40>
140022e1b:     	cmpq	%rax, %rcx
140022e1e:     	je	0x140022fca <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2daa>
140022e24:     	xorl	%esi, %esi
140022e26:     	nopw	%cs:(%rax,%rax)
140022e30:     	movq	0x150(%rsp), %rbx
140022e38:     	movq	0x158(%rsp), %rax
140022e40:     	movq	(%rbx), %rcx
140022e43:     	movq	0x8(%rax), %rdx
140022e47:     	leaq	0x4(%rsi), %r8
140022e4b:     	leaq	0x8(%rsi), %r9
140022e4f:     	callq	0x1400408d0 <_ZN2kp11SoftContact8prefetchERKNSt3__16vectorIS0_NS_13StepAllocatorIS0_EEEERKNS2_INS_10SolverBodyENS3_IS8_EEEEyy>
140022e54:     	movq	(%rbx), %rax
140022e57:     	movq	(%rax), %rcx
140022e5a:     	imulq	$0x2c8, %rsi, %rax      # imm = 0x2C8
140022e61:     	movq	0x8(%rcx,%rax), %rdx
140022e66:     	movq	0x10(%rcx,%rax), %r8
140022e6b:     	subq	%rdx, %r8
140022e6e:     	je	0x140022e90 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2c70>
140022e70:     	cmpq	$0xb0, %r8
140022e77:     	jne	0x140022ea0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2c80>
140022e79:     	xorpd	%xmm0, %xmm0
140022e7d:     	xorl	%r9d, %r9d
140022e80:     	jmp	0x140022f06 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2ce6>
140022e85:     	nopw	%cs:(%rax,%rax)
140022e90:     	xorpd	%xmm0, %xmm0
140022e94:     	jmp	0x140022f27 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2d07>
140022e99:     	nopl	(%rax)
140022ea0:     	sarq	$0x4, %r8
140022ea4:     	movabsq	$0x2e8ba2e8ba2e8ba3, %r9 # imm = 0x2E8BA2E8BA2E8BA3
140022eae:     	imulq	%r9, %r8
140022eb2:     	movq	%r8, %r10
140022eb5:     	andq	$-0x2, %r10
140022eb9:     	leaq	0x130(%rdx), %r11
140022ec0:     	xorpd	%xmm0, %xmm0
140022ec4:     	xorl	%r9d, %r9d
140022ec7:     	nopw	(%rax,%rax)
140022ed0:     	movsd	-0xb0(%r11), %xmm1
140022ed9:     	xorpd	%xmm12, %xmm1
140022ede:     	maxsd	%xmm0, %xmm1
140022ee2:     	movsd	(%r11), %xmm0
140022ee7:     	xorpd	%xmm12, %xmm0
140022eec:     	maxsd	%xmm1, %xmm0
140022ef0:     	addq	$0x2, %r9
140022ef4:     	addq	$0x160, %r11            # imm = 0x160
140022efb:     	cmpq	%r9, %r10
140022efe:     	jne	0x140022ed0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2cb0>
140022f00:     	testb	$0x1, %r8b
140022f04:     	je	0x140022f27 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2d07>
140022f06:     	movapd	%xmm0, %xmm1
140022f0a:     	imulq	$0xb0, %r9, %r8
140022f11:     	movsd	0x80(%rdx,%r8), %xmm0
140022f1b:     	xorpd	0x52c9d(%rip), %xmm0    # 0x140075bc0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xc8>
140022f23:     	maxsd	%xmm1, %xmm0
140022f27:     	addq	%rax, %rcx
140022f2a:     	movq	0x160(%rsp), %rax
140022f32:     	movq	(%rax), %rax
140022f35:     	movsd	%xmm0, (%rax,%rsi,8)
140022f3a:     	movq	0x158(%rsp), %rax
140022f42:     	movq	0x8(%rax), %rdx
140022f46:     	callq	0x14003fe00 <_ZN2kp11SoftContact6followERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>
140022f4b:     	incq	%rsi
140022f4e:     	cmpq	%rdi, %rsi
140022f51:     	jne	0x140022e30 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2c10>
140022f57:     	jmp	0x140022fca <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2daa>
140022f59:     	nopl	(%rax)
140022f60:     	callq	0x14000b130 <_ZN2kp10WorkerPool6sharedEv>
140022f65:     	shrq	$0x5, %rsi
140022f69:     	leaq	0x52f80(%rip), %rcx     # 0x140075ef0 <_ZTVNSt3__110__function6__funcIZN2kp12_GLOBAL__N_16eachOfIZNS3_12LiveContacts12solveAndMoveERNS3_6MovingEddEUlyE_EEvyRKT_EUlyE_FvyEEE+0x10>
140022f70:     	movq	%rcx, 0x430(%rsp)
140022f78:     	leaq	0x178(%rsp), %rcx
140022f80:     	movq	%rcx, 0x438(%rsp)
140022f88:     	movq	%r14, 0x440(%rsp)
140022f90:     	movq	%rbx, 0x450(%rsp)
140022f98:     	movq	%rax, %rcx
140022f9b:     	movq	%rsi, %rdx
140022f9e:     	movq	%rbx, %r8
140022fa1:     	callq	0x14000b630 <_ZN2kp10WorkerPool3runEyRKNSt3__18functionIFvyEEE>
140022fa6:     	movq	0x450(%rsp), %rcx
140022fae:     	cmpq	%rbx, %rcx
140022fb1:     	je	0x140022fbf <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2d9f>
140022fb3:     	movl	$0x28, %eax
140022fb8:     	testq	%rcx, %rcx
140022fbb:     	jne	0x140022fc4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2da4>
140022fbd:     	jmp	0x140022fca <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2daa>
140022fbf:     	movl	$0x20, %eax
140022fc4:     	movq	(%rcx), %rdx
140022fc7:     	callq	*(%rdx,%rax)
140022fca:     	movq	0x188(%rsp), %rdx
140022fd2:     	movq	0x8(%rdx), %rbp
140022fd6:     	movq	(%rdx), %rax
140022fd9:     	movq	%rbp, %r13
140022fdc:     	subq	%rax, %r13
140022fdf:     	sarq	$0x3, %r13
140022fe3:     	movabsq	$-0xb81702e05c0b817, %rcx # imm = 0xF47E8FD1FA3F47E9
140022fed:     	imulq	%rcx, %r13
140022ff1:     	subq	%rax, %rbp
140022ff4:     	je	0x140023081 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2e61>
140022ffa:     	movq	0x198(%rsp), %rax
140023002:     	movq	0x60(%rsp), %rcx
140023007:     	movq	0x20(%rax), %r8
14002300b:     	movq	0x98(%rax), %rax
140023012:     	cmpq	$0x2c8, %rbp            # imm = 0x2C8
140023019:     	jne	0x140023020 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2e00>
14002301b:     	xorl	%r9d, %r9d
14002301e:     	jmp	0x14002306d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2e4d>
140023020:     	movq	%r13, %r10
140023023:     	andq	$-0x2, %r10
140023027:     	xorl	%r9d, %r9d
14002302a:     	nopw	(%rax,%rax)
140023030:     	movsd	(%rcx,%r9,8), %xmm0
140023036:     	movq	(%r8,%r9,8), %r11
14002303a:     	maxsd	(%rax,%r11,8), %xmm0
140023040:     	movsd	%xmm0, (%rax,%r11,8)
140023046:     	movsd	0x8(%rcx,%r9,8), %xmm0
14002304d:     	movq	0x8(%r8,%r9,8), %r11
140023052:     	maxsd	(%rax,%r11,8), %xmm0
140023058:     	movsd	%xmm0, (%rax,%r11,8)
14002305e:     	addq	$0x2, %r9
140023062:     	cmpq	%r9, %r10
140023065:     	jne	0x140023030 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2e10>
140023067:     	testb	$0x1, %r13b
14002306b:     	je	0x140023081 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2e61>
14002306d:     	movsd	(%rcx,%r9,8), %xmm0
140023073:     	movq	(%r8,%r9,8), %rcx
140023077:     	maxsd	(%rax,%rcx,8), %xmm0
14002307c:     	movsd	%xmm0, (%rax,%rcx,8)
140023081:     	movq	0x1d0(%rsp), %rax
140023089:     	movq	0x20(%rax), %rcx
14002308d:     	testq	%rcx, %rcx
140023090:     	je	0x1400230cf <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2eaf>
140023092:     	movl	$0x3, 0x430(%rsp)
14002309d:     	movq	(%rcx), %rax
1400230a0:     	leaq	0x430(%rsp), %rdx
1400230a8:     	callq	*0x30(%rax)
1400230ab:     	movq	0x188(%rsp), %rdx
1400230b3:     	movq	0x8(%rdx), %rbp
1400230b7:     	subq	(%rdx), %rbp
1400230ba:     	movq	%rbp, %r13
1400230bd:     	sarq	$0x3, %r13
1400230c1:     	movabsq	$-0xb81702e05c0b817, %rax # imm = 0xF47E8FD1FA3F47E9
1400230cb:     	imulq	%rax, %r13
1400230cf:     	cmpl	$0x3, 0x184(%rsp)
1400230d7:     	jne	0x1400230f0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2ed0>
1400230d9:     	xorl	%esi, %esi
1400230db:     	movq	0x1d0(%rsp), %rax
1400230e3:     	movq	0x20(%rax), %rcx
1400230e7:     	testq	%rcx, %rcx
1400230ea:     	jne	0x140023139 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2f19>
1400230ec:     	jmp	0x140023152 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2f32>
1400230ee:     	nop
1400230f0:     	movq	0x198(%rsp), %rcx
1400230f8:     	movq	0x80(%rsp), %r8
140023100:     	movq	0x88(%rsp), %r9
140023108:     	leaq	0x210(%rsp), %rax
140023110:     	movq	%rax, 0x28(%rsp)
140023115:     	movapd	0x50(%rsp), %xmm0
14002311b:     	movsd	%xmm0, 0x20(%rsp)
140023121:     	callq	0x140044c00 <_ZN2kp14MissedContacts4findERNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_4BodyENS1_9allocatorIS8_EEEERKNS2_INS_10SolverBodyENS4_ISE_EEEEdRKNS1_8functionIFS3_RKNS_11ContactPairEEEE>
140023126:     	movl	%eax, %esi
140023128:     	movq	0x1d0(%rsp), %rax
140023130:     	movq	0x20(%rax), %rcx
140023134:     	testq	%rcx, %rcx
140023137:     	je	0x140023152 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2f32>
140023139:     	movl	$0x9, 0x430(%rsp)
140023144:     	movq	(%rcx), %rax
140023147:     	leaq	0x430(%rsp), %rdx
14002314f:     	callq	*0x30(%rax)
140023152:     	testb	%sil, %sil
140023155:     	je	0x140023500 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x32e0>
14002315b:     	movq	0x88(%rsp), %rbx
140023163:     	leaq	0xc0(%rsp), %rax
14002316b:     	cmpq	%rax, %rbx
14002316e:     	je	0x14002328b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x306b>
140023174:     	movq	0xc0(%rsp), %r15
14002317c:     	movq	0xc8(%rsp), %rdi
140023184:     	movq	%rdi, %r14
140023187:     	subq	%r15, %r14
14002318a:     	movq	(%rbx), %rcx
14002318d:     	movq	0x10(%rbx), %rax
140023191:     	movq	%rax, %rdx
140023194:     	subq	%rcx, %rdx
140023197:     	cmpq	%rdx, %r14
14002319a:     	jbe	0x140023240 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3020>
1400231a0:     	testq	%rcx, %rcx
1400231a3:     	je	0x1400231bd <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x2f9d>
1400231a5:     	movq	%rcx, 0x8(%rbx)
1400231a9:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400231ae:     	movupd	%xmm10, (%rbx)
1400231b3:     	movq	$0x0, 0x10(%rbx)
1400231bb:     	xorl	%eax, %eax
1400231bd:     	movq	%r14, %rcx
1400231c0:     	sarq	$0x3, %rcx
1400231c4:     	movabsq	$-0x2c8590b21642c859, %rdx # imm = 0xD37A6F4DE9BD37A7
1400231ce:     	imulq	%rdx, %rcx
1400231d2:     	movabsq	$0x1642c8590b21642, %r8 # imm = 0x1642C8590B21642
1400231dc:     	cmpq	%r8, %rcx
1400231df:     	ja	0x140023fe4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dc4>
1400231e5:     	sarq	$0x3, %rax
1400231e9:     	imulq	%rdx, %rax
1400231ed:     	leaq	(%rax,%rax), %rdx
1400231f1:     	cmpq	%rcx, %rdx
1400231f4:     	cmovaq	%rdx, %rcx
1400231f8:     	movabsq	$0xb21642c8590b21, %rdx # imm = 0xB21642C8590B21
140023202:     	cmpq	%rdx, %rax
140023205:     	cmovaeq	%r8, %rcx
140023209:     	cmpq	%r8, %rcx
14002320c:     	ja	0x140023fe4 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dc4>
140023212:     	imulq	$0xb8, %rcx, %rdi
140023219:     	movq	%rdi, %rcx
14002321c:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
140023221:     	movq	%rax, %rsi
140023224:     	movq	%rax, (%rbx)
140023227:     	movq	%rax, 0x8(%rbx)
14002322b:     	addq	%rax, %rdi
14002322e:     	movq	%rdi, 0x10(%rbx)
140023232:     	movq	%rax, %rcx
140023235:     	jmp	0x140023279 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3059>
140023237:     	nopw	(%rax,%rax)
140023240:     	movq	0x8(%rbx), %r8
140023244:     	subq	%rcx, %r8
140023247:     	cmpq	%r8, %r14
14002324a:     	jbe	0x140023276 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3056>
14002324c:     	leaq	(%r15,%r8), %rsi
140023250:     	movq	%r15, %rdx
140023253:     	callq	0x140073050 <memmove>
140023258:     	movq	0x8(%rbx), %r14
14002325c:     	subq	%rsi, %rdi
14002325f:     	movq	%r14, %rcx
140023262:     	movq	%rsi, %rdx
140023265:     	movq	%rdi, %r8
140023268:     	callq	0x140073050 <memmove>
14002326d:     	addq	%r14, %rdi
140023270:     	movq	%rdi, 0x8(%rbx)
140023274:     	jmp	0x14002328b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x306b>
140023276:     	movq	%rcx, %rsi
140023279:     	movq	%r15, %rdx
14002327c:     	movq	%r14, %r8
14002327f:     	callq	0x140073050 <memmove>
140023284:     	addq	%r14, %rsi
140023287:     	movq	%rsi, 0x8(%rbx)
14002328b:     	movq	0x80(%rsp), %rax
140023293:     	movq	(%rax), %r8
140023296:     	cmpq	%r8, 0x8(%rax)
14002329a:     	movabsq	$0x51b3bea3677d46cf, %r11 # imm = 0x51B3BEA3677D46CF
1400232a4:     	je	0x140023355 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3135>
1400232aa:     	xorl	%eax, %eax
1400232ac:     	xorl	%ecx, %ecx
1400232ae:     	xorl	%edx, %edx
1400232b0:     	movq	0xa8(%rsp), %r9
1400232b8:     	movq	0x10(%r9,%rax), %r10
1400232bd:     	movq	%r10, 0x10(%r8,%rcx)
1400232c2:     	movups	(%r9,%rax), %xmm0
1400232c7:     	movups	%xmm0, (%r8,%rcx)
1400232cc:     	movq	0x80(%rsp), %r8
1400232d4:     	movq	0xa8(%rsp), %r9
1400232dc:     	movq	(%r8), %r8
1400232df:     	movq	0x28(%r9,%rax), %r10
1400232e4:     	movq	%r10, 0x60(%r8,%rcx)
1400232e9:     	movups	0x18(%r9,%rax), %xmm0
1400232ef:     	movups	%xmm0, 0x50(%r8,%rcx)
1400232f5:     	movq	0x80(%rsp), %r8
1400232fd:     	movq	0xa8(%rsp), %r9
140023305:     	movq	(%r8), %r8
140023308:     	movupd	0x30(%r9,%rax), %xmm0
14002330f:     	movupd	0x40(%r9,%rax), %xmm1
140023316:     	movupd	%xmm1, 0x28(%r8,%rcx)
14002331d:     	movupd	%xmm0, 0x18(%r8,%rcx)
140023324:     	incq	%rdx
140023327:     	movq	0x80(%rsp), %r9
14002332f:     	movq	(%r9), %r8
140023332:     	movq	0x8(%r9), %r9
140023336:     	subq	%r8, %r9
140023339:     	sarq	$0x3, %r9
14002333d:     	imulq	%r11, %r9
140023341:     	addq	$0x178, %rcx            # imm = 0x178
140023348:     	addq	$0x50, %rax
14002334c:     	cmpq	%r9, %rdx
14002334f:     	jb	0x1400232b0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3090>
140023355:     	movq	0x188(%rsp), %rcx
14002335d:     	movq	(%rcx), %rax
140023360:     	movq	0x8(%rcx), %rcx
140023364:     	movq	%rcx, %rdi
140023367:     	subq	%rax, %rdi
14002336a:     	sarq	$0x3, %rdi
14002336e:     	movabsq	$-0xb81702e05c0b817, %rdx # imm = 0xF47E8FD1FA3F47E9
140023378:     	imulq	%rdx, %rdi
14002337c:     	leaq	0x188(%rsp), %rdx
140023384:     	movq	%rdx, 0x150(%rsp)
14002338c:     	leaq	0x80(%rsp), %rdx
140023394:     	movq	%rdx, 0x158(%rsp)
14002339c:     	movq	%rdi, 0x178(%rsp)
1400233a4:     	leaq	0x1f(%rdi), %rsi
1400233a8:     	cmpq	$0xff, %rsi
1400233af:     	leaq	0x150(%rsp), %rbx
1400233b7:     	ja	0x140023400 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x31e0>
1400233b9:     	cmpq	%rax, %rcx
1400233bc:     	je	0x140023472 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3252>
1400233c2:     	xorl	%esi, %esi
1400233c4:     	nopw	%cs:(%rax,%rax)
1400233d0:     	movq	0x150(%rsp), %rax
1400233d8:     	movq	0x158(%rsp), %rcx
1400233e0:     	movq	(%rax), %rax
1400233e3:     	movq	0x8(%rcx), %rdx
1400233e7:     	movq	(%rax), %rcx
1400233ea:     	addq	%rsi, %rcx
1400233ed:     	callq	0x14003fe00 <_ZN2kp11SoftContact6followERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>
1400233f2:     	addq	$0x2c8, %rsi            # imm = 0x2C8
1400233f9:     	decq	%rdi
1400233fc:     	jne	0x1400233d0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x31b0>
1400233fe:     	jmp	0x140023472 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3252>
140023400:     	callq	0x14000b130 <_ZN2kp10WorkerPool6sharedEv>
140023405:     	shrq	$0x5, %rsi
140023409:     	leaq	0x52c50(%rip), %rcx     # 0x140076060 <_ZTVNSt3__110__function6__funcIZN2kp12_GLOBAL__N_16eachOfIZNS3_12LiveContacts12solveAndMoveERNS3_6MovingEddEUlyE0_EEvyRKT_EUlyE_FvyEEE+0x10>
140023410:     	movq	%rcx, 0x430(%rsp)
140023418:     	leaq	0x178(%rsp), %rcx
140023420:     	movq	%rcx, 0x438(%rsp)
140023428:     	movq	%rbx, 0x440(%rsp)
140023430:     	leaq	0x430(%rsp), %rdi
140023438:     	movq	%rdi, 0x450(%rsp)
140023440:     	movq	%rax, %rcx
140023443:     	movq	%rsi, %rdx
140023446:     	movq	%rdi, %r8
140023449:     	callq	0x14000b630 <_ZN2kp10WorkerPool3runEyRKNSt3__18functionIFvyEEE>
14002344e:     	movq	0x450(%rsp), %rcx
140023456:     	cmpq	%rdi, %rcx
140023459:     	je	0x140023467 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3247>
14002345b:     	movl	$0x28, %eax
140023460:     	testq	%rcx, %rcx
140023463:     	jne	0x14002346c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x324c>
140023465:     	jmp	0x140023472 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3252>
140023467:     	movl	$0x20, %eax
14002346c:     	movq	(%rcx), %rdx
14002346f:     	callq	*(%rdx,%rax)
140023472:     	movq	0x188(%rsp), %rdx
14002347a:     	movq	(%rdx), %rcx
14002347d:     	movq	0x8(%rdx), %rax
140023481:     	subq	%rcx, %rax
140023484:     	cmpq	%rax, %rbp
140023487:     	jae	0x1400234d9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x32b9>
140023489:     	imulq	$0x2c8, %r13, %rsi      # imm = 0x2C8
140023490:     	addq	%rsi, %rcx
140023493:     	movq	0x88(%rsp), %rdx
14002349b:     	movapd	0x50(%rsp), %xmm2
1400234a1:     	callq	0x140042320 <_ZN2kp11SoftContact10matchTrialERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEd>
1400234a6:     	incq	%r13
1400234a9:     	movq	0x188(%rsp), %rdx
1400234b1:     	movq	(%rdx), %rcx
1400234b4:     	movq	0x8(%rdx), %rax
1400234b8:     	subq	%rcx, %rax
1400234bb:     	sarq	$0x3, %rax
1400234bf:     	movabsq	$-0xb81702e05c0b817, %r8 # imm = 0xF47E8FD1FA3F47E9
1400234c9:     	imulq	%r8, %rax
1400234cd:     	addq	$0x2c8, %rsi            # imm = 0x2C8
1400234d4:     	cmpq	%rax, %r13
1400234d7:     	jb	0x140023490 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3270>
1400234d9:     	movq	0x60(%rsp), %rcx
1400234de:     	testq	%rcx, %rcx
1400234e1:     	je	0x140021cf0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1ad0>
1400234e7:     	movq	%rcx, 0x68(%rsp)
1400234ec:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400234f1:     	movq	0x188(%rsp), %rdx
1400234f9:     	jmp	0x140021cf0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1ad0>
1400234fe:     	nop
140023500:     	movq	0x60(%rsp), %rcx
140023505:     	testq	%rcx, %rcx
140023508:     	je	0x140023514 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x32f4>
14002350a:     	movq	%rcx, 0x68(%rsp)
14002350f:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023514:     	movq	0x1a0(%rsp), %rcx
14002351c:     	callq	0x140046c60 <_ZN2kp9PairReach5spendEv>
140023521:     	leaq	0x430(%rsp), %rbx
140023529:     	leaq	0x450(%rsp), %r13
140023531:     	movq	0x230(%rsp), %rcx
140023539:     	leaq	0x210(%rsp), %rax
140023541:     	cmpq	%rax, %rcx
140023544:     	movq	0x9c8(%rsp), %rdx
14002354c:     	je	0x140023560 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3340>
14002354e:     	movl	$0x28, %eax
140023553:     	testq	%rcx, %rcx
140023556:     	jne	0x140023565 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3345>
140023558:     	jmp	0x140023573 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3353>
14002355a:     	nopw	(%rax,%rax)
140023560:     	movl	$0x20, %eax
140023565:     	movq	(%rcx), %rdx
140023568:     	callq	*(%rdx,%rax)
14002356b:     	movq	0x9c8(%rsp), %rdx
140023573:     	movzbl	0x60(%r15), %eax
140023578:     	movb	%al, 0x28(%rsp)
14002357c:     	movq	%rdx, 0x20(%rsp)
140023581:     	leaq	0x350(%rsp), %rcx
140023589:     	movq	0x248(%rsp), %rdx
140023591:     	movq	0x48(%rsp), %r8
140023596:     	movq	%r12, %r9
140023599:     	callq	0x1400243d0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb>
14002359e:     	movsd	0x20(%r15), %xmm8
1400235a4:     	xorpd	%xmm2, %xmm2
1400235a8:     	leaq	0x368(%rsp), %rcx
1400235b0:     	movq	%r12, %rdx
1400235b3:     	movapd	0x50(%rsp), %xmm3
1400235b9:     	callq	0x140049880 <_ZNK2kp12DirectJoints5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEdd>
1400235be:     	movq	0x350(%rsp), %rsi
1400235c6:     	movq	0x358(%rsp), %rdi
1400235ce:     	cmpq	%rdi, %rsi
1400235d1:     	je	0x140023614 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x33f4>
1400235d3:     	nopw	%cs:(%rax,%rax)
1400235e0:     	movsd	%xmm8, 0x28(%rsp)
1400235e7:     	leaq	0x2e8(%rsp), %rax
1400235ef:     	movq	%rax, 0x20(%rsp)
1400235f4:     	movq	%rsi, %rcx
1400235f7:     	movq	%r12, %rdx
1400235fa:     	xorl	%r8d, %r8d
1400235fd:     	movapd	0x50(%rsp), %xmm3
140023603:     	callq	0x14004b210 <_ZN2kp9SoftJoint5solveERNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEEbdRKNS_8SoftnessEd>
140023608:     	addq	$0x270, %rsi            # imm = 0x270
14002360f:     	cmpq	%rdi, %rsi
140023612:     	jne	0x1400235e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x33c0>
140023614:     	movq	0xa0(%r15), %rcx
14002361b:     	testq	%rcx, %rcx
14002361e:     	je	0x140023634 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3414>
140023620:     	movl	$0x7, 0x430(%rsp)
14002362b:     	movq	(%rcx), %rax
14002362e:     	movq	%rbx, %rdx
140023631:     	callq	*0x30(%rax)
140023634:     	movq	0x88(%rsp), %rax
14002363c:     	movq	0x8(%rax), %rcx
140023640:     	movq	(%rax), %rax
140023643:     	movq	%rcx, %rdi
140023646:     	subq	%rax, %rdi
140023649:     	movsd	0x8(%r15), %xmm14
14002364f:     	movapd	%xmm10, 0x210(%rsp)
140023659:     	movq	$0x0, 0x220(%rsp)
140023665:     	subq	%rax, %rcx
140023668:     	je	0x140023820 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3600>
14002366e:     	js	0x140023fe9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3dc9>
140023674:     	sarq	$0x3, %rdi
140023678:     	movabsq	$-0x2c8590b21642c859, %rax # imm = 0xD37A6F4DE9BD37A7
140023682:     	imulq	%rax, %rdi
140023686:     	movq	%rdi, %rcx
140023689:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
14002368e:     	movq	%rax, %r14
140023691:     	movq	%rax, 0x210(%rsp)
140023699:     	movq	%rax, %rsi
14002369c:     	addq	%rdi, %rsi
14002369f:     	movq	%rsi, 0x220(%rsp)
1400236a7:     	movq	%rax, %rcx
1400236aa:     	xorl	%edx, %edx
1400236ac:     	movq	%rdi, %r8
1400236af:     	callq	0x140073000 <memset>
1400236b4:     	movq	%rsi, 0x218(%rsp)
1400236bc:     	movq	0x88(%rsp), %rax
1400236c4:     	movq	(%rax), %r8
1400236c7:     	cmpq	%r8, 0x8(%rax)
1400236cb:     	je	0x140023820 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3600>
1400236d1:     	movl	$0x2e, %eax
1400236d6:     	xorl	%ecx, %ecx
1400236d8:     	xorl	%edx, %edx
1400236da:     	jmp	0x140023780 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3560>
1400236df:     	nop
1400236e0:     	movupd	0x8(%r8,%rcx), %xmm0
1400236e7:     	mulpd	%xmm0, %xmm0
1400236eb:     	movupd	0x20(%r8,%rcx), %xmm1
1400236f2:     	mulpd	%xmm1, %xmm1
1400236f6:     	movsd	(%r8,%rcx), %xmm2
1400236fc:     	movhpd	0x18(%r8,%rcx), %xmm2   # xmm2 = xmm2[0],mem[0]
140023703:     	mulpd	%xmm2, %xmm2
140023707:     	movapd	%xmm0, %xmm3
14002370b:     	unpcklpd	%xmm1, %xmm3            # xmm3 = xmm3[0],xmm1[0]
14002370f:     	addpd	%xmm2, %xmm3
140023713:     	movhlps	%xmm0, %xmm1            # xmm1 = xmm0[1],xmm1[1]
140023716:     	addpd	%xmm3, %xmm1
14002371a:     	sqrtpd	%xmm1, %xmm0
14002371e:     	movq	0xd8(%rsp), %r8
140023726:     	movapd	%xmm0, %xmm1
14002372a:     	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
14002372e:     	mulsd	(%r8,%rdx,8), %xmm1
140023734:     	addsd	%xmm0, %xmm1
140023738:     	ucomisd	%xmm14, %xmm1
14002373d:     	seta	%r8b
140023741:     	movb	%r8b, (%r14,%rdx)
140023745:     	incq	%rdx
140023748:     	movq	0x88(%rsp), %r9
140023750:     	movq	(%r9), %r8
140023753:     	movq	0x8(%r9), %r9
140023757:     	subq	%r8, %r9
14002375a:     	sarq	$0x3, %r9
14002375e:     	movabsq	$-0x2c8590b21642c859, %r10 # imm = 0xD37A6F4DE9BD37A7
140023768:     	imulq	%r10, %r9
14002376c:     	addq	$0x2f, %rax
140023770:     	addq	$0xb8, %rcx
140023777:     	cmpq	%r9, %rdx
14002377a:     	jae	0x140023820 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3600>
140023780:     	movsd	0x78(%r8,%rcx), %xmm0
140023787:     	ucomisd	%xmm7, %xmm0
14002378b:     	jne	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
140023791:     	jp	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
140023797:     	movq	0x80(%rsp), %r9
14002379f:     	movq	(%r9), %r9
1400237a2:     	movsd	-0x108(%r9,%rax,8), %xmm0
1400237ac:     	ucomisd	%xmm7, %xmm0
1400237b0:     	jne	0x14002380c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x35ec>
1400237b2:     	jp	0x14002380c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x35ec>
1400237b4:     	movupd	-0x28(%r9,%rax,8), %xmm0
1400237bb:     	movupd	-0x18(%r9,%rax,8), %xmm1
1400237c2:     	cmpneqpd	%xmm10, %xmm1
1400237c8:     	cmpneqpd	%xmm10, %xmm0
1400237ce:     	shufps	$0x88, %xmm1, %xmm0     # xmm0 = xmm0[0,2],xmm1[0,2]
1400237d2:     	movmskps	%xmm0, %r10d
1400237d6:     	testl	%r10d, %r10d
1400237d9:     	jne	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
1400237df:     	movsd	-0x8(%r9,%rax,8), %xmm0
1400237e6:     	ucomisd	%xmm7, %xmm0
1400237ea:     	jne	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
1400237f0:     	jp	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
1400237f6:     	movsd	(%r9,%rax,8), %xmm0
1400237fc:     	ucomisd	%xmm7, %xmm0
140023800:     	jne	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
140023806:     	jp	0x1400236e0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x34c0>
14002380c:     	xorl	%r8d, %r8d
14002380f:     	jmp	0x140023741 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3521>
140023814:     	nopw	%cs:(%rax,%rax)
140023820:     	movsd	0x8(%r15), %xmm8
140023826:     	ucomisd	%xmm7, %xmm8
14002382b:     	movabsq	$0x51b3bea3677d46cf, %rdi # imm = 0x51B3BEA3677D46CF
140023835:     	jne	0x140023839 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3619>
140023837:     	jnp	0x140023863 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3643>
140023839:     	movq	0x210(%rsp), %rcx
140023841:     	movq	0x218(%rsp), %rsi
140023849:     	movq	%rsi, %r8
14002384c:     	subq	%rcx, %r8
14002384f:     	movl	$0x1, %edx
140023854:     	callq	0x1400732b0 <memchr>
140023859:     	testq	%rax, %rax
14002385c:     	je	0x1400238b8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3698>
14002385e:     	cmpq	%rsi, %rax
140023861:     	je	0x1400238b8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3698>
140023863:     	movsd	0x20(%r15), %xmm0
140023869:     	ucomisd	%xmm7, %xmm8
14002386e:     	movl	$0x0, %eax
140023873:     	leaq	0x210(%rsp), %rcx
14002387b:     	cmovaq	%rcx, %rax
14002387f:     	movq	%rax, 0x38(%rsp)
140023884:     	movsd	%xmm0, 0x30(%rsp)
14002388a:     	movapd	0x50(%rsp), %xmm0
140023890:     	movsd	%xmm0, 0x28(%rsp)
140023896:     	movb	$0x0, 0x20(%rsp)
14002389b:     	leaq	0x270(%rsp), %rcx
1400238a3:     	leaq	0x110(%rsp), %rdx
1400238ab:     	movq	0x48(%rsp), %r8
1400238b0:     	movq	%r12, %r9
1400238b3:     	callq	0x14004d6c0 <_ZN2kp13IslandNormals5solveERNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_4BodyENS1_9allocatorIS8_EEEERNS2_INS_10SolverBodyENS4_ISE_EEEEbddPKNS2_IcNS4_IcEEEE>
1400238b8:     	movq	0xa0(%r15), %rcx
1400238bf:     	testq	%rcx, %rcx
1400238c2:     	je	0x1400238d8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x36b8>
1400238c4:     	movl	$0x8, 0x430(%rsp)
1400238cf:     	movq	(%rcx), %rax
1400238d2:     	movq	%rbx, %rdx
1400238d5:     	callq	*0x30(%rax)
1400238d8:     	cmpb	$0x1, 0xb0(%r15)
1400238e0:     	jne	0x140023940 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3720>
1400238e2:     	movsd	0x78(%r15), %xmm0
1400238e8:     	movsd	%xmm0, 0x30(%rsp)
1400238ee:     	movapd	0x50(%rsp), %xmm0
1400238f4:     	movsd	%xmm0, 0x28(%rsp)
1400238fa:     	leaq	0x270(%rsp), %rax
140023902:     	movq	%rax, 0x20(%rsp)
140023907:     	leaq	0x110(%rsp), %rcx
14002390f:     	movq	%r12, %rdx
140023912:     	leaq	0x368(%rsp), %r8
14002391a:     	leaq	0x350(%rsp), %r9
140023922:     	callq	0x140050e00 <_ZN2kp20solveFrictionIslandsERNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS2_EEEERNS1_INS_10SolverBodyENS3_IS7_EEEERKNS_12DirectJointsERKNS1_INS_9SoftJointENS3_ISE_EEEERNS_13ContactLevelsEdd>
140023927:     	movq	0xa0(%r15), %rcx
14002392e:     	testq	%rcx, %rcx
140023931:     	jne	0x1400239ba <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x379a>
140023937:     	jmp	0x1400239ce <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x37ae>
14002393c:     	nopl	(%rax)
140023940:     	leaq	0x52ab1(%rip), %rax     # 0x1400763f8 <_ZTVNSt3__110__function6__funcIZNK2kp8SoftStep4stepERNS_6vectorINS2_4BodyENS_9allocatorIS5_EEEERKNS4_INS2_11ContactPairENS6_ISA_EEEERKNS2_8JointSetENS2_7Vector3EdRNS2_13ContactForcesERNS4_INS4_IdNS6_IdEEEENS6_ISM_EEEEE3$_1FvyEEE+0x10>
140023947:     	movq	%rax, 0x430(%rsp)
14002394f:     	leaq	0x110(%rsp), %rdx
140023957:     	movq	%rdx, 0x438(%rsp)
14002395f:     	movq	%r12, 0x440(%rsp)
140023967:     	movq	%r15, 0x448(%rsp)
14002396f:     	movq	%rbx, 0x450(%rsp)
140023977:     	leaq	0x270(%rsp), %rcx
14002397f:     	movq	%r12, %r8
140023982:     	movq	%rbx, %r9
140023985:     	callq	0x14004b8f0 <_ZN2kp13ContactLevels4eachERKNSt3__16vectorINS_11SoftContactENS_13StepAllocatorIS3_EEEERKNS2_INS_10SolverBodyENS4_IS9_EEEERKNS1_8functionIFvyEEE>
14002398a:     	movq	0x450(%rsp), %rcx
140023992:     	cmpq	%rbx, %rcx
140023995:     	je	0x1400239a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3783>
140023997:     	movl	$0x28, %eax
14002399c:     	testq	%rcx, %rcx
14002399f:     	jne	0x1400239a8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3788>
1400239a1:     	jmp	0x140023927 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3707>
1400239a3:     	movl	$0x20, %eax
1400239a8:     	movq	(%rcx), %rdx
1400239ab:     	callq	*(%rdx,%rax)
1400239ae:     	movq	0xa0(%r15), %rcx
1400239b5:     	testq	%rcx, %rcx
1400239b8:     	je	0x1400239ce <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x37ae>
1400239ba:     	movl	$0xa, 0x430(%rsp)
1400239c5:     	movq	(%rcx), %rax
1400239c8:     	movq	%rbx, %rdx
1400239cb:     	callq	*0x30(%rax)
1400239ce:     	movq	0x210(%rsp), %rcx
1400239d6:     	testq	%rcx, %rcx
1400239d9:     	je	0x140021880 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1660>
1400239df:     	movq	%rcx, 0x218(%rsp)
1400239e7:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400239ec:     	jmp	0x140021880 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x1660>
1400239f1:     	movq	0x48(%rsp), %rcx
1400239f6:     	movq	(%rcx), %rax
1400239f9:     	movq	0x8(%rcx), %rcx
1400239fd:     	subq	%rax, %rcx
140023a00:     	je	0x140023c1c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x39fc>
140023a06:     	sarq	$0x3, %rcx
140023a0a:     	imulq	%rdi, %rcx
140023a0e:     	movq	0x130(%rsp), %rdx
140023a16:     	addq	$0x18, %rax
140023a1a:     	xorpd	%xmm0, %xmm0
140023a1e:     	movapd	0x5218a(%rip), %xmm1    # 0x140075bb0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xb8>
140023a26:     	jmp	0x140023a46 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3826>
140023a28:     	nopl	(%rax,%rax)
140023a30:     	addq	$0x178, %rax            # imm = 0x178
140023a36:     	addq	$0xb8, %rdx
140023a3d:     	decq	%rcx
140023a40:     	je	0x140023c1c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x39fc>
140023a46:     	movsd	0x78(%rdx), %xmm3
140023a4b:     	ucomisd	%xmm0, %xmm3
140023a4f:     	jne	0x140023a53 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3833>
140023a51:     	jnp	0x140023a30 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3810>
140023a53:     	movupd	(%rdx), %xmm4
140023a57:     	movsd	(%rax), %xmm2
140023a5b:     	movupd	0x58(%rax), %xmm5
140023a60:     	movapd	%xmm1, %xmm9
140023a65:     	movhpd	0x68(%rax), %xmm3       # xmm3 = xmm3[0],mem[0]
140023a6a:     	divpd	%xmm5, %xmm9
140023a6f:     	movapd	%xmm1, %xmm5
140023a73:     	divpd	%xmm3, %xmm5
140023a77:     	movsd	0x10(%rdx), %xmm3
140023a7c:     	mulsd	%xmm5, %xmm3
140023a80:     	movapd	%xmm5, %xmm7
140023a84:     	unpcklpd	%xmm5, %xmm7            # xmm7 = xmm7[0],xmm5[0]
140023a88:     	mulpd	%xmm4, %xmm7
140023a8c:     	movupd	%xmm7, 0x20(%rax)
140023a91:     	movsd	%xmm3, 0x30(%rax)
140023a96:     	movupd	0x18(%rdx), %xmm10
140023a9c:     	movupd	0x20(%rdx), %xmm12
140023aa2:     	movupd	0x8(%rax), %xmm4
140023aa7:     	movupd	0x10(%rax), %xmm3
140023aac:     	movapd	%xmm3, %xmm7
140023ab0:     	shufpd	$0x1, %xmm4, %xmm7      # xmm7 = xmm7[1],xmm4[0]
140023ab5:     	movapd	%xmm12, %xmm11
140023aba:     	mulpd	%xmm7, %xmm11
140023abf:     	shufpd	$0x1, %xmm10, %xmm12    # xmm12 = xmm12[1],xmm10[0]
140023ac5:     	movapd	%xmm12, %xmm8
140023aca:     	mulpd	%xmm3, %xmm8
140023acf:     	subpd	%xmm8, %xmm11
140023ad4:     	mulpd	%xmm4, %xmm12
140023ad9:     	addpd	%xmm11, %xmm11
140023ade:     	movapd	%xmm2, %xmm8
140023ae3:     	unpcklpd	%xmm2, %xmm8            # xmm8 = xmm8[0],xmm2[0]
140023ae8:     	movapd	%xmm8, %xmm13
140023aed:     	mulpd	%xmm11, %xmm13
140023af2:     	addpd	%xmm10, %xmm13
140023af7:     	mulpd	%xmm7, %xmm10
140023afc:     	subpd	%xmm10, %xmm12
140023b01:     	addpd	%xmm12, %xmm12
140023b06:     	movapd	%xmm12, %xmm14
140023b0b:     	unpckhpd	%xmm12, %xmm14          # xmm14 = xmm14[1],xmm12[1]
140023b10:     	mulsd	%xmm2, %xmm14
140023b15:     	addsd	0x28(%rdx), %xmm14
140023b1b:     	movapd	%xmm7, %xmm10
140023b20:     	mulpd	%xmm12, %xmm10
140023b25:     	shufpd	$0x1, %xmm11, %xmm12    # xmm12 = xmm12[1],xmm11[0]
140023b2b:     	mulpd	%xmm3, %xmm12
140023b30:     	subpd	%xmm12, %xmm10
140023b35:     	addpd	%xmm13, %xmm10
140023b3a:     	mulpd	%xmm9, %xmm10
140023b3f:     	movapd	%xmm3, %xmm9
140023b44:     	unpcklpd	%xmm4, %xmm9            # xmm9 = xmm9[0],xmm4[0]
140023b49:     	mulpd	%xmm11, %xmm9
140023b4e:     	movapd	%xmm9, %xmm11
140023b53:     	unpckhpd	%xmm9, %xmm11           # xmm11 = xmm11[1],xmm9[1]
140023b58:     	subsd	%xmm11, %xmm9
140023b5d:     	addsd	%xmm14, %xmm9
140023b62:     	unpckhpd	%xmm5, %xmm5            # xmm5 = xmm5[1,1]
140023b66:     	mulsd	%xmm9, %xmm5
140023b6b:     	movapd	%xmm10, %xmm11
140023b70:     	shufpd	$0x1, %xmm5, %xmm11     # xmm11 = xmm11[1],xmm5[0]
140023b76:     	mulpd	%xmm4, %xmm11
140023b7b:     	movapd	%xmm3, %xmm12
140023b80:     	unpckhpd	%xmm3, %xmm12           # xmm12 = xmm12[1],xmm3[1]
140023b85:     	mulsd	%xmm10, %xmm12
140023b8a:     	movapd	%xmm3, %xmm9
140023b8f:     	mulpd	%xmm10, %xmm9
140023b94:     	subpd	%xmm9, %xmm11
140023b99:     	movapd	%xmm4, %xmm9
140023b9e:     	mulsd	%xmm5, %xmm9
140023ba3:     	subsd	%xmm9, %xmm12
140023ba8:     	movapd	%xmm11, %xmm9
140023bad:     	shufpd	$0x1, %xmm12, %xmm9     # xmm9 = xmm9[1],xmm12[0]
140023bb3:     	addpd	%xmm9, %xmm9
140023bb8:     	addpd	%xmm11, %xmm11
140023bbd:     	mulpd	%xmm9, %xmm8
140023bc2:     	mulsd	%xmm11, %xmm2
140023bc7:     	addpd	%xmm10, %xmm8
140023bcc:     	addsd	%xmm5, %xmm2
140023bd0:     	movapd	%xmm3, %xmm5
140023bd4:     	mulpd	%xmm11, %xmm5
140023bd9:     	movapd	%xmm9, %xmm10
140023bde:     	shufpd	$0x1, %xmm11, %xmm10    # xmm10 = xmm10[1],xmm11[0]
140023be4:     	mulpd	%xmm7, %xmm10
140023be9:     	subpd	%xmm10, %xmm5
140023bee:     	addpd	%xmm8, %xmm5
140023bf3:     	mulsd	%xmm9, %xmm3
140023bf8:     	unpckhpd	%xmm9, %xmm9            # xmm9 = xmm9[1,1]
140023bfd:     	mulsd	%xmm4, %xmm9
140023c02:     	subsd	%xmm3, %xmm9
140023c07:     	addsd	%xmm2, %xmm9
140023c0c:     	movupd	%xmm5, 0x38(%rax)
140023c11:     	movsd	%xmm9, 0x48(%rax)
140023c17:     	jmp	0x140023a30 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3810>
140023c1c:     	movq	0x9c0(%rsp), %rcx
140023c24:     	movq	(%rcx), %rax
140023c27:     	movq	%rax, 0x8(%rcx)
140023c2b:     	movq	0x110(%rsp), %rsi
140023c33:     	movq	0x118(%rsp), %rdi
140023c3b:     	cmpq	%rdi, %rsi
140023c3e:     	je	0x140023c62 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3a42>
140023c40:     	movq	%rsi, %rcx
140023c43:     	movq	0x9c0(%rsp), %rdx
140023c4b:     	movapd	0x50(%rsp), %xmm2
140023c51:     	callq	0x140042d20 <_ZNK2kp11SoftContact8rememberERNS_13ContactForcesEd>
140023c56:     	addq	$0x2c8, %rsi            # imm = 0x2C8
140023c5d:     	cmpq	%rdi, %rsi
140023c60:     	jne	0x140023c40 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3a20>
140023c62:     	movq	0xa0(%r15), %rcx
140023c69:     	testq	%rcx, %rcx
140023c6c:     	je	0x140023c87 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3a67>
140023c6e:     	movl	$0xb, 0x430(%rsp)
140023c79:     	movq	(%rcx), %rax
140023c7c:     	leaq	0x430(%rsp), %rdx
140023c84:     	callq	*0x30(%rax)
140023c87:     	movq	0x2c8(%rsp), %rdi
140023c8f:     	testq	%rdi, %rdi
140023c92:     	je	0x140023d23 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b03>
140023c98:     	movq	0x2d0(%rsp), %rsi
140023ca0:     	movq	%rdi, %rcx
140023ca3:     	cmpq	%rsi, %rdi
140023ca6:     	je	0x140023d16 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3af6>
140023ca8:     	addq	$-0x30, %rsi
140023cac:     	jmp	0x140023cc0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3aa0>
140023cae:     	nop
140023cb0:     	leaq	-0x60(%rsi), %rax
140023cb4:     	addq	$-0x30, %rsi
140023cb8:     	cmpq	%rdi, %rsi
140023cbb:     	movq	%rax, %rsi
140023cbe:     	je	0x140023d0e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3aee>
140023cc0:     	movq	0x18(%rsi), %rcx
140023cc4:     	testq	%rcx, %rcx
140023cc7:     	je	0x140023cd2 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ab2>
140023cc9:     	movq	%rcx, 0x20(%rsi)
140023ccd:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023cd2:     	cmpq	$0x0, (%rsi)
140023cd6:     	je	0x140023ce8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ac8>
140023cd8:     	movq	%rsi, %rcx
140023cdb:     	callq	0x140026d50 <_ZNSt3__16vectorIN2kp4BodyENS1_13StepAllocatorIS2_EEE5clearB9nqe230106Ev>
140023ce0:     	movq	(%rsi), %rcx
140023ce3:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023ce8:     	movq	-0x18(%rsi), %rcx
140023cec:     	testq	%rcx, %rcx
140023cef:     	je	0x140023cfa <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ada>
140023cf1:     	movq	%rcx, -0x10(%rsi)
140023cf5:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023cfa:     	movq	-0x30(%rsi), %rcx
140023cfe:     	testq	%rcx, %rcx
140023d01:     	je	0x140023cb0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3a90>
140023d03:     	movq	%rcx, -0x28(%rsi)
140023d07:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023d0c:     	jmp	0x140023cb0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3a90>
140023d0e:     	movq	0x2c8(%rsp), %rcx
140023d16:     	movq	%rdi, 0x2d0(%rsp)
140023d1e:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023d23:     	movq	0x2b0(%rsp), %rcx
140023d2b:     	testq	%rcx, %rcx
140023d2e:     	je	0x140023d3d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b1d>
140023d30:     	movq	%rcx, 0x2b8(%rsp)
140023d38:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023d3d:     	movq	0x288(%rsp), %rcx
140023d45:     	testq	%rcx, %rcx
140023d48:     	je	0x140023d57 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b37>
140023d4a:     	movq	%rcx, 0x290(%rsp)
140023d52:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023d57:     	movq	0x270(%rsp), %rcx
140023d5f:     	testq	%rcx, %rcx
140023d62:     	je	0x140023d71 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b51>
140023d64:     	movq	%rcx, 0x278(%rsp)
140023d6c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023d71:     	movq	0x410(%rsp), %rcx
140023d79:     	testq	%rcx, %rcx
140023d7c:     	je	0x140023d8b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b6b>
140023d7e:     	movq	%rcx, 0x418(%rsp)
140023d86:     	callq	0x140072e60 <_ZdlPv>
140023d8b:     	leaq	0x368(%rsp), %rcx
140023d93:     	callq	0x140026e40 <_ZN2kp12DirectJointsD2Ev>
140023d98:     	movq	0x350(%rsp), %rcx
140023da0:     	testq	%rcx, %rcx
140023da3:     	je	0x140023db2 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3b92>
140023da5:     	movq	%rcx, 0x358(%rsp)
140023dad:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023db2:     	movq	0xd8(%rsp), %rcx
140023dba:     	testq	%rcx, %rcx
140023dbd:     	je	0x140023dcc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3bac>
140023dbf:     	movq	%rcx, 0xe0(%rsp)
140023dc7:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023dcc:     	movq	0xc0(%rsp), %rcx
140023dd4:     	testq	%rcx, %rcx
140023dd7:     	je	0x140023de6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3bc6>
140023dd9:     	movq	%rcx, 0xc8(%rsp)
140023de1:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023de6:     	movq	0xa8(%rsp), %rcx
140023dee:     	testq	%rcx, %rcx
140023df1:     	je	0x140023e00 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3be0>
140023df3:     	movq	%rcx, 0xb0(%rsp)
140023dfb:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e00:     	movq	0x90(%rsp), %rcx
140023e08:     	testq	%rcx, %rcx
140023e0b:     	je	0x140023e1a <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3bfa>
140023e0d:     	movq	%rcx, 0x98(%rsp)
140023e15:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e1a:     	movq	0x7c8(%rsp), %rcx
140023e22:     	testq	%rcx, %rcx
140023e25:     	je	0x140023e34 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c14>
140023e27:     	movq	%rcx, 0x7d0(%rsp)
140023e2f:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e34:     	movq	0x7b0(%rsp), %rcx
140023e3c:     	testq	%rcx, %rcx
140023e3f:     	je	0x140023e4e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c2e>
140023e41:     	movq	%rcx, 0x7b8(%rsp)
140023e49:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e4e:     	movq	0x798(%rsp), %rcx
140023e56:     	testq	%rcx, %rcx
140023e59:     	je	0x140023e68 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c48>
140023e5b:     	movq	%rcx, 0x7a0(%rsp)
140023e63:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e68:     	movq	0x780(%rsp), %rcx
140023e70:     	testq	%rcx, %rcx
140023e73:     	je	0x140023e82 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c62>
140023e75:     	movq	%rcx, 0x788(%rsp)
140023e7d:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e82:     	movq	0x768(%rsp), %rcx
140023e8a:     	testq	%rcx, %rcx
140023e8d:     	je	0x140023e9c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c7c>
140023e8f:     	movq	%rcx, 0x770(%rsp)
140023e97:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023e9c:     	movq	0x750(%rsp), %rcx
140023ea4:     	testq	%rcx, %rcx
140023ea7:     	je	0x140023eb6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3c96>
140023ea9:     	movq	%rcx, 0x758(%rsp)
140023eb1:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023eb6:     	leaq	0x7e0(%rsp), %rcx
140023ebe:     	callq	0x140025e80 <_ZN2kp14MissedContactsD2Ev>
140023ec3:     	movq	0x110(%rsp), %rsi
140023ecb:     	testq	%rsi, %rsi
140023ece:     	je	0x140023f2b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3d0b>
140023ed0:     	movq	0x118(%rsp), %rdi
140023ed8:     	movq	%rsi, %rcx
140023edb:     	cmpq	%rdi, %rsi
140023ede:     	jne	0x140023efc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3cdc>
140023ee0:     	jmp	0x140023f1e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3cfe>
140023ee2:     	nopw	%cs:(%rax,%rax)
140023ef0:     	addq	$-0x2c8, %rdi           # imm = 0xFD38
140023ef7:     	cmpq	%rsi, %rdi
140023efa:     	je	0x140023f16 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3cf6>
140023efc:     	movq	-0x2c0(%rdi), %rcx
140023f03:     	testq	%rcx, %rcx
140023f06:     	je	0x140023ef0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3cd0>
140023f08:     	movq	%rcx, -0x2b8(%rdi)
140023f0f:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023f14:     	jmp	0x140023ef0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3cd0>
140023f16:     	movq	0x110(%rsp), %rcx
140023f1e:     	movq	%rsi, 0x118(%rsp)
140023f26:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023f2b:     	movq	0xf0(%rsp), %rcx
140023f33:     	testq	%rcx, %rcx
140023f36:     	je	0x140023f45 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3d25>
140023f38:     	movq	%rcx, 0xf8(%rsp)
140023f40:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023f45:     	movq	0x130(%rsp), %rcx
140023f4d:     	testq	%rcx, %rcx
140023f50:     	je	0x140023f5f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3d3f>
140023f52:     	movq	%rcx, 0x138(%rsp)
140023f5a:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140023f5f:     	movaps	0x8a0(%rsp), %xmm6
140023f67:     	movaps	0x8b0(%rsp), %xmm7
140023f6f:     	movaps	0x8c0(%rsp), %xmm8
140023f78:     	movaps	0x8d0(%rsp), %xmm9
140023f81:     	movaps	0x8e0(%rsp), %xmm10
140023f8a:     	movaps	0x8f0(%rsp), %xmm11
140023f93:     	movaps	0x900(%rsp), %xmm12
140023f9c:     	movaps	0x910(%rsp), %xmm13
140023fa5:     	movaps	0x920(%rsp), %xmm14
140023fae:     	movaps	0x930(%rsp), %xmm15
140023fb7:     	addq	$0x948, %rsp            # imm = 0x948
140023fbe:     	popq	%rbx
140023fbf:     	popq	%rbp
140023fc0:     	popq	%rdi
140023fc1:     	popq	%rsi
140023fc2:     	popq	%r12
140023fc4:     	popq	%r13
140023fc6:     	popq	%r14
140023fc8:     	popq	%r15
140023fca:     	retq
140023fcb:     	callq	0x140026710 <_ZNSt3__16vectorIN2kp11SoftContactENS1_13StepAllocatorIS2_EEE20__throw_length_errorB9nqe230106Ev>
140023fd0:     	callq	0x140019b20 <_ZNSt3__16vectorIdN2kp13StepAllocatorIdEEE20__throw_length_errorB9nqe230106Ev>
140023fd5:     	callq	0x140026470 <_ZNSt3__16vectorIN2kp10SolverBodyENS1_13StepAllocatorIS2_EEE20__throw_length_errorB9nqe230106Ev>
140023fda:     	callq	0x140024850 <_ZNSt3__16vectorIN2kp12_GLOBAL__N_16Moving4PoseENS1_13StepAllocatorIS4_EEE20__throw_length_errorB9nqe230106Ev>
140023fdf:     	callq	0x140019b20 <_ZNSt3__16vectorIdN2kp13StepAllocatorIdEEE20__throw_length_errorB9nqe230106Ev>
140023fe4:     	callq	0x140026470 <_ZNSt3__16vectorIN2kp10SolverBodyENS1_13StepAllocatorIS2_EEE20__throw_length_errorB9nqe230106Ev>
140023fe9:     	callq	0x140026ca0 <_ZNSt3__16vectorIcN2kp13StepAllocatorIcEEE20__throw_length_errorB9nqe230106Ev>
140023fee:     	callq	0x140026470 <_ZNSt3__16vectorIN2kp10SolverBodyENS1_13StepAllocatorIS2_EEE20__throw_length_errorB9nqe230106Ev>
140023ff3:     	callq	0x140026730 <_ZNSt3__16vectorIyN2kp13StepAllocatorIyEEE20__throw_length_errorB9nqe230106Ev>
140023ff8:     	callq	0x140019b20 <_ZNSt3__16vectorIdN2kp13StepAllocatorIdEEE20__throw_length_errorB9nqe230106Ev>
140023ffd:     	callq	0x140026730 <_ZNSt3__16vectorIyN2kp13StepAllocatorIyEEE20__throw_length_errorB9nqe230106Ev>
140024002:     	callq	0x140024850 <_ZNSt3__16vectorIN2kp12_GLOBAL__N_16Moving4PoseENS1_13StepAllocatorIS4_EEE20__throw_length_errorB9nqe230106Ev>
140024007:     	jmp	0x140024104 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ee4>
14002400c:     	movq	%rax, %rsi
14002400f:     	jmp	0x140024339 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4119>
140024014:     	movq	%rax, %rsi
140024017:     	jmp	0x140024346 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4126>
14002401c:     	movq	%rax, %rsi
14002401f:     	jmp	0x140024360 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4140>
140024024:     	jmp	0x140024030 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3e10>
140024026:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
14002402b:     	jmp	0x140024104 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3ee4>
140024030:     	movq	%rax, %rsi
140024033:     	movq	0x1e0(%rsp), %rcx
14002403b:     	testq	%rcx, %rcx
14002403e:     	je	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
140024044:     	movq	%rcx, 0x1e8(%rsp)
14002404c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140024051:     	jmp	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
140024056:     	movq	%rax, %rsi
140024059:     	jmp	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
14002405e:     	movq	%rax, %rsi
140024061:     	movq	0x438(%rsp), %rcx
140024069:     	testq	%rcx, %rcx
14002406c:     	je	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
140024072:     	movq	%rcx, 0x440(%rsp)
14002407a:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002407f:     	jmp	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
140024084:     	jmp	0x1400240d3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3eb3>
140024086:     	movq	%rax, %rsi
140024089:     	movq	0x450(%rsp), %rcx
140024091:     	movl	$0x20, %eax
140024096:     	cmpq	%rbx, %rcx
140024099:     	je	0x1400240a9 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3e89>
14002409b:     	movl	$0x28, %eax
1400240a0:     	testq	%rcx, %rcx
1400240a3:     	je	0x1400241ac <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f8c>
1400240a9:     	movq	(%rcx), %rdx
1400240ac:     	callq	*(%rdx,%rax)
1400240af:     	jmp	0x1400241ac <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f8c>
1400240b4:     	movq	%rax, %rsi
1400240b7:     	jmp	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
1400240bc:     	movq	%rax, %rsi
1400240bf:     	jmp	0x14002436d <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x414d>
1400240c4:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
1400240c9:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
1400240ce:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
1400240d3:     	movq	%rax, %rsi
1400240d6:     	movq	%r14, %rcx
1400240d9:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400240de:     	movq	%rsi, %rcx
1400240e1:     	callq	0x140072ed0 <_Unwind_Resume>
1400240e6:     	movq	%rax, %rsi
1400240e9:     	movq	0x450(%rsp), %rcx
1400240f1:     	movl	$0x20, %eax
1400240f6:     	cmpq	%rbx, %rcx
1400240f9:     	jne	0x14002431c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40fc>
1400240ff:     	jmp	0x140024326 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4106>
140024104:     	movq	%rax, %rsi
140024107:     	movq	0xd8(%rsp), %rcx
14002410f:     	testq	%rcx, %rcx
140024112:     	jne	0x140024140 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f20>
140024114:     	movq	0xc0(%rsp), %rcx
14002411c:     	testq	%rcx, %rcx
14002411f:     	jne	0x14002415a <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f3a>
140024121:     	movq	0xa8(%rsp), %rcx
140024129:     	testq	%rcx, %rcx
14002412c:     	jne	0x140024174 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f54>
14002412e:     	movq	0x90(%rsp), %rcx
140024136:     	testq	%rcx, %rcx
140024139:     	jne	0x140024192 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f72>
14002413b:     	jmp	0x140024353 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4133>
140024140:     	movq	%rcx, 0xe0(%rsp)
140024148:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002414d:     	movq	0xc0(%rsp), %rcx
140024155:     	testq	%rcx, %rcx
140024158:     	je	0x140024121 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f01>
14002415a:     	movq	%rcx, 0xc8(%rsp)
140024162:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140024167:     	movq	0xa8(%rsp), %rcx
14002416f:     	testq	%rcx, %rcx
140024172:     	je	0x14002412e <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3f0e>
140024174:     	movq	%rcx, 0xb0(%rsp)
14002417c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140024181:     	movq	0x90(%rsp), %rcx
140024189:     	testq	%rcx, %rcx
14002418c:     	je	0x140024353 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4133>
140024192:     	movq	%rcx, 0x98(%rsp)
14002419a:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
14002419f:     	jmp	0x140024353 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4133>
1400241a4:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
1400241a9:     	movq	%rax, %rsi
1400241ac:     	movq	0x210(%rsp), %rcx
1400241b4:     	testq	%rcx, %rcx
1400241b7:     	je	0x14002432c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x410c>
1400241bd:     	movq	%rcx, 0x218(%rsp)
1400241c5:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400241ca:     	jmp	0x14002432c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x410c>
1400241cf:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
1400241d1:     	movq	%rax, %rsi
1400241d4:     	movq	0x450(%rsp), %rcx
1400241dc:     	movl	$0x20, %eax
1400241e1:     	cmpq	%rdi, %rcx
1400241e4:     	jne	0x140024201 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3fe1>
1400241e6:     	jmp	0x14002420b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3feb>
1400241e8:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
1400241ea:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
1400241ec:     	movq	%rax, %rsi
1400241ef:     	movq	0x450(%rsp), %rcx
1400241f7:     	movl	$0x20, %eax
1400241fc:     	cmpq	%rbx, %rcx
1400241ff:     	je	0x14002420b <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x3feb>
140024201:     	movl	$0x28, %eax
140024206:     	testq	%rcx, %rcx
140024209:     	je	0x140024268 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4048>
14002420b:     	movq	(%rcx), %rdx
14002420e:     	callq	*(%rdx,%rax)
140024211:     	jmp	0x140024268 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4048>
140024213:     	movq	%rax, %rsi
140024216:     	movq	0x450(%rsp), %rcx
14002421e:     	movl	$0x20, %eax
140024223:     	cmpq	%rbx, %rcx
140024226:     	je	0x140024236 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4016>
140024228:     	movl	$0x28, %eax
14002422d:     	testq	%rcx, %rcx
140024230:     	je	0x140024302 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40e2>
140024236:     	movq	(%rcx), %rdx
140024239:     	callq	*(%rdx,%rax)
14002423c:     	jmp	0x140024302 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40e2>
140024241:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
140024243:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
140024245:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
140024247:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
140024249:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
14002424b:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
14002424d:     	jmp	0x14002424f <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x402f>
14002424f:     	movq	%rax, %rsi
140024252:     	jmp	0x14002432c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x410c>
140024257:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
140024259:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
14002425b:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
14002425d:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
14002425f:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
140024261:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
140024263:     	jmp	0x140024265 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4045>
140024265:     	movq	%rax, %rsi
140024268:     	movq	0x60(%rsp), %rcx
14002426d:     	testq	%rcx, %rcx
140024270:     	je	0x140024302 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40e2>
140024276:     	movq	%rcx, 0x68(%rsp)
14002427b:     	jmp	0x1400242fd <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40dd>
140024280:     	jmp	0x140024284 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4064>
140024282:     	jmp	0x1400242a3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4083>
140024284:     	movq	%rax, %rsi
140024287:     	movq	0x438(%rsp), %rcx
14002428f:     	testq	%rcx, %rcx
140024292:     	je	0x1400242ad <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x408d>
140024294:     	movq	%rcx, 0x440(%rsp)
14002429c:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400242a1:     	jmp	0x1400242ad <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x408d>
1400242a3:     	movq	%rax, %rsi
1400242a6:     	jmp	0x140024302 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40e2>
1400242a8:     	jmp	0x1400242aa <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x408a>
1400242aa:     	movq	%rax, %rsi
1400242ad:     	movq	0x60(%rsp), %rdi
1400242b2:     	testq	%rdi, %rdi
1400242b5:     	je	0x140024302 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40e2>
1400242b7:     	movq	0x68(%rsp), %rbx
1400242bc:     	movq	%rdi, %rcx
1400242bf:     	cmpq	%rbx, %rdi
1400242c2:     	jne	0x1400242dc <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40bc>
1400242c4:     	jmp	0x1400242f8 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40d8>
1400242c6:     	nopw	%cs:(%rax,%rax)
1400242d0:     	addq	$-0x268, %rbx           # imm = 0xFD98
1400242d7:     	cmpq	%rdi, %rbx
1400242da:     	je	0x1400242f3 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40d3>
1400242dc:     	leaq	-0x230(%rbx), %rax
1400242e3:     	movq	-0x30(%rbx), %rcx
1400242e7:     	cmpq	%rcx, %rax
1400242ea:     	je	0x1400242d0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40b0>
1400242ec:     	callq	0x140072e60 <_ZdlPv>
1400242f1:     	jmp	0x1400242d0 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x40b0>
1400242f3:     	movq	0x60(%rsp), %rcx
1400242f8:     	movq	%rdi, 0x68(%rsp)
1400242fd:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140024302:     	movq	0x230(%rsp), %rcx
14002430a:     	movl	$0x20, %eax
14002430f:     	leaq	0x210(%rsp), %rdx
140024317:     	cmpq	%rdx, %rcx
14002431a:     	je	0x140024326 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4106>
14002431c:     	movl	$0x28, %eax
140024321:     	testq	%rcx, %rcx
140024324:     	je	0x14002432c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x410c>
140024326:     	movq	(%rcx), %rdx
140024329:     	callq	*(%rdx,%rax)
14002432c:     	leaq	0x270(%rsp), %rcx
140024334:     	callq	0x140025d80 <_ZN2kp13IslandNormalsD2Ev>
140024339:     	leaq	0x350(%rsp), %rcx
140024341:     	callq	0x1400247a0 <_ZN2kp12_GLOBAL__N_19JointRowsD2Ev>
140024346:     	leaq	0x80(%rsp), %rcx
14002434e:     	callq	0x1400247f0 <_ZN2kp12_GLOBAL__N_16MovingD2Ev>
140024353:     	leaq	0x730(%rsp), %rcx
14002435b:     	callq	0x140025df0 <_ZN2kp9PairReachD2Ev>
140024360:     	leaq	0x7e0(%rsp), %rcx
140024368:     	callq	0x140025e80 <_ZN2kp14MissedContactsD2Ev>
14002436d:     	leaq	0x110(%rsp), %rcx
140024375:     	callq	0x140025f60 <_ZNSt3__16vectorIN2kp11SoftContactENS1_13StepAllocatorIS2_EEED2B9nqe230106Ev>
14002437a:     	movq	0xf0(%rsp), %rcx
140024382:     	testq	%rcx, %rcx
140024385:     	jne	0x14002439c <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x417c>
140024387:     	movq	0x130(%rsp), %rcx
14002438f:     	testq	%rcx, %rcx
140024392:     	jne	0x1400243b6 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4196>
140024394:     	movq	%rsi, %rcx
140024397:     	callq	0x140072ed0 <_Unwind_Resume>
14002439c:     	movq	%rcx, 0xf8(%rsp)
1400243a4:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400243a9:     	movq	0x130(%rsp), %rcx
1400243b1:     	testq	%rcx, %rcx
1400243b4:     	je	0x140024394 <_ZNK2kp8SoftStep4stepERNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEERKNS2_INS_11ContactPairENS4_IS8_EEEERKNS_8JointSetENS_7Vector3EdRNS_13ContactForcesERNS2_INS2_IdNS4_IdEEEENS4_ISK_EEEE+0x4174>
1400243b6:     	movq	%rcx, 0x138(%rsp)
1400243be:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
1400243c3:     	movq	%rsi, %rcx
1400243c6:     	callq	0x140072ed0 <_Unwind_Resume>
1400243cb:     	int3
1400243cc:     	nopl	(%rax)

(anonymous namespace)::JointRows::build

C:\Users\PC\kp-2326667-mwrev8ox\sieve-20261122-100223\engine-anatomy-nov22\sg-build\validation\studies\study-grip-limit.exe:	file format coff-x86-64

Disassembly of section .text:

00000001400243d0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb>:
1400243d0:     	pushq	%r15
1400243d2:     	pushq	%r14
1400243d4:     	pushq	%r13
1400243d6:     	pushq	%r12
1400243d8:     	pushq	%rsi
1400243d9:     	pushq	%rdi
1400243da:     	pushq	%rbp
1400243db:     	pushq	%rbx
1400243dc:     	subq	$0x2f8, %rsp            # imm = 0x2F8
1400243e3:     	movapd	%xmm6, 0x2e0(%rsp)
1400243ec:     	movq	%r9, %rbp
1400243ef:     	movq	%r8, 0x60(%rsp)
1400243f4:     	movq	%rdx, %rsi
1400243f7:     	movq	%rcx, %r14
1400243fa:     	movq	(%rcx), %rax
1400243fd:     	movq	%rax, 0x8(%rcx)
140024401:     	addq	$0x18, %rcx
140024405:     	movq	%rcx, 0x58(%rsp)
14002440a:     	callq	0x140048dc0 <_ZN2kp12DirectJoints5clearEv>
14002440f:     	movq	0x8(%rsi), %rax
140024413:     	movq	%rsi, 0x40(%rsp)
140024418:     	cmpq	(%rsi), %rax
14002441b:     	movq	%rbp, 0x48(%rsp)
140024420:     	je	0x1400244b9 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0xe9>
140024426:     	movq	0xc0(%r14), %rax
14002442d:     	movq	0xd0(%r14), %rcx
140024434:     	subq	%rax, %rcx
140024437:     	sarq	$0x3, %rcx
14002443b:     	movabsq	$-0x30c30c30c30c30c3, %rdx # imm = 0xCF3CF3CF3CF3CF3D
140024445:     	imulq	%rdx, %rcx
140024449:     	cmpq	$0x5, %rcx
14002444d:     	ja	0x1400244b9 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0xe9>
14002444f:     	movq	0xc8(%r14), %rsi
140024456:     	subq	%rax, %rsi
140024459:     	movl	$0x3f0, %ecx            # imm = 0x3F0
14002445e:     	callq	0x140072e70 <_Znwy>
140024463:     	movq	%rax, %r13
140024466:     	addq	%rax, %rsi
140024469:     	addq	$0x3f0, %r13            # imm = 0x3F0
140024470:     	movq	0xc0(%r14), %rdi
140024477:     	movq	0xc8(%r14), %r8
14002447e:     	subq	%rdi, %r8
140024481:     	movq	%rsi, %rbp
140024484:     	subq	%r8, %rbp
140024487:     	movq	%rbp, %rcx
14002448a:     	movq	%rdi, %rdx
14002448d:     	callq	0x140072ff0 <memcpy>
140024492:     	movq	%rbp, 0xc0(%r14)
140024499:     	movq	0x48(%rsp), %rbp
14002449e:     	movq	%rsi, 0xc8(%r14)
1400244a5:     	movq	%r13, 0xd0(%r14)
1400244ac:     	testq	%rdi, %rdi
1400244af:     	je	0x1400244b9 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0xe9>
1400244b1:     	movq	%rdi, %rcx
1400244b4:     	callq	0x140072e60 <_ZdlPv>
1400244b9:     	movq	0x40(%rsp), %rcx
1400244be:     	movq	(%rcx), %rax
1400244c1:     	cmpq	%rax, 0x8(%rcx)
1400244c5:     	je	0x140024767 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x397>
1400244cb:     	movzbl	0x368(%rsp), %edi
1400244d3:     	movq	0x360(%rsp), %rbx
1400244db:     	xorb	$0x1, %dil
1400244df:     	xorl	%esi, %esi
1400244e1:     	movsd	0x516e7(%rip), %xmm6    # 0x140075bd0 <_ZTSNSt3__110__function6__baseIFvyEEE+0xd8>
1400244e9:     	jmp	0x140024514 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x144>
1400244eb:     	nopl	(%rax,%rax)
1400244f0:     	movq	0x68(%rsp), %rsi
1400244f5:     	incq	%rsi
1400244f8:     	movq	0x40(%rsp), %rcx
1400244fd:     	movq	(%rcx), %rax
140024500:     	movq	0x8(%rcx), %rcx
140024504:     	subq	%rax, %rcx
140024507:     	sarq	$0x3, %rcx
14002450b:     	cmpq	%rcx, %rsi
14002450e:     	jae	0x140024767 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x397>
140024514:     	movq	(%rax,%rsi,8), %rcx
140024518:     	movq	0x60(%rsp), %rdx
14002451d:     	movq	%rdx, %r8
140024520:     	leaq	0xc0(%r14), %r9
140024527:     	callq	0x14000c230 <_ZNK2kp5Joint10writeBondsERKNSt3__16vectorINS_4BodyENS1_9allocatorIS3_EEEES8_RNS2_INS_4BondENS4_IS9_EEEE>
14002452c:     	movq	(%rbx), %rcx
14002452f:     	movq	%rsi, 0x68(%rsp)
140024534:     	leaq	(%rsi,%rsi,2), %r12
140024538:     	movq	0x8(%rcx,%r12,8), %r9
14002453d:     	subq	(%rcx,%r12,8), %r9
140024541:     	sarq	$0x3, %r9
140024545:     	movq	0xc0(%r14), %rax
14002454c:     	movq	0xc8(%r14), %r8
140024553:     	movq	%r8, %rdx
140024556:     	subq	%rax, %rdx
140024559:     	sarq	$0x3, %rdx
14002455d:     	movabsq	$-0x30c30c30c30c30c3, %r10 # imm = 0xCF3CF3CF3CF3CF3D
140024567:     	imulq	%r10, %rdx
14002456b:     	cmpq	%rdx, %r9
14002456e:     	je	0x140024595 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x1c5>
140024570:     	leaq	(%rcx,%r12,8), %rcx
140024574:     	movq	$0x0, 0x70(%rsp)
14002457d:     	leaq	0x70(%rsp), %r8
140024582:     	callq	0x140026a30 <_ZNSt3__16vectorIdNS_9allocatorIdEEE6assignB9nqe230106EyRKd>
140024587:     	movq	0xc0(%r14), %rax
14002458e:     	movq	0xc8(%r14), %r8
140024595:     	cmpq	%rax, %r8
140024598:     	je	0x1400244f0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x120>
14002459e:     	xorl	%r15d, %r15d
1400245a1:     	xorl	%r13d, %r13d
1400245a4:     	xorl	%esi, %esi
1400245a6:     	jmp	0x1400245fd <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x22d>
1400245a8:     	nopl	(%rax,%rax)
1400245b0:     	movq	(%rbx), %rax
1400245b3:     	movq	(%rax,%r12,8), %r8
1400245b7:     	addq	%r15, %r8
1400245ba:     	leaq	0x18(%r14), %rcx
1400245be:     	callq	0x140048e60 <_ZN2kp12DirectJoints3addERKNS_4BondEPd>
1400245c3:     	incq	%rsi
1400245c6:     	movq	0xc0(%r14), %rax
1400245cd:     	movq	0xc8(%r14), %rcx
1400245d4:     	subq	%rax, %rcx
1400245d7:     	sarq	$0x3, %rcx
1400245db:     	movabsq	$-0x30c30c30c30c30c3, %rdx # imm = 0xCF3CF3CF3CF3CF3D
1400245e5:     	imulq	%rdx, %rcx
1400245e9:     	addq	$0xa8, %r13
1400245f0:     	addq	$0x8, %r15
1400245f4:     	cmpq	%rcx, %rsi
1400245f7:     	jae	0x1400244f0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x120>
1400245fd:     	leaq	(%rax,%r13), %rdx
140024601:     	movzbl	0x89(%rax,%r13), %ecx
14002460a:     	orb	%dil, %cl
14002460d:     	testb	$0x1, %cl
140024610:     	jne	0x140024630 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x260>
140024612:     	cmpb	$0x0, 0x78(%rax,%r13)
140024618:     	jne	0x140024630 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x260>
14002461a:     	cmpb	$0x1, 0x60(%rax,%r13)
140024620:     	jne	0x1400245b0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x1e0>
140024622:     	movsd	0x70(%rax,%r13), %xmm0
140024629:     	ucomisd	%xmm6, %xmm0
14002462d:     	jae	0x1400245b0 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x1e0>
14002462f:     	nop
140024630:     	movq	(%rbx), %rax
140024633:     	movq	(%rax,%r12,8), %rax
140024637:     	addq	%r15, %rax
14002463a:     	movq	%rax, 0x20(%rsp)
14002463f:     	leaq	0x70(%rsp), %rcx
140024644:     	movl	$0x1, %r8d
14002464a:     	movq	%rbp, %r9
14002464d:     	callq	0x14004a730 <_ZN2kp9SoftJointC2EPKNS_4BondEiRKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS6_EEEEPd>
140024652:     	cmpb	$0x1, 0x2d1(%rsp)
14002465a:     	jne	0x1400245c3 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x1f3>
140024660:     	movq	0x8(%r14), %rbp
140024664:     	cmpq	0x10(%r14), %rbp
140024668:     	je	0x140024692 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x2c2>
14002466a:     	movl	$0x270, %r8d            # imm = 0x270
140024670:     	movq	%rbp, %rcx
140024673:     	leaq	0x70(%rsp), %rdx
140024678:     	callq	0x140072ff0 <memcpy>
14002467d:     	addq	$0x270, %rbp            # imm = 0x270
140024684:     	movq	%rbp, 0x8(%r14)
140024688:     	movq	0x48(%rsp), %rbp
14002468d:     	jmp	0x1400245c3 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x1f3>
140024692:     	subq	(%r14), %rbp
140024695:     	movq	%rbp, %rax
140024698:     	sarq	$0x4, %rax
14002469c:     	movabsq	$0x6f96f96f96f96f97, %rcx # imm = 0x6F96F96F96F96F97
1400246a6:     	imulq	%rcx, %rax
1400246aa:     	leaq	0x1(%rax), %rcx
1400246ae:     	movabsq	$0x69069069069069, %r8  # imm = 0x69069069069069
1400246b8:     	cmpq	%r8, %rcx
1400246bb:     	ja	0x140024790 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x3c0>
1400246c1:     	leaq	(%rax,%rax), %rdx
1400246c5:     	cmpq	%rcx, %rdx
1400246c8:     	cmovaq	%rdx, %rcx
1400246cc:     	movabsq	$0x34834834834834, %rdx # imm = 0x34834834834834
1400246d6:     	cmpq	%rdx, %rax
1400246d9:     	cmovaeq	%r8, %rcx
1400246dd:     	imulq	$0x270, %rcx, %rcx      # imm = 0x270
1400246e4:     	movq	%rcx, 0x38(%rsp)
1400246e9:     	callq	0x1400117e0 <_ZN2kp10StepMemory4takeEy>
1400246ee:     	movq	%rax, 0x50(%rsp)
1400246f3:     	leaq	(%rax,%rbp), %rcx
1400246f7:     	movq	%rcx, 0x30(%rsp)
1400246fc:     	addq	%rax, 0x38(%rsp)
140024701:     	movl	$0x270, %r8d            # imm = 0x270
140024707:     	leaq	0x70(%rsp), %rdx
14002470c:     	callq	0x140072ff0 <memcpy>
140024711:     	movq	0x50(%rsp), %rax
140024716:     	addq	%rax, %rbp
140024719:     	addq	$0x270, %rbp            # imm = 0x270
140024720:     	movq	(%r14), %rdx
140024723:     	movq	0x8(%r14), %r8
140024727:     	subq	%rdx, %r8
14002472a:     	movq	0x30(%rsp), %rcx
14002472f:     	subq	%r8, %rcx
140024732:     	movq	%rcx, 0x30(%rsp)
140024737:     	callq	0x140072ff0 <memcpy>
14002473c:     	movq	(%r14), %rcx
14002473f:     	movq	0x30(%rsp), %rax
140024744:     	movq	%rax, (%r14)
140024747:     	movq	%rbp, 0x8(%r14)
14002474b:     	movq	0x38(%rsp), %rax
140024750:     	movq	%rax, 0x10(%r14)
140024754:     	testq	%rcx, %rcx
140024757:     	je	0x140024684 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x2b4>
14002475d:     	callq	0x140011ed0 <_ZN2kp10StepMemory4giveEPv>
140024762:     	jmp	0x140024684 <_ZN2kp12_GLOBAL__N_19JointRows5buildERKNS_8JointSetERKNSt3__16vectorINS_4BodyENS5_9allocatorIS7_EEEERKNS6_INS_10SolverBodyENS_13StepAllocatorISD_EEEERNS6_INS6_IdNS8_IdEEEENS8_ISK_EEEEb+0x2b4>
140024767:     	movq	0x58(%rsp), %rcx
14002476c:     	movq	%rbp, %rdx
14002476f:     	callq	0x140048f10 <_ZN2kp12DirectJoints8assembleERKNSt3__16vectorINS_10SolverBodyENS_13StepAllocatorIS3_EEEE>
140024774:     	movaps	0x2e0(%rsp), %xmm6
14002477c:     	addq	$0x2f8, %rsp            # imm = 0x2F8
140024783:     	popq	%rbx
140024784:     	popq	%rbp
140024785:     	popq	%rdi
140024786:     	popq	%rsi
140024787:     	popq	%r12
140024789:     	popq	%r13
14002478b:     	popq	%r14
14002478d:     	popq	%r15
14002478f:     	retq
140024790:     	callq	0x140026c70 <_ZNSt3__16vectorIN2kp9SoftJointENS1_13StepAllocatorIS2_EEE20__throw_length_errorB9nqe230106Ev>
140024795:     	int3
140024796:     	nopw	%cs:(%rax,%rax)
